//
//  NSArray+TYSafeAccess.m
//  Project
//
//  Created by eagle on 18/02/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "NSArray+TYAdd.h"



@implementation NSArray (TYAdd)

// 默认数据
// TYViewController
// XGeneric
// regions
+ (instancetype)cityDataFromBundleForClass:(NSString *)cls
                            resourceBundle:(NSString *)bundleName
                                  fileName:(NSString *)fileName
                                   fileExt:(NSString *)fileExt{
    
    NSBundle *bundleForCls = [NSBundle bundleForClass:NSClassFromString(cls)] ;
    NSString *path = [bundleForCls pathForResource:bundleName ofType:@"bundle"] ;
    NSBundle *bundle = [NSBundle bundleWithPath:path];
    
    // 获取文件路径
    NSString *jsonPath = [bundle pathForResource:fileName ofType:fileExt];
    NSData *data = [NSData dataWithContentsOfFile:jsonPath];
    if (data == nil) {
        return @[].copy;
    }
    
    // 解析
    NSError *error = nil;
    NSArray *result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    if (error != nil) {
        return @[].copy;
    }
    
    return result.copy;
}

// 读取本地JSON文件
- (NSArray *)readLocalFileWithName:(NSString *)name {
    // 获取文件路径
    NSString *path = [[NSBundle mainBundle] pathForResource:name ofType:@"json"];
    // 将文件数据化
    NSData *data = [[NSData alloc] initWithContentsOfFile:path];
    // 对数据进行JSON格式化并返回字典形式
    return [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
}

- (NSArray *)ty_subArrayWithCount:(NSInteger)count {
    if (count < 0) { count = 0;  }
    NSInteger cutCount = MIN(self.count, count);
    return [self subarrayWithRange:NSMakeRange(0, cutCount)];
}
@end
