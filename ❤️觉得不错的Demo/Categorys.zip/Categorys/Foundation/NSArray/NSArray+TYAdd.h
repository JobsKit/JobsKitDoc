//
//  NSArray+TYSafeAccess.h
//  Project
//
//  Created by eagle on 18/02/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSArray (TYAdd)


/// 获取城市数据
/// @param cls 指定类所在的Bundle
/// @param bundleName  指定类所在的Bundle下的Bundle的名称
/// @param fileName  文件名
/// @param fileExt 文件扩展名
+ (instancetype)cityDataFromBundleForClass:(NSString *)cls
                            resourceBundle:(NSString *)bundleName
                                  fileName:(NSString *)fileName
                                   fileExt:(NSString *)fileExt;

/// 获得子数组
/// @param count  数组长度
- (NSArray *)ty_subArrayWithCount:(NSInteger)count;
@end

NS_ASSUME_NONNULL_END
