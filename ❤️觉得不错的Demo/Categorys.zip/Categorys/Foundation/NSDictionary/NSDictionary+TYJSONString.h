//
//  NSDictionary+TYJSONString.h
//  YaboSports
//
//  Created by windy on 17/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDictionary (TYJSONString)

/**
 *  @brief NSDictionary转换成JSON字符串
 *
 *  @return  JSON字符串
 */
-(NSString *)ty_JSONString;

@end

NS_ASSUME_NONNULL_END
