//
//  NSDictionary+TYSafeAccess.h
//  YaboSports
//
//  Created by windy on 17/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDictionary (TYSafeAccess)

- (BOOL)ty_hasKey:(NSString *)key;

- (NSString*)ty_stringForKey:(id)key;

- (NSNumber*)ty_numberForKey:(id)key;

- (NSDecimalNumber *)ty_decimalNumberForKey:(id)key;

- (NSArray*)ty_arrayForKey:(id)key;

- (NSDictionary*)ty_dictionaryForKey:(id)key;

- (NSInteger)ty_integerForKey:(id)key;

- (NSUInteger)ty_unsignedIntegerForKey:(id)key;

- (BOOL)ty_boolForKey:(id)key;

- (int16_t)ty_int16ForKey:(id)key;

- (int32_t)ty_int32ForKey:(id)key;

- (int64_t)ty_int64ForKey:(id)key;

- (char)ty_charForKey:(id)key;

- (short)ty_shortForKey:(id)key;

- (float)ty_floatForKey:(id)key;

- (double)ty_doubleForKey:(id)key;

- (long long)ty_longLongForKey:(id)key;

- (unsigned long long)ty_unsignedLongLongForKey:(id)key;

- (NSDate *)ty_dateForKey:(id)key dateFormat:(NSString *)dateFormat;

//CG
- (CGFloat)ty_CGFloatForKey:(id)key;

- (CGPoint)ty_pointForKey:(id)key;

- (CGSize)ty_sizeForKey:(id)key;

- (CGRect)ty_rectForKey:(id)key;
@end

#pragma --mark NSMutableDictionary setter

@interface NSMutableDictionary(SafeAccess)

-(void)ty_setObj:(id)i forKey:(NSString*)key;

-(void)ty_setString:(NSString*)i forKey:(NSString*)key;

-(void)ty_setBool:(BOOL)i forKey:(NSString*)key;

-(void)ty_setInt:(int)i forKey:(NSString*)key;

-(void)ty_setInteger:(NSInteger)i forKey:(NSString*)key;

-(void)ty_setUnsignedInteger:(NSUInteger)i forKey:(NSString*)key;

-(void)ty_setCGFloat:(CGFloat)f forKey:(NSString*)key;

-(void)ty_setChar:(char)c forKey:(NSString*)key;

-(void)ty_setFloat:(float)i forKey:(NSString*)key;

-(void)ty_setDouble:(double)i forKey:(NSString*)key;

-(void)ty_setLongLong:(long long)i forKey:(NSString*)key;

-(void)ty_setPoint:(CGPoint)o forKey:(NSString*)key;

-(void)ty_setSize:(CGSize)o forKey:(NSString*)key;

-(void)ty_setRect:(CGRect)o forKey:(NSString*)key;

@end

NS_ASSUME_NONNULL_END
