//
//  NSDictionary+TYFoundation.m
//  TYNetworking
//
//  Created by eagle on 2019/3/18.
//  Copyright © 2019 com.ty. All rights reserved.
//

#import "NSDictionary+TYFoundation.h"

@implementation NSDictionary (TYFoundation)

- (NSInteger) getIntValueWithKey:(NSString *) key defaultValue:(NSInteger) defaultValue {
    id obj = [self objectForKey:key];
    if (obj && [obj isKindOfClass:[NSNumber class]]) {
        return [(NSNumber *)obj integerValue];
    }
    return defaultValue;
}

- (NSString *) getStringValueWithKey:(NSString *) key defaultValue:(NSString *) defaultValue {
    id obj = [self objectForKey:key];
    if (obj && [obj isKindOfClass:[NSString class]]) {
        return obj;
    }
    return defaultValue;
}

- (BOOL) getBoolValueWithKey:(NSString *) key defaultValue:(BOOL) defaultValue {
    id obj = [self objectForKey:key];
    if (obj && [obj isKindOfClass:[NSNumber class]]) {
        return [(NSNumber *)obj boolValue];
    }
    return defaultValue;
}

@end
