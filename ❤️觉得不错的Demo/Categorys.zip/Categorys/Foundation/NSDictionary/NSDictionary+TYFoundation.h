//
//  NSDictionary+TYFoundation.h
//  TYNetworking
//
//  Created by eagle on 2019/3/18.
//  Copyright © 2019 com.ty. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDictionary (TYFoundation)

- (NSInteger) getIntValueWithKey:(NSString *) key defaultValue:(NSInteger) defaultValue;
- (NSString *) getStringValueWithKey:(NSString *) key defaultValue:(NSString *) defaultValue;
- (BOOL) getBoolValueWithKey:(NSString *) key defaultValue:(BOOL) defaultValue;

@end

NS_ASSUME_NONNULL_END
