//
//  NSString+URLPath.m
//  FirefoxGames
//
//  Created by Frederic on 2020/11/30.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "NSString+URLPath.h"

@implementation NSString(URLPath)
- (NSString *)stringByAppendPath:(NSString *)path{
    
    BOOL selfHas = [self hasSuffix:@"/"];
    BOOL pathHas = [path hasPrefix:@"/"];
    NSMutableString *result = [NSMutableString stringWithFormat:@"%@%@", self, path];
    
    //如果两个都有斜线，替换重复的
    if (selfHas && pathHas) {
        [result replaceOccurrencesOfString:@"//" withString:@"/" options:NSCaseInsensitiveSearch range:NSMakeRange(0, result.length)];
    }
    
    //两个都没有，补一个
    if (!selfHas && !pathHas) {
        result = [NSMutableString stringWithFormat:@"%@/%@", self, path];
    }
    
    return result;
}
@end
