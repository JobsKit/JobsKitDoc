//
//  NSString+URLPath.h
//  FirefoxGames
//
//  Created by Frederic on 2020/11/30.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString(URLPath)
//Url路径拼接、解决多一个斜线或者少一个斜线的问题
- (NSString *)stringByAppendPath:(NSString *)path;
@end

NS_ASSUME_NONNULL_END
