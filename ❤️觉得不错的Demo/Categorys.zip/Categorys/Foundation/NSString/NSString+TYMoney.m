//
//  NSString+TYMoney.m
//  YaboSports
//
//  Created by corin on 2019/11/24.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "NSString+TYMoney.h"

#define DEFAULT_FRACTION_LENGTH 2

@implementation NSString (TYMoney)
+ (NSString *)ty_moneyFormattedWithString:(NSString *)moneyStr hasFraction:(BOOL)fraction thousandSeparator:(BOOL)separator {
    return [self _moneyFormattedWithString:moneyStr fractionLength:(fraction == YES? DEFAULT_FRACTION_LENGTH: 0) thousandSeparator:separator];
}

+ (NSString *)ty_moneyFormattedWithString:(NSString *)moneyStr fractionLength:(NSUInteger)fractionLength thousandSeparator:(BOOL)separator {
    return [self _moneyFormattedWithString:moneyStr fractionLength:fractionLength thousandSeparator:separator];
}

+ (NSString *)ty_moneyFormattedWithNumber:(NSNumber *)money hasFraction:(BOOL)fraction thousandSeparator:(BOOL)separator {
    return [self ty_moneyFormattedWithNumber:money fractionLength:(fraction == YES? DEFAULT_FRACTION_LENGTH: 0) thousandSeparator:separator];
}

+ (NSString *)ty_moneyFormattedWithNumber:(NSNumber *)money fractionLength:(NSUInteger)fractionLength thousandSeparator:(BOOL)separator {
    NSParameterAssert(money);
    NSString *moneyStr = [money stringValue];
    return [self _moneyFormattedWithString:moneyStr fractionLength:fractionLength thousandSeparator:separator];
}

+ (NSString *)_moneyFormattedWithString:(NSString *)moneyStr fractionLength:(NSUInteger)fractionLength thousandSeparator:(BOOL)separator {
    NSParameterAssert(moneyStr);
    if (!moneyStr) {
        return @"";
    }
    if ([moneyStr containsString:@","]) {
        return moneyStr;
    }
    NSDecimalNumber *number = [[NSDecimalNumber alloc] initWithString:moneyStr];
    if ([number isEqualToNumber:NSDecimalNumber.notANumber]) {
        return moneyStr;
    }
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.formatterBehavior = NSNumberFormatterBehaviorDefault;
    formatter.numberStyle = NSNumberFormatterDecimalStyle;
    formatter.maximumFractionDigits = fractionLength;
    formatter.minimumFractionDigits = fractionLength;
    formatter.groupingSeparator = @",";
    NSString *formattedMoney = [formatter stringFromNumber:number];
    return formattedMoney;
}
@end
