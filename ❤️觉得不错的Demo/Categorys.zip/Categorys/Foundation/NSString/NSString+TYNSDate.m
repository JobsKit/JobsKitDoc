//
//  NSString+TYNSDate.m
//  YaboGames
//
//  Created by mac on 2019/12/6.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "NSString+TYNSDate.h"
#import "NSDate+TYExtension.h"

@implementation NSString (TYNSDate)

+ (NSString *)getTimeStringWithDate:(NSDate *)date {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSString *dateTime = [formatter stringFromDate:date];
    return dateTime;
}

/**
 获取 年-月-日 的格式 为 月-日
 @param yyMMDDSting 带年的
 @return 返回不带年
 */
+ (NSString *)getMonthDayStringWithYYMMDDString:(NSString *)yyMMDDSting {
    
     NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
     NSDate *date = [NSDate ty_dateWithString:yyMMDDSting format:@"yyyy-MM-dd"];
     formatter.dateFormat = @"MM月dd日";
    return [formatter stringFromDate:date];
}


/**
 返回 将这样的 31/12  返回  12月31日 这样的
 
 @param dayMonth 31/12
 @return 12月31日
 */
+ (NSString *)getMonthDayWithDayMonthFormatStr:(NSString *)dayMonth {
    
    NSString *monthDay = @"";
    if (dayMonth) {
        /// 此处做一下兼容，如果strs中不包含 “-” 符号，则直接返回原字符串
        if ([dayMonth containsString:@"-"]) {
            NSArray *strs = [dayMonth componentsSeparatedByString:@"-"];
            if (strs.count == 2) {
    //            NSArray *monthDays = @[strs.lastObject,strs.firstObject];
                NSArray *monthDays = @[strs.firstObject,strs.lastObject];
                monthDay = [[monthDays componentsJoinedByString:@"月"] stringByAppendingString:@"日"];
            }
            return monthDay;
        }
    }
    return dayMonth;
}

- (NSDate *)ty_timeStampDate {
    NSTimeInterval timestamp = self.longLongValue;
    if (self.length == @"1622619286000".length) {
        // 毫秒改成秒
        timestamp = timestamp/1000;
    }
    NSTimeZone *destinationTimeZone = [NSTimeZone localTimeZone];
    
    NSTimeZone *baseTimeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    
    NSInteger countGMT = [destinationTimeZone secondsFromGMT];
    
    NSInteger countGMT1 = [baseTimeZone secondsFromGMT];
    
    return [NSDate dateWithTimeIntervalSince1970:timestamp + (countGMT1 - countGMT)];
}

- (NSString *)ty_timeStampDateWithFormat:(NSString *)formatString {
    NSDate *date = [self ty_timeStampDate];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:formatString];
    NSString *dateString = [formatter stringFromDate:date];
    return dateString;
}
@end
