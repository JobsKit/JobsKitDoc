//
//  NSString+TYFBiz.m
//  FirefoxGames
//
//  Created by storm on 2020/10/20.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "NSString+TYFBiz.h"

@implementation NSString (TYFBiz)
- (NSString *)ty_urlAddiCode {

    NSString *iCode = TYInstallSharedManager.getParams[@"i_code"];
    NSString *downloadUrl = [self ty_urlAddQueryWithKey:@"i_code" value:iCode];
    if ([self isEqualToString:downloadUrl]) {
        // 上报日志,地址没有变化，说明有问题，需要日志上报
        NSString *params = [TYInstallSharedManager.getParams yy_modelToJSONString];
        NSDictionary *requestLog = @{@"downloadUrl":EMPTY_IF_NIL(downloadUrl),
                                     @"TYInstallParams":EMPTY_IF_NIL(params),
                                     @"status": @"添加iCode失败",
                                     @"subEventType": @"iCode"
        };
        NSDictionary *reportInfo = @{@"request":requestLog?requestLog:@{},@"response":@{}};
        [TYFBusinessLogService submitLogWithEventType:TYLogUploadEventTypeOpeartion apiName:@"" params:reportInfo];
    }else{
        // 上报成功日志
        NSString *params = [TYInstallSharedManager.getParams yy_modelToJSONString];
        NSDictionary *requestLog = @{@"downloadUrl":EMPTY_IF_NIL(downloadUrl),
                                     @"TYInstallParams":EMPTY_IF_NIL(params),
                                     @"status": @"添加iCode成功",
                                     @"subEventType": @"iCode"
        };
        NSDictionary *reportInfo = @{@"request":requestLog?requestLog:@{},@"response":@{}};
        [TYFBusinessLogService submitLogWithEventType:TYLogUploadEventTypeOpeartion apiName:@"" params:reportInfo];
    }
    return downloadUrl;
}

- (NSString *)ty_addTokenTypeUrl {
    NSString *loadUrl = self;
    
    if (TYKToken().length) {
        loadUrl = [self appendingBaseUrl:loadUrl queryKey:@"token" queryValue:TYKToken()];
    }

    if (IsIphoneX()) {//SKTF 通过传isiphonex来判断刘海屏,VIP顶部导航栏隐藏,显示填满页面
        loadUrl = [self appendingBaseUrl:loadUrl queryKey:@"isiphonex" queryValue:@"1"];
    }
    
    NSString *h5Domain = TYKHTML5Domain();
    if (![loadUrl.lowercaseString hasPrefix:@"http"]) {
        if ([h5Domain hasSuffix:@"/"]) {
            h5Domain = [h5Domain substringToIndex:h5Domain.length];
        }
        if ([loadUrl hasPrefix:@"/"]) {
            loadUrl = [loadUrl substringFromIndex:1];
        }
        loadUrl = [NSString stringWithFormat:@"%@/%@",h5Domain,loadUrl];
    }
    return loadUrl;
}

- (NSString *)appendingBaseUrl:(NSString *)baseUrl queryKey:(NSString *)queryKey queryValue:(NSString *)queryValue {
    NSURLComponents *cpt = [[NSURLComponents alloc] initWithString:baseUrl ?: @""];
    __block bool existToken = false;
    [cpt.queryItems enumerateObjectsUsingBlock:^(NSURLQueryItem * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj.name isEqualToString:queryKey]) {
            existToken = true;
            *stop = true;
        }
    }];
    
    // && ![baseUrl containsString:@"客服"]
    if (!existToken) {
        if (cpt.queryItems.count == 0) {
          baseUrl =  [NSString stringWithFormat:@"%@?%@=%@", EMPTY_IF_NIL(baseUrl),queryKey,queryValue];
        } else {
          baseUrl =  [NSString stringWithFormat:@"%@&%@=%@", EMPTY_IF_NIL(baseUrl),queryKey,queryValue];
        }
    }
    
    return baseUrl;
}
@end
