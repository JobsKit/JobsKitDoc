//
//  NSString+TYFBiz.h
//  FirefoxGames
//
//  Created by storm on 2020/10/20.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (TYFBiz)
// 加载地址里添加iCode参数，下载地址必须是一个可以在浏览器里展示APP下载页的地址
- (NSString *)ty_urlAddiCode;
- (NSString *)ty_addTokenTypeUrl;
@end

NS_ASSUME_NONNULL_END
