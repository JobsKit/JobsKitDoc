//
//  NSString+TYHash.h
//  TYNetworking
//
//  Created by eagle on 2019/3/14.
//  Copyright © 2019 com.ty. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (TYHash)

- (NSString *)ty_md5;

@end

NS_ASSUME_NONNULL_END
