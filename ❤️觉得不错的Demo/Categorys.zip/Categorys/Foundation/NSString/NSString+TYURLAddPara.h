//
//  NSString+TYURLAddPara.h
//  YaboSports
//
//  Created by Allon on 2019/9/8.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (TYURLAddPara)

/**
 给链接拼接参数

 @param paraments 参数及相应value的map
 @param linkURLString 原链接字符串
 @return 拼接参数后的字符串
 */
+ (NSString *)addParaWith:(nonnull NSDictionary *)paraments originLinkURLString:(nonnull NSString *)linkURLString;

@end

NS_ASSUME_NONNULL_END
