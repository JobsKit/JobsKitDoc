//
//  NSString+TYURLAddPara.m
//  YaboSports
//
//  Created by Allon on 2019/9/8.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "NSString+TYURLAddPara.h"
#import "NSString+TYAdd.h"

@implementation NSString (TYURLAddPara)

+ (NSString *)addParaWith:(nonnull NSDictionary *)paraments originLinkURLString:(nonnull NSString *)linkURLString {
    NSAssert(linkURLString, @"The URL components linkURLString must not be nil/null!");
    if ([linkURLString isNotNilOrWhiteSpaceString]) {
        NSURLComponents *urlComponents = [NSURLComponents componentsWithString:linkURLString];
        NSMutableArray *items = [NSMutableArray arrayWithArray:urlComponents.queryItems];
        
        [paraments enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            __block BOOL exist = NO;
            NSString *paraKey = (NSString *)key;
            NSString *paraValue = (NSString *)obj;
            if ([paraValue isNotNilOrWhiteSpaceString]) {
                [items enumerateObjectsUsingBlock:^(NSURLQueryItem * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    if ([obj.name isEqualToString:paraKey]) {
                        exist = YES;
                        *stop = YES;
                    }
                }];
                if(!exist){
                    NSURLQueryItem *paraItem = [NSURLQueryItem queryItemWithName:paraKey value:paraValue];
                    [items addObject:paraItem];
                    [urlComponents setQueryItems:items];
                }
            }
        }];
        return urlComponents.URL.absoluteString;
    }
    return @"";
}

@end
