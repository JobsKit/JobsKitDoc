//
//  NSString+TYNSDate.h
//  YaboGames
//
//  Created by mac on 2019/12/6.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (TYNSDate)


/**
 返回 某个 NSDate 日期的 字符串格式.2019-12-06 这样的格式.

 @param date 要格式化字符串的 日期
 @return 2019-12-06类似格式的字符串.
 */
+ (NSString *)getTimeStringWithDate:(NSDate *)date;


/**
 获取 年-月-日 的格式 为 月-日
 @param yyMMDDSting 带年的
 @return 返回不带年
 */
+ (NSString *)getMonthDayStringWithYYMMDDString:(NSString *)yyMMDDSting;

/**
 返回 将这样的 31/12  返回  12月31日 这样的
 
 @param dayMonth 31/12
 @return 12月31日
 */
+ (NSString *)getMonthDayWithDayMonthFormatStr:(NSString *)dayMonth;

- (NSDate *)ty_timeStampDate;
- (NSString *)ty_timeStampDateWithFormat:(NSString *)format;
@end

NS_ASSUME_NONNULL_END
