//
//  NSString+TYMoney.h
//  YaboSports
//
//  Created by corin on 2019/11/24.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "TYCommonSaftyMacro.h"

NS_ASSUME_NONNULL_BEGIN

#define TYMoneyDefaultFormatted(_money) [NSString ty_moneyFormattedWithString:(EMPTY_IF_NIL(_money)) hasFraction:YES thousandSeparator:YES]

@interface NSString (TYMoney)

/**
 获取格式化后的金额字符串
 @param moneyStr 金额字符串
 @param decimal 是否显示小数位
 @param separator 金额字符串
 例：
 moneyStr: @"12345.12"  decimal: YES separator: YES,  返回：@"12,345.12"
 moneyStr: @"12345.12"  decimal: YES separator: NO,   返回：@"12345.12"
 moneyStr: @"12345.12"  decimal: NO  separator: YES,  返回：@"12,345"
 moneyStr: @"12345.12"  decimal: NO  separator: NO,   返回：@"12345"
 */
+ (NSString *)ty_moneyFormattedWithString:(NSString *)moneyStr hasFraction:(BOOL)decimal thousandSeparator:(BOOL)separator;

/**
 获取格式化后的金额字符串
 @param moneyStr 金额字符串
 @param fractionLength 是否显示小数位
 @param separator 金额字符串
 例：
 moneyStr: @"12345.12123"  fractionLength: 1  separator: YES, 返回：@"12,345.1"
 moneyStr: @"12345.12123"  fractionLength: 2  separator: YES, 返回：@"12,345.12"
 moneyStr: @"12345.12123"  fractionLength: 2  separator: NO,  返回：@"12345.12"
 moneyStr: @"12345.12123"  fractionLength: 0  separator: NO,  返回：@"12345"
 */
+ (NSString *)ty_moneyFormattedWithString:(NSString *)moneyStr fractionLength:(NSUInteger)fractionLength thousandSeparator:(BOOL)separator;
    
/**
 获取格式化后的金额字符串
 @param money 金额
 @param decimal 是否有小数位
 @param separator 是否有千分位
 money: @(12345.12123)  decimal: YES  separator: YES, 返回：@"12,345.12"
 money: @(12345.12123)  decimal: YES  separator: NO,  返回：@"12345.12"
 money: @(12345.12123)  decimal: NO   separator: YES, 返回：@"12,345"
 money: @(12345.12123)  decimal: NO   separator: NO,  返回：@"12345"
 */
+ (NSString *)ty_moneyFormattedWithNumber:(NSNumber *)money hasFraction:(BOOL)decimal thousandSeparator:(BOOL)separator;

/**
 获取格式化后的金额字符串
 @param money 金额
 @param fractionLength 小数位数
 @param separator 是否有千分位
 money: @(12345.12123)  fractionLength: 1  separator: YES, 返回：@"12,345.1"
 money: @(12345.12123)  fractionLength: 2  separator: YES, 返回：@"12,345.12"
 money: @(12345.12123)  fractionLength: 2  separator: NO,  返回：@"12345.12"
 money: @(12345.12123)  fractionLength: 0  separator: NO,  返回：@"12345"
 */
+ (NSString *)ty_moneyFormattedWithNumber:(NSNumber *)money fractionLength:(NSUInteger)fractionLength thousandSeparator:(BOOL)separator;
@end

NS_ASSUME_NONNULL_END
