//
//  NSString+TYAES.h
//  AFNetworking
//
//  Created by corin on 2020/1/3.
// 
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (TYAES)


/// 字符串的AES解密
/// 这个字符串是经过base64加密过的，先需要做一次base64解码
/// @param key AES解密的key
/// @param piv AES解密的向量
- (NSString*)ty_decryptAESWithKey:(NSString *)key peiv:(NSString *)piv;

@end

NS_ASSUME_NONNULL_END
