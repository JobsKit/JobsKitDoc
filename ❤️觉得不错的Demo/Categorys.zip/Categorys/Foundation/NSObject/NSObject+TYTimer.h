//
//  NSObject+TYTimer.h
//  YaboSports
//
//  Created by mac on 2019/8/31.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^TimerActionBlock)(NSUInteger times);
typedef void (^TimerCompleteBlock)(void);

/*
 对NSObject 子类做一个定时器功能. 如果验证码 获取 倒计时.
 */

@interface NSObject (TYTimer)

@property (nonatomic, readonly) BOOL isTiming;

- (void)stopTimer;

- (void)startTimerWithTotalTime:(NSUInteger)totalTime
                       interval:(NSUInteger)interval
                         action:(TimerActionBlock)actionBlock
                       complete:(TimerCompleteBlock)completeBlock;
@end

NS_ASSUME_NONNULL_END
