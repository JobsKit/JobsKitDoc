//
//  NSObject+TYTimer.m
//  YaboSports
//
//  Created by mac on 2019/8/31.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <objc/runtime.h>
#import "NSObject+TYTimer.h"
#import "TYProxy.h"
#import "TYCommonSaftyMacro.h"

@implementation NSObject (TYTimer)
#pragma mark - public methods
- (void)stopTimer {
    if ([self timer]) {
        [[self timer] invalidate];
    }
    
    [self setTimer:nil];
    [self setTotalTime:0];
    [self setActionBlock:nil];
    [self setCompleteBlock:nil];
    [self endBack];
}

- (void)startTimerWithTotalTime:(NSUInteger)totalTime
                       interval:(NSUInteger)interval
                         action:(TimerActionBlock)actionBlock
                       complete:(TimerCompleteBlock)completeBlock {
    
    [self stopTimer];

    [self setTotalTime:totalTime];
    [self setActionBlock:actionBlock];
    [self setCompleteBlock:completeBlock];    
    NSTimer *timer = [NSTimer timerWithTimeInterval:interval
                                             target:[self proxy]
                                           selector:@selector(timerRepeatAction)
                                           userInfo:nil
                                            repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
    [self setTimer:timer];
    
    [self beginTask];
}

#pragma mark - private methods
- (void)timerRepeatAction {
    NSUInteger remainTime = [self totalTime]-1;
    if (remainTime > 0 && remainTime < [self totalTime]) {
        [self setTotalTime:remainTime];
        
        TimerActionBlock actionBlock = [self actionBlock];
        if (actionBlock) {
            actionBlock(remainTime);
        }
    } else {
        TimerCompleteBlock completeBlock = [self completeBlock];
        if (completeBlock) {
            completeBlock();
        }
        [self stopTimer];
    }
}

//申请后台
-(void)beginTask {
    ///如果之前存在backIden,先注销之前的BackgroundTask
    [self endBack];
    //申请新BackgroundTask
    @weakify(self)
    UIBackgroundTaskIdentifier _backIden = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
        @strongify(self)
        [self endBack];
    }];
    [self setBackIden:_backIden];
}

//注销后台
-(void)endBack {
    UIBackgroundTaskIdentifier _backIden = [self backIden];
    if(_backIden && _backIden != UIBackgroundTaskInvalid){
        [[UIApplication sharedApplication] endBackgroundTask:_backIden];
        [self setBackIden:UIBackgroundTaskInvalid];
    }
}

#pragma mark - getter/setter methods
- (BOOL)isTiming {
    return [self totalTime] > 0;
}

- (NSTimer *)timer {
    return objc_getAssociatedObject(self, _cmd);
}
- (void)setTimer:(NSTimer *)timer {
    objc_setAssociatedObject(self, @selector(timer), timer, OBJC_ASSOCIATION_RETAIN);
}

- (NSUInteger)totalTime {
    NSNumber *totalTimeNum = objc_getAssociatedObject(self, _cmd);
    return [totalTimeNum unsignedIntegerValue];
}
- (void)setTotalTime:(NSUInteger)totalTime {
    NSNumber *totalTimeNum = [NSNumber numberWithUnsignedInteger:totalTime];
    objc_setAssociatedObject(self, @selector(totalTime), totalTimeNum, OBJC_ASSOCIATION_RETAIN);
}

- (TimerActionBlock)actionBlock {
    return objc_getAssociatedObject(self, _cmd);
}
- (void)setActionBlock:(TimerActionBlock)actionBlock {
    objc_setAssociatedObject(self, @selector(actionBlock), actionBlock, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (TimerCompleteBlock)completeBlock {
    return objc_getAssociatedObject(self, _cmd);
}
- (void)setCompleteBlock:(TimerCompleteBlock)completeBlock {
    objc_setAssociatedObject(self, @selector(completeBlock), completeBlock, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (UIBackgroundTaskIdentifier)backIden {
    NSNumber *backIdenNum = objc_getAssociatedObject(self, _cmd);
    return [backIdenNum unsignedIntegerValue];
}
- (void)setBackIden:(UIBackgroundTaskIdentifier)backIden {
    NSNumber *backIdenNum = [NSNumber numberWithUnsignedInteger:backIden];
    objc_setAssociatedObject(self, @selector(backIden), backIdenNum, OBJC_ASSOCIATION_RETAIN);
}

- (TYProxy *)proxy {
    TYProxy *_proxy = objc_getAssociatedObject(self, _cmd);
    if(!_proxy) { _proxy = [TYProxy proxyWithTarget:self];}
    [self setProxy:_proxy];
    return _proxy;
}
- (void)setProxy:(TYProxy *)proxy {
    objc_setAssociatedObject(self, @selector(proxy), proxy, OBJC_ASSOCIATION_RETAIN);
}

@end
