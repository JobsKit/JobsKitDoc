//
//  NSBundle+Quick.m
//  Quick
//
//  Created by Corin on 2021/3/7.
//

#import "NSBundle+Quick.h"

@implementation NSBundle (Quick)

- (NSString *)qk_pathForFileName:(NSString *)fileName ofType:(NSString * _Nullable)type {
    if (fileName.length == 0) {
        return nil;
    }
    NSArray *pathComponents = [[fileName lastPathComponent] componentsSeparatedByString:@"."];
    
    // AAA.type
    if (pathComponents.count == 2) {
        if (type.length > 0) {
            return [self pathForResource:pathComponents.firstObject ofType:type];
        } else {
            return [self pathForResource:pathComponents.firstObject ofType:pathComponents.lastObject];
        }
    } else if (pathComponents.count == 1) {
        return [self pathForResource:pathComponents.firstObject ofType:type];
    }
    return nil;
}

@end
