//
//  NSBundle+Quick.h
//  Quick
//
//  Created by Corin on 2021/3/7.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSBundle (Quick)

- (NSString *)qk_pathForFileName:(NSString *)fileName ofType:(NSString * _Nullable)type;

@end

NS_ASSUME_NONNULL_END
