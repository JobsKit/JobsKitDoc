//
//  NSDate+TYExtension.h
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (TYExtension)

/**
 * 获取日、月、年、小时、分钟、秒
 */
- (NSUInteger)ty_day;
- (NSUInteger)ty_month;
- (NSUInteger)ty_year;
- (NSUInteger)ty_hour;
- (NSUInteger)ty_minute;
- (NSUInteger)ty_second;
+ (NSUInteger)ty_day:(NSDate *)date;
+ (NSUInteger)ty_month:(NSDate *)date;
+ (NSUInteger)ty_year:(NSDate *)date;
+ (NSUInteger)ty_hour:(NSDate *)date;
+ (NSUInteger)ty_minute:(NSDate *)date;
+ (NSUInteger)ty_second:(NSDate *)date;

/**
 * 获取一年中的总天数
 */
- (NSUInteger)ty_daysInYear;
+ (NSUInteger)ty_daysInYear:(NSDate *)date;

/**
 * 判断是否是润年
 * @return YES表示润年，NO表示平年
 */
- (BOOL)ty_isLeapYear;
+ (BOOL)ty_isLeapYear:(NSDate *)date;

/**
 * 获取该日期是该年的第几周
 */
- (NSUInteger)ty_weekOfYear;
+ (NSUInteger)ty_weekOfYear:(NSDate *)date;

/**
 * 获取格式化为YYYY-MM-dd格式的日期字符串(##有坑：返回的是 2019-12-1 格式##)
 */
- (NSString *)ty_formatYMD;
+ (NSString *)ty_formatYMD:(NSDate *)date;

/**
 * 返回当前月一共有几周(可能为4,5,6)
 */
- (NSUInteger)ty_weeksOfMonth;
+ (NSUInteger)ty_weeksOfMonth:(NSDate *)date;

/**
 * 获取该月的第一天的日期
 */
- (NSDate *)ty_begindayOfMonth;
+ (NSDate *)ty_begindayOfMonth:(NSDate *)date;

/**
 * 获取该月的最后一天的日期
 */
- (NSDate *)ty_lastdayOfMonth;
+ (NSDate *)ty_lastdayOfMonth:(NSDate *)date;

/**
 * 返回day天后的日期(若day为负数,则为|day|天前的日期)
 */
- (NSDate *)ty_dateAfterDay:(NSUInteger)day;
+ (NSDate *)ty_dateAfterDate:(NSDate *)date day:(NSInteger)day;

/**
 * 返回day天后的日期(若day为负数,则为|day|天前的日期)
 */
- (NSDate *)ty_dateAfterMonth:(NSUInteger)month;
+ (NSDate *)ty_dateAfterDate:(NSDate *)date month:(NSInteger)month;

/**
 * 返回numYears年后的日期
 */
- (NSDate *)ty_offsetYears:(int)numYears;
+ (NSDate *)ty_offsetYears:(int)numYears fromDate:(NSDate *)fromDate;

/**
 * 返回numMonths月后的日期
 */
- (NSDate *)ty_offsetMonths:(int)numMonths;
+ (NSDate *)ty_offsetMonths:(int)numMonths fromDate:(NSDate *)fromDate;

/**
 * 返回numDays天后的日期
 */
- (NSDate *)ty_offsetDays:(int)numDays;
+ (NSDate *)ty_offsetDays:(int)numDays fromDate:(NSDate *)fromDate;

/**
 * 返回numHours小时后的日期
 */
- (NSDate *)ty_offsetHours:(int)hours;
+ (NSDate *)ty_offsetHours:(int)numHours fromDate:(NSDate *)fromDate;

/**
 * 距离该日期前几天
 */
- (NSUInteger)ty_daysAgo;
+ (NSUInteger)ty_daysAgo:(NSDate *)date;

/**
 *  获取星期几
 *
 *  @return Return weekday number
 *  [1 - Sunday]
 *  [2 - Monday]
 *  [3 - Tuerday]
 *  [4 - Wednesday]
 *  [5 - Thursday]
 *  [6 - Friday]
 *  [7 - Saturday]
 */
- (NSInteger)ty_weekday;
+ (NSInteger)ty_weekday:(NSDate *)date;

/**
 *  获取星期几(名称)
 *
 *  @return Return weekday as a localized string
 *  [1 - Sunday]
 *  [2 - Monday]
 *  [3 - Tuerday]
 *  [4 - Wednesday]
 *  [5 - Thursday]
 *  [6 - Friday]
 *  [7 - Saturday]
 */
- (NSString *)ty_dayFromWeekday;
+ (NSString *)ty_dayFromWeekday:(NSDate *)date;

/**
 *  日期是否相等
 *
 *  @param anotherDate The another date to compare as NSDate
 *  @return Return YES if is same day, NO if not
 */
- (BOOL)ty_isSameDay:(NSDate *)anotherDate;

/**
 *  是否是今天
 *
 *  @return Return if self is today
 */
- (BOOL)ty_isToday;

/**
 *  Add days to self
 *
 *  @param days The number of days to add
 *  @return Return self by adding the gived days number
 */
- (NSDate *)ty_dateByAddingDays:(NSUInteger)days;

/**
 *  Get the month as a localized string from the given month number
 *
 *  @param month The month to be converted in string
 *  [1 - January]
 *  [2 - February]
 *  [3 - March]
 *  [4 - April]
 *  [5 - May]
 *  [6 - June]
 *  [7 - July]
 *  [8 - August]
 *  [9 - September]
 *  [10 - October]
 *  [11 - November]
 *  [12 - December]
 *
 *  @return Return the given month as a localized string
 */
+ (NSString *)ty_monthWithMonthNumber:(NSInteger)month;

/**
 * 根据日期返回字符串
 */
+ (NSString *)ty_stringWithDate:(NSDate *)date format:(NSString *)format;
- (NSString *)ty_stringWithFormat:(NSString *)format;
+ (NSDate *)ty_dateWithString:(NSString *)string format:(NSString *)format;

/**
 * 获取指定月份的天数
 */
- (NSUInteger)ty_daysInMonth:(NSUInteger)month;
+ (NSUInteger)ty_daysInMonth:(NSDate *)date month:(NSUInteger)month;

/**
 * 获取当前月份的天数
 */
- (NSUInteger)ty_daysInMonth;
+ (NSUInteger)ty_daysInMonth:(NSDate *)date;

/**
 * 返回x分钟前/x小时前/昨天/x天前/x个月前/x年前
 */
- (NSString *)ty_timeInfo;
+ (NSString *)ty_timeInfoWithDate:(NSDate *)date;
+ (NSString *)ty_timeInfoWithDateString:(NSString *)dateString;

/**
 * 分别获取yyyy-MM-dd/HH:mm:ss/yyyy-MM-dd HH:mm:ss格式的字符串
 */
- (NSString *)ty_ymdFormat;
- (NSString *)ty_hmsFormat;
- (NSString *)ty_ymdHmsFormat;
+ (NSString *)ty_ymdFormat;
+ (NSString *)ty_hmsFormat;
+ (NSString *)ty_ymdHmsFormat;
@end
