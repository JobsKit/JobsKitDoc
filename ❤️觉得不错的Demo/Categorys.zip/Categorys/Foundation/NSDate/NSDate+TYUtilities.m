//
//  NSDate+TYUtilities.m
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "NSDate+TYUtilities.h"
#import <UIKit/UIKit.h>
#import "TYFNetworkTimeManager.h"

#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_8_0
#define TY_NSDATE_UTILITIES_COMPONENT_FLAGS \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Wdeprecated-declarations\"") \
({ \
     unsigned components;\
    if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f){ \
        components = (NSYearCalendarUnit| NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekCalendarUnit |  NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit | NSWeekdayCalendarUnit | NSWeekdayOrdinalCalendarUnit); \
    }else{ \
        components = (NSYearCalendarUnit| NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit | NSWeekdayCalendarUnit | NSWeekdayOrdinalCalendarUnit); \
    } \
    components; \
})\
_Pragma("clang diagnostic pop") \

#else
#define TY_NSDATE_UTILITIES_COMPONENT_FLAGS \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Wdeprecated-declarations\"") \
({\
     unsigned components = (NSYearCalendarUnit| NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit | NSWeekdayCalendarUnit | NSWeekdayOrdinalCalendarUnit); \
    components; \
})\
_Pragma("clang diagnostic pop") \

#endif

@implementation NSDate (Utilities)

// Courtesy of Lukasz Margielewski
// Updated via Holger Haenisch
+ (NSCalendar *) ty_currentCalendar
{
    static NSCalendar *sharedCalendar = nil;
    if (!sharedCalendar)
        sharedCalendar = [NSCalendar autoupdatingCurrentCalendar];
    return sharedCalendar;
}

#pragma mark - Relative Dates

+ (NSDate *)ty_dateWithDaysFromNow: (NSInteger) days
{
    return [[NSDate verifyFromBaiduOffsetDate] ty_dateByAddingDays:days];
}

+ (NSDate *)verifyFromBaiduOffsetDate
{
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:TYFNetworkTimeManager.manager.timestamp];
    return date;
}

+ (NSDate *)ty_dateWithDaysBeforeNow: (NSInteger) days
{
    // Thanks, Jim Morrison
    return [[NSDate verifyFromBaiduOffsetDate] ty_dateBySubtractingDays:days];
}

+ (NSDate *) ty_dateTomorrow
{
    return [NSDate ty_dateWithDaysFromNow:1];
}

+ (NSDate *) ty_dateYesterday
{
    return [NSDate ty_dateWithDaysBeforeNow:1];
}

+ (NSDate *) ty_dateWithHoursFromNow: (NSInteger) dHours
{
    NSTimeInterval aTimeInterval = [[NSDate verifyFromBaiduOffsetDate] timeIntervalSinceReferenceDate] + TY_D_HOUR * dHours;
    NSDate *newDate = [NSDate dateWithTimeIntervalSinceReferenceDate:aTimeInterval];
    return newDate;
}

+ (NSDate *) ty_dateWithHoursBeforeNow: (NSInteger) dHours
{
    NSTimeInterval aTimeInterval = [[NSDate verifyFromBaiduOffsetDate] timeIntervalSinceReferenceDate] - TY_D_HOUR * dHours;
    NSDate *newDate = [NSDate dateWithTimeIntervalSinceReferenceDate:aTimeInterval];
    return newDate;
}

+ (NSDate *) ty_dateWithMinutesFromNow: (NSInteger) dMinutes
{
    NSTimeInterval aTimeInterval = [[NSDate verifyFromBaiduOffsetDate] timeIntervalSinceReferenceDate] + TY_D_MINUTE * dMinutes;
    NSDate *newDate = [NSDate dateWithTimeIntervalSinceReferenceDate:aTimeInterval];
    return newDate;
}

+ (NSDate *) ty_dateWithMinutesBeforeNow: (NSInteger) dMinutes
{
    NSTimeInterval aTimeInterval = [[NSDate verifyFromBaiduOffsetDate] timeIntervalSinceReferenceDate] - TY_D_MINUTE * dMinutes;
    NSDate *newDate = [NSDate dateWithTimeIntervalSinceReferenceDate:aTimeInterval];
    return newDate;
}

#pragma mark - String Properties
- (NSString *) ty_stringWithFormat: (NSString *) format
{
    NSCalendar *initCalendar = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateFormatter *formatter = [NSDateFormatter new];
    [formatter setCalendar:initCalendar];
    //    formatter.locale = [NSLocale currentLocale]; // Necessary?
    formatter.dateFormat = format;
    
    return [formatter stringFromDate:self];
}

- (NSString *) ty_stringWithDateStyle: (NSDateFormatterStyle) dateStyle timeStyle: (NSDateFormatterStyle) timeStyle
{
    NSCalendar *initCalendar = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateFormatter *formatter = [NSDateFormatter new];
    [formatter setCalendar:initCalendar];
    formatter.dateStyle = dateStyle;
    formatter.timeStyle = timeStyle;
    //    formatter.locale = [NSLocale currentLocale]; // Necessary?
    return [formatter stringFromDate:self];
}

- (NSString *) ty_shortString
{
    return [self ty_stringWithDateStyle:NSDateFormatterShortStyle timeStyle:NSDateFormatterShortStyle];
}

- (NSString *) ty_shortTimeString
{
    return [self ty_stringWithDateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterShortStyle];
}

- (NSString *) ty_shortDateString
{
    return [self ty_stringWithDateStyle:NSDateFormatterShortStyle timeStyle:NSDateFormatterNoStyle];
}

- (NSString *) ty_mediumString
{
    return [self ty_stringWithDateStyle:NSDateFormatterMediumStyle timeStyle:NSDateFormatterMediumStyle ];
}

- (NSString *) ty_mediumTimeString
{
    return [self ty_stringWithDateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterMediumStyle ];
}

- (NSString *) ty_mediumDateString
{
    return [self ty_stringWithDateStyle:NSDateFormatterMediumStyle  timeStyle:NSDateFormatterNoStyle];
}

- (NSString *) ty_longString
{
    return [self ty_stringWithDateStyle:NSDateFormatterLongStyle timeStyle:NSDateFormatterLongStyle ];
}

- (NSString *) ty_longTimeString
{
    return [self ty_stringWithDateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterLongStyle ];
}

- (NSString *) ty_longDateString
{
    return [self ty_stringWithDateStyle:NSDateFormatterLongStyle  timeStyle:NSDateFormatterNoStyle];
}

#pragma mark - Comparing Dates

- (BOOL) ty_isEqualToDateIgnoringTime: (NSDate *) aDate
{
    NSDateComponents *components1 = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];
    NSDateComponents *components2 = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:aDate];
    return ((components1.year == components2.year) &&
            (components1.month == components2.month) &&
            (components1.day == components2.day));
}

- (BOOL) ty_ty_isToday
{
    return [self ty_isEqualToDateIgnoringTime:[NSDate verifyFromBaiduOffsetDate]];
}

- (BOOL) ty_isTomorrow
{
    return [self ty_isEqualToDateIgnoringTime:[NSDate ty_dateTomorrow]];
}

- (BOOL) ty_isYesterday
{
    return [self ty_isEqualToDateIgnoringTime:[NSDate ty_dateYesterday]];
}

// This hard codes the assumption that a week is 7 days
- (BOOL)ty_isSameWeekAsDate: (NSDate *) aDate
{
    NSDateComponents *components1 = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];
    NSDateComponents *components2 = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:aDate];

    // Must be same week. 12/31 and 1/1 will both be week "1" if they are in the same week
    if (components1.weekOfYear != components2.weekOfYear) return NO;
    
    // Must have a time interval under 1 week. Thanks @aclark
    return (fabs([self timeIntervalSinceDate:aDate]) < TY_D_WEEK);

}

- (BOOL) ty_isThisWeek
{
    return [self ty_isSameWeekAsDate:[NSDate verifyFromBaiduOffsetDate]];
}

- (BOOL) ty_isNextWeek
{
    NSTimeInterval aTimeInterval = [[NSDate verifyFromBaiduOffsetDate] timeIntervalSinceReferenceDate] + TY_D_WEEK;
    NSDate *newDate = [NSDate dateWithTimeIntervalSinceReferenceDate:aTimeInterval];
    return [self ty_isSameWeekAsDate:newDate];
}

- (BOOL) ty_isLastWeek
{
    NSTimeInterval aTimeInterval = [[NSDate verifyFromBaiduOffsetDate] timeIntervalSinceReferenceDate] - TY_D_WEEK;
    NSDate *newDate = [NSDate dateWithTimeIntervalSinceReferenceDate:aTimeInterval];
    return [self ty_isSameWeekAsDate:newDate];
}

// Thanks, mspasov
- (BOOL) ty_isSameMonthAsDate: (NSDate *) aDate
{
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_8_0
    NSDateComponents *components1;
    NSDateComponents *components2;
    if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f){
        components1 = [[NSDate ty_currentCalendar] components:NSCalendarUnitYear | NSCalendarUnitMonth fromDate:self];
        components2 = [[NSDate ty_currentCalendar] components:NSCalendarUnitYear | NSCalendarUnitMonth fromDate:aDate];
    }else{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        components1 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:self];
        components2 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:aDate];
#pragma clang diagnostic pop
    }
#else
    NSDateComponents *components1 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:self];
    NSDateComponents *components2 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:aDate];
#endif
    
    return ((components1.month == components2.month) &&
            (components1.year == components2.year));
}

- (BOOL) ty_isThisMonth
{
    return [self ty_isSameMonthAsDate:[NSDate verifyFromBaiduOffsetDate]];
}

// Thanks Marcin Krzyzanowski, also for adding/subtracting years and months
- (BOOL) ty_isLastMonth
{
    return [self ty_isSameMonthAsDate:[[NSDate verifyFromBaiduOffsetDate] ty_dateBySubtractingMonths:1]];
}

- (BOOL) ty_isNextMonth
{
    return [self ty_isSameMonthAsDate:[[NSDate verifyFromBaiduOffsetDate] ty_dateByAddingMonths:1]];
}

- (BOOL) ty_isSameYearAsDate: (NSDate *) aDate
{
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_8_0
    NSDateComponents *components1;
    NSDateComponents *components2;
    if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f){
        components1 = [[NSDate ty_currentCalendar] components:NSCalendarUnitYear fromDate:self];
        components2 = [[NSDate ty_currentCalendar] components:NSCalendarUnitYear fromDate:aDate];
    }else{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        components1 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit fromDate:self];
        components2 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit  fromDate:aDate];
#pragma clang diagnostic pop
    }
#else
    NSDateComponents *components1 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:self];
    NSDateComponents *components2 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit | NSMonthCalendarUnit fromDate:aDate];
#endif
    return (components1.year == components2.year);
}

- (BOOL) ty_isThisYear
{
    // Thanks, baspellis
    return [self ty_isSameYearAsDate:[NSDate verifyFromBaiduOffsetDate]];
}

- (BOOL) ty_isNextYear
{
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_8_0
    NSDateComponents *components1;
    NSDateComponents *components2;
    if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f){
        components1 = [[NSDate ty_currentCalendar] components:NSCalendarUnitYear fromDate:self];
        components2 = [[NSDate ty_currentCalendar] components:NSCalendarUnitYear fromDate:[NSDate verifyFromBaiduOffsetDate]];
    }else{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        components1 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit fromDate:self];
        components2 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit  fromDate:[NSDate verifyFromBaiduOffsetDate]];
#pragma clang diagnostic pop
    }
#else
    NSDateComponents *components1 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit fromDate:self];
    NSDateComponents *components2 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit fromDate:[NSDate verifyFromBaiduOffsetDate]];
#endif
    
    return (components1.year == (components2.year + 1));
}

- (BOOL) ty_isLastYear
{
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_8_0
    NSDateComponents *components1;
    NSDateComponents *components2;
    if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f){
        components1 = [[NSDate ty_currentCalendar] components:NSCalendarUnitYear fromDate:self];
        components2 = [[NSDate ty_currentCalendar] components:NSCalendarUnitYear fromDate:[NSDate verifyFromBaiduOffsetDate]];
    }else{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        components1 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit fromDate:self];
        components2 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit  fromDate:[NSDate verifyFromBaiduOffsetDate]];
#pragma clang diagnostic pop
    }
#else
    NSDateComponents *components1 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit fromDate:self];
    NSDateComponents *components2 = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit fromDate:[NSDate verifyFromBaiduOffsetDate]];
#endif
    return (components1.year == (components2.year - 1));
}

- (BOOL) ty_isEarlierThanDate: (NSDate *) aDate
{
    return ([self compare:aDate] == NSOrderedAscending);
}

- (BOOL) ty_isLaterThanDate: (NSDate *) aDate
{
    return ([self compare:aDate] == NSOrderedDescending);
}

// Thanks, markrickert
- (BOOL) ty_isInFuture
{
    return ([self ty_isLaterThanDate:[NSDate verifyFromBaiduOffsetDate]]);
}

// Thanks, markrickert
- (BOOL) ty_isInPast
{
    return ([self ty_isEarlierThanDate:[NSDate verifyFromBaiduOffsetDate]]);
}


#pragma mark - Roles
- (BOOL) ty_isTypicallyWeekend
{
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_8_0
    NSDateComponents *components;
    if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f){
        components = [[NSDate ty_currentCalendar] components:NSCalendarUnitWeekday | NSCalendarUnitMonth fromDate:self];
    }else{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        components = [[NSDate ty_currentCalendar] components:NSWeekdayCalendarUnit fromDate:self];
#pragma clang diagnostic pop
    }
#else
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:NSWeekdayCalendarUnit fromDate:self];
#endif
    if ((components.weekday == 1) ||
        (components.weekday == 7))
        return YES;
    return NO;
}

- (BOOL) ty_isTypicallyWorkday
{
    return ![self ty_isTypicallyWeekend];
}

#pragma mark - Adjusting Dates

// Thaks, rsjohnson
- (NSDate *) ty_dateByAddingYears: (NSInteger) dYears
{
    NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
    [dateComponents setYear:dYears];
    NSDate *newDate = [[NSCalendar currentCalendar] dateByAddingComponents:dateComponents toDate:self options:0];
    return newDate;
}

- (NSDate *) ty_dateBySubtractingYears: (NSInteger) dYears
{
    return [self ty_dateByAddingYears:-dYears];
}

- (NSDate *) ty_dateByAddingMonths: (NSInteger) dMonths
{
    NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
    [dateComponents setMonth:dMonths];
    NSDate *newDate = [[NSCalendar currentCalendar] dateByAddingComponents:dateComponents toDate:self options:0];
    return newDate;
}

- (NSDate *) ty_dateBySubtractingMonths: (NSInteger) dMonths
{
    return [self ty_dateByAddingMonths:-dMonths];
}

// Courtesy of dedan who mentions issues with Daylight Savings
- (NSDate *) ty_dateByAddingDays: (NSInteger) dDays
{
    NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
    [dateComponents setDay:dDays];
    NSDate *newDate = [[NSCalendar currentCalendar] dateByAddingComponents:dateComponents toDate:self options:0];
    return newDate;
}

- (NSDate *) ty_dateBySubtractingDays: (NSInteger) dDays
{
    return [self ty_dateByAddingDays: (dDays * -1)];
}

- (NSDate *) ty_dateByAddingHours: (NSInteger) dHours
{
    NSTimeInterval aTimeInterval = [self timeIntervalSinceReferenceDate] + TY_D_HOUR * dHours;
    NSDate *newDate = [NSDate dateWithTimeIntervalSinceReferenceDate:aTimeInterval];
    return newDate;
}

- (NSDate *) ty_dateBySubtractingHours: (NSInteger) dHours
{
    return [self ty_dateByAddingHours: (dHours * -1)];
}

- (NSDate *) ty_dateByAddingMinutes: (NSInteger) dMinutes
{
    NSTimeInterval aTimeInterval = [self timeIntervalSinceReferenceDate] + TY_D_MINUTE * dMinutes;
    NSDate *newDate = [NSDate dateWithTimeIntervalSinceReferenceDate:aTimeInterval];
    return newDate;
}

- (NSDate *) ty_dateBySubtractingMinutes: (NSInteger) dMinutes
{
    return [self ty_dateByAddingMinutes: (dMinutes * -1)];
}

- (NSDateComponents *) ty_componentsWithOffsetFromDate: (NSDate *) aDate
{
    NSDateComponents *dTime = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:aDate toDate:self options:0];
    return dTime;
}

#pragma mark - Extremes

- (NSDate *) ty_dateAtStartOfDay
{
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];
    components.hour = 0;
    components.minute = 0;
    components.second = 0;
    return [[NSDate ty_currentCalendar] dateFromComponents:components];
}

// Thanks gsempe & mteece
- (NSDate *) ty_dateAtEndOfDay
{
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];

    components.hour = 23; // Thanks Aleksey Kononov
    components.minute = 59;
    components.second = 59;
    return [[NSDate ty_currentCalendar] dateFromComponents:components];
}

#pragma mark - Retrieving Intervals

- (NSInteger) ty_minutesAfterDate: (NSDate *) aDate
{
    NSTimeInterval ti = [self timeIntervalSinceDate:aDate];
    return (NSInteger) (ti / TY_D_MINUTE);
}

- (NSInteger) ty_secondsAfterDate: (NSDate *) aDate
{
    return (NSInteger) [self timeIntervalSinceDate:aDate];
}


- (NSInteger) ty_minutesBeforeDate: (NSDate *) aDate
{
    NSTimeInterval ti = [aDate timeIntervalSinceDate:self];
    return (NSInteger) (ti / TY_D_MINUTE);
}

- (NSInteger) ty_hoursAfterDate: (NSDate *) aDate
{
    NSTimeInterval ti = [self timeIntervalSinceDate:aDate];
    return (NSInteger) (ti / TY_D_HOUR);
}

- (NSInteger) ty_hoursBeforeDate: (NSDate *) aDate
{
    NSTimeInterval ti = [aDate timeIntervalSinceDate:self];
    return (NSInteger) (ti / TY_D_HOUR);
}

- (NSInteger) ty_daysAfterDate: (NSDate *) aDate
{
    NSTimeInterval ti = [self timeIntervalSinceDate:aDate];
    return (NSInteger) (ti / TY_D_DAY);
}

- (NSInteger) ty_daysBeforeDate: (NSDate *) aDate
{
    NSTimeInterval ti = [aDate timeIntervalSinceDate:self];
    return (NSInteger) (ti / TY_D_DAY);
}

// Thanks, dmitrydims
// I have not yet thoroughly tested this
- (NSInteger)ty_distanceDaysToDate:(NSDate *)anotherDate
{
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_8_0
    NSDateComponents *components;
    if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f){
        components = [[NSDate ty_currentCalendar] components:NSCalendarUnitDay fromDate:self toDate:anotherDate options:0];
    }else{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        components = [[NSDate ty_currentCalendar] components:NSDayCalendarUnit fromDate:self toDate:anotherDate options:0];
#pragma clang diagnostic pop
    }
#else
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:NSDayCalendarUnit fromDate:self toDate:anotherDate options:0]
#endif
    
    return components.day;
}
- (NSInteger)ty_distanceMonthsToDate:(NSDate *)anotherDate{
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_8_0
    NSDateComponents *components;
    if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f){
        components = [[NSDate ty_currentCalendar] components:NSCalendarUnitMonth fromDate:self toDate:anotherDate options:0];
    }else{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        components = [[NSDate ty_currentCalendar] components:NSMonthCalendarUnit fromDate:self toDate:anotherDate options:0];
#pragma clang diagnostic pop
    }
#else
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:NSMonthCalendarUnit fromDate:self toDate:anotherDate options:0]
#endif
    return components.month;
}
- (NSInteger)ty_distanceYearsToDate:(NSDate *)anotherDate{
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_8_0
    NSDateComponents *components;
    if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f){
        components = [[NSDate ty_currentCalendar] components:NSCalendarUnitYear fromDate:self toDate:anotherDate options:0];
    }else{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        components = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit fromDate:self toDate:anotherDate options:0];
#pragma clang diagnostic pop
    }
#else
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:NSYearCalendarUnit fromDate:self toDate:anotherDate options:0]
#endif
    return components.year;
}
#pragma mark Decomposing Dates
- (NSInteger)ty_nearestHour
{
    NSTimeInterval aTimeInterval = [[NSDate verifyFromBaiduOffsetDate] timeIntervalSinceReferenceDate] + TY_D_MINUTE * 30;
    NSDate *newDate = [NSDate dateWithTimeIntervalSinceReferenceDate:aTimeInterval];
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_8_0
    NSDateComponents *components;
    if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0f){
        components = [[NSDate ty_currentCalendar] components:NSCalendarUnitHour fromDate:newDate];
    }else{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        components = [[NSDate ty_currentCalendar] components:NSHourCalendarUnit fromDate:newDate];
#pragma clang diagnostic pop
    }
#else
    NSDateComponents *components =  [[NSDate ty_currentCalendar] components:NSHourCalendarUnit fromDate:newDate];
#endif
    return components.hour;
}
- (NSInteger) ty_hour
{
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];
    return components.hour;
}

- (NSInteger) ty_minute
{
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];
    return components.minute;
}

- (NSInteger) ty_seconds
{
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];
    return components.second;
}

- (NSInteger) ty_day
{
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];
    return components.day;
}

- (NSInteger) ty_month
{
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];
    return components.month;
}

- (NSInteger) ty_week
{
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];
    return components.weekOfMonth;
}

- (NSInteger) ty_weekday
{
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];
    return components.weekday;
}

- (NSInteger) ty_nthWeekday // e.g. 2nd Tuesday of the month is 2
{
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];
    return components.weekdayOrdinal;
}

- (NSInteger) ty_year
{
    NSDateComponents *components = [[NSDate ty_currentCalendar] components:TY_NSDATE_UTILITIES_COMPONENT_FLAGS fromDate:self];
    return components.year;
}
@end
