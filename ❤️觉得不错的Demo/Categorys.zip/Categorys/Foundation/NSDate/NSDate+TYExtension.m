//
//  NSDate+TYExtension.m
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "NSDate+TYExtension.h"

@implementation NSDate (TYExtension)

- (NSUInteger)ty_day {
    return [NSDate ty_day:self];
}

- (NSUInteger)ty_month {
    return [NSDate ty_month:self];
}

- (NSUInteger)ty_year {
    return [NSDate ty_year:self];
}

- (NSUInteger)ty_hour {
    return [NSDate ty_hour:self];
}

- (NSUInteger)ty_minute {
    return [NSDate ty_minute:self];
}

- (NSUInteger)ty_second {
    return [NSDate ty_second:self];
}

+ (NSUInteger)ty_day:(NSDate *)date {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_8_0
    // NSDayCalendarUnit
    NSDateComponents *dayComponents = [calendar components:(NSCalendarUnitDay) fromDate:date];
#else
    NSDateComponents *dayComponents = [calendar components:(NSDayCalendarUnit) fromDate:date];
#endif
    
    return [dayComponents day];
}

+ (NSUInteger)ty_month:(NSDate *)date {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_8_0
    // NSDayCalendarUnit
    NSDateComponents *dayComponents = [calendar components:(NSCalendarUnitMonth) fromDate:date];
#else
    NSDateComponents *dayComponents = [calendar components:(NSMonthCalendarUnit) fromDate:date];
#endif
    
    return [dayComponents month];
}

+ (NSUInteger)ty_year:(NSDate *)date {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_8_0
    // NSDayCalendarUnit
    NSDateComponents *dayComponents = [calendar components:(NSCalendarUnitYear) fromDate:date];
#else
    NSDateComponents *dayComponents = [calendar components:(NSYearCalendarUnit) fromDate:date];
#endif
    
    return [dayComponents year];
}

+ (NSUInteger)ty_hour:(NSDate *)date {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_8_0
    // NSDayCalendarUnit
    NSDateComponents *dayComponents = [calendar components:(NSCalendarUnitHour) fromDate:date];
#else
    NSDateComponents *dayComponents = [calendar components:(NSHourCalendarUnit) fromDate:date];
#endif
    
    return [dayComponents hour];
}

+ (NSUInteger)ty_minute:(NSDate *)date {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_8_0
    // NSDayCalendarUnit
    NSDateComponents *dayComponents = [calendar components:(NSCalendarUnitMinute) fromDate:date];
#else
    NSDateComponents *dayComponents = [calendar components:(NSMinuteCalendarUnit) fromDate:date];
#endif
    
    return [dayComponents minute];
}

+ (NSUInteger)ty_second:(NSDate *)date {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_8_0
    // NSDayCalendarUnit
    NSDateComponents *dayComponents = [calendar components:(NSCalendarUnitSecond) fromDate:date];
#else
    NSDateComponents *dayComponents = [calendar components:(NSSecondCalendarUnit) fromDate:date];
#endif
    
    return [dayComponents second];
}

- (NSUInteger)ty_daysInYear {
    return [NSDate ty_daysInYear:self];
}

+ (NSUInteger)ty_daysInYear:(NSDate *)date {
    return [self ty_isLeapYear:date] ? 366 : 365;
}

- (BOOL)ty_isLeapYear {
    return [NSDate ty_isLeapYear:self];
}

+ (BOOL)ty_isLeapYear:(NSDate *)date {
    NSUInteger year = [date ty_year];
    if ((year % 4  == 0 && year % 100 != 0) || year % 400 == 0) {
        return YES;
    }
    return NO;
}

- (NSString *)ty_formatYMD {
    return [NSDate ty_formatYMD:self];
}

+ (NSString *)ty_formatYMD:(NSDate *)date {
    return [NSString stringWithFormat:@"%zd-%zd-%zd",[date ty_year],[date ty_month], [date ty_day]];
}

- (NSUInteger)ty_weeksOfMonth {
    return [NSDate ty_weeksOfMonth:self];
}

+ (NSUInteger)ty_weeksOfMonth:(NSDate *)date {
    return [[date ty_lastdayOfMonth] ty_weekOfYear] - [[date ty_begindayOfMonth] ty_weekOfYear] + 1;
}

- (NSUInteger)ty_weekOfYear {
    return [NSDate ty_weekOfYear:self];
}

+ (NSUInteger)ty_weekOfYear:(NSDate *)date {
    NSUInteger i;
    NSUInteger year = [date ty_year];
    
    //    NSDate *lastdate = [date ty_lastdayOfMonth];
    
    for (i = 1;[[date ty_dateAfterDay:-7 * i] ty_year] == year; i++) {
        
    }
    //    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    //    [dateFormatter setDateFormat:@"'公元前/后:'G  '年份:'u'='yyyy'='yy '季度:'q'='qqq'='qqqq '月份:'M'='MMM'='MMMM '今天是今年第几周:'w '今天是本月第几周:'W  '今天是今天第几天:'D '今天是本月第几天:'d '星期:'c'='ccc'='cccc '上午/下午:'a '小时:'h'='H '分钟:'m '秒:'s '毫秒:'SSS  '这一天已过多少毫秒:'A  '时区名称:'zzzz'='vvvv '时区编号:'Z "];
    //    NSLog(@"%@", [dateFormatter stringFromDate:[NSDate date]]);
    return i;
}

- (NSDate *)ty_dateAfterDay:(NSUInteger)day {
    return [NSDate ty_dateAfterDate:self day:day];
}

+ (NSDate *)ty_dateAfterDate:(NSDate *)date day:(NSInteger)day {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *componentsToAdd = [[NSDateComponents alloc] init];
    [componentsToAdd setDay:day];
    
    NSDate *dateAfterDay = [calendar dateByAddingComponents:componentsToAdd toDate:date options:0];
    
    return dateAfterDay;
}

- (NSDate *)ty_dateAfterMonth:(NSUInteger)month {
    return [NSDate ty_dateAfterDate:self month:month];
}

+ (NSDate *)ty_dateAfterDate:(NSDate *)date month:(NSInteger)month {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *componentsToAdd = [[NSDateComponents alloc] init];
    [componentsToAdd setMonth:month];
    NSDate *dateAfterMonth = [calendar dateByAddingComponents:componentsToAdd toDate:date options:0];
    
    return dateAfterMonth;
}

- (NSDate *)ty_begindayOfMonth {
    return [NSDate ty_begindayOfMonth:self];
}

+ (NSDate *)ty_begindayOfMonth:(NSDate *)date {
    return [self ty_dateAfterDate:date day:-[date ty_day] + 1];
}

- (NSDate *)ty_lastdayOfMonth {
    return [NSDate ty_lastdayOfMonth:self];
}

+ (NSDate *)ty_lastdayOfMonth:(NSDate *)date {
    NSDate *lastDate = [self ty_begindayOfMonth:date];
    return [[lastDate ty_dateAfterMonth:1] ty_dateAfterDay:-1];
}

- (NSUInteger)ty_daysAgo {
    return [NSDate ty_daysAgo:self];
}

+ (NSUInteger)ty_daysAgo:(NSDate *)date {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_8_0
    NSDateComponents *components = [calendar components:(NSCalendarUnitDay)
                                               fromDate:date
                                                 toDate:[NSDate date]
                                                options:0];
#else
    NSDateComponents *components = [calendar components:(NSDayCalendarUnit)
                                               fromDate:date
                                                 toDate:[NSDate date]
                                                options:0];
#endif
    
    return [components day];
}

- (NSInteger)ty_weekday {
    return [NSDate ty_weekday:self];
}

+ (NSInteger)ty_weekday:(NSDate *)date {
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *comps = [gregorian components:(NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear | NSCalendarUnitWeekday) fromDate:date];
    NSInteger weekday = [comps weekday];
    
    return weekday;
}

- (NSString *)ty_dayFromWeekday {
    return [NSDate ty_dayFromWeekday:self];
}

+ (NSString *)ty_dayFromWeekday:(NSDate *)date {
    switch([date ty_weekday]) {
        case 1:
            return @"星期日";
            break;
        case 2:
            return @"星期一";
            break;
        case 3:
            return @"星期二";
            break;
        case 4:
            return @"星期三";
            break;
        case 5:
            return @"星期四";
            break;
        case 6:
            return @"星期五";
            break;
        case 7:
            return @"星期六";
            break;
        default:
            break;
    }
    return @"";
}

- (BOOL)ty_isSameDay:(NSDate *)anotherDate {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *components1 = [calendar components:(NSCalendarUnitYear
                                                          | NSCalendarUnitMonth
                                                          | NSCalendarUnitDay)
                                                fromDate:self];
    NSDateComponents *components2 = [calendar components:(NSCalendarUnitYear
                                                          | NSCalendarUnitMonth
                                                          | NSCalendarUnitDay)
                                                fromDate:anotherDate];
    return ([components1 year] == [components2 year]
            && [components1 month] == [components2 month]
            && [components1 day] == [components2 day]);
}

- (BOOL)ty_isToday {
    return [self ty_isSameDay:[NSDate date]];
}

- (NSDate *)ty_dateByAddingDays:(NSUInteger)days {
    NSDateComponents *c = [[NSDateComponents alloc] init];
    c.day = days;
    return [[NSCalendar currentCalendar] dateByAddingComponents:c toDate:self options:0];
}

/**
 *  Get the month as a localized string from the given month number
 *
 *  @param month The month to be converted in string
 *  [1 - January]
 *  [2 - February]
 *  [3 - March]
 *  [4 - April]
 *  [5 - May]
 *  [6 - June]
 *  [7 - July]
 *  [8 - August]
 *  [9 - September]
 *  [10 - October]
 *  [11 - November]
 *  [12 - December]
 *
 *  @return Return the given month as a localized string
 */
+ (NSString *)ty_monthWithMonthNumber:(NSInteger)month {
    switch(month) {
        case 1:
            return @"January";
            break;
        case 2:
            return @"February";
            break;
        case 3:
            return @"March";
            break;
        case 4:
            return @"April";
            break;
        case 5:
            return @"May";
            break;
        case 6:
            return @"June";
            break;
        case 7:
            return @"July";
            break;
        case 8:
            return @"August";
            break;
        case 9:
            return @"September";
            break;
        case 10:
            return @"October";
            break;
        case 11:
            return @"November";
            break;
        case 12:
            return @"December";
            break;
        default:
            break;
    }
    return @"";
}

+ (NSString *)ty_stringWithDate:(NSDate *)date format:(NSString *)format {
    return [date ty_stringWithFormat:format];
}

- (NSString *)ty_stringWithFormat:(NSString *)format {
    NSCalendar *initCalendar = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
    [outputFormatter setDateFormat:format];
    [outputFormatter setCalendar:initCalendar];
    NSString *retStr = [outputFormatter stringFromDate:self];
    
    return retStr;
}

+ (NSDate *)ty_dateWithString:(NSString *)string format:(NSString *)format {
    NSCalendar *initCalendar = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateFormatter *inputFormatter = [[NSDateFormatter alloc] init];
    [inputFormatter setDateFormat:format];
    [inputFormatter setCalendar:initCalendar];
    NSDate *date = [inputFormatter dateFromString:string];
    
    return date;
}

- (NSUInteger)ty_daysInMonth:(NSUInteger)month {
    return [NSDate ty_daysInMonth:self month:month];
}

+ (NSUInteger)ty_daysInMonth:(NSDate *)date month:(NSUInteger)month {
    switch (month) {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            return 31;
        case 2:
            return [date ty_isLeapYear] ? 29 : 28;
    }
    return 30;
}

- (NSUInteger)ty_daysInMonth {
    return [NSDate ty_daysInMonth:self];
}

+ (NSUInteger)ty_daysInMonth:(NSDate *)date {
    return [self ty_daysInMonth:date month:[date ty_month]];
}

- (NSString *)ty_timeInfo {
    return [NSDate ty_timeInfoWithDate:self];
}

+ (NSString *)ty_timeInfoWithDate:(NSDate *)date {
    return [self ty_timeInfoWithDateString:[self ty_stringWithDate:date format:[self ty_ymdHmsFormat]]];
}

+ (NSString *)ty_timeInfoWithDateString:(NSString *)dateString {
    NSDate *date = [self ty_dateWithString:dateString format:[self ty_ymdHmsFormat]];
    
    NSDate *curDate = [NSDate date];
    NSTimeInterval time = -[date timeIntervalSinceDate:curDate];
    
    int month = (int)([curDate ty_month] - [date ty_month]);
    int year = (int)([curDate ty_year] - [date ty_year]);
    int day = (int)([curDate ty_day] - [date ty_day]);
    
    NSTimeInterval retTime = 1.0;
    if (time < 3600) { // 小于一小时
        retTime = time / 60;
        retTime = retTime <= 0.0 ? 1.0 : retTime;
        //        return [NSString stringWithFormat:@"%.0f分钟前", retTime];
        return retTime < 1.0 ? @"刚刚" : [NSString stringWithFormat:@"%.0f分钟前", retTime];
        
    } else if (time < 3600 * 24) { // 小于一天，也就是今天
        retTime = time / 3600;
        retTime = retTime <= 0.0 ? 1.0 : retTime;
        return [NSString stringWithFormat:@"%.0f小时前", retTime];
    } else if (time < 3600 * 24 * 2) {
        return @"昨天";
    }
    // 第一个条件是同年，且相隔时间在一个月内
    // 第二个条件是隔年，对于隔年，只能是去年12月与今年1月这种情况
    else if ((abs(year) == 0 && abs(month) <= 1)
             || (abs(year) == 1 && [curDate ty_month] == 1 && [date ty_month] == 12)) {
        int retDay = 0;
        if (year == 0) { // 同年
            if (month == 0) { // 同月
                retDay = day;
            }
        }
        
        if (retDay <= 0) {
            // 获取发布日期中，该月有多少天
            int totalDays = (int)[self ty_daysInMonth:date month:[date ty_month]];
            
            // 当前天数 + （发布日期月中的总天数-发布日期月中发布日，即等于距离今天的天数）
            retDay = (int)[curDate ty_day] + (totalDays - (int)[date ty_day]);
        }
        
        return [NSString stringWithFormat:@"%d天前", (abs)(retDay)];
    } else  {
        if (abs(year) <= 1) {
            if (year == 0) { // 同年
                return [NSString stringWithFormat:@"%d个月前", abs(month)];
            }
            
            // 隔年
            int month = (int)[curDate ty_month];
            int preMonth = (int)[date ty_month];
            if (month == 12 && preMonth == 12) {// 隔年，但同月，就作为满一年来计算
                return @"1年前";
            }
            return [NSString stringWithFormat:@"%d个月前", (abs)(12 - preMonth + month)];
        }
        
        return [NSString stringWithFormat:@"%d年前", abs(year)];
    }
    
    return @"1小时前";
}

- (NSString *)ty_ymdFormat {
    return [NSDate ty_ymdFormat];
}

- (NSString *)ty_hmsFormat {
    return [NSDate ty_hmsFormat];
}

- (NSString *)ty_ymdHmsFormat {
    return [NSDate ty_ymdHmsFormat];
}

+ (NSString *)ty_ymdFormat {
    return @"yyyy-MM-dd";
}

+ (NSString *)ty_hmsFormat {
    return @"HH:mm:ss";
}

+ (NSString *)ty_ymdHmsFormat {
    return [NSString stringWithFormat:@"%@ %@", [self ty_ymdFormat], [self ty_hmsFormat]];
}

- (NSDate *)ty_offsetYears:(int)numYears {
    return [NSDate ty_offsetYears:numYears fromDate:self];
}

+ (NSDate *)ty_offsetYears:(int)numYears fromDate:(NSDate *)fromDate {
    if (fromDate == nil) {
        return nil;
    }
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_8_0
    // NSDayCalendarUnit
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
#else
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSGregorianCalendar];
#endif
    
    
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    [offsetComponents setYear:numYears];
    
    return [gregorian dateByAddingComponents:offsetComponents
                                      toDate:fromDate
                                     options:0];
}

- (NSDate *)ty_offsetMonths:(int)numMonths {
    return [NSDate ty_offsetMonths:numMonths fromDate:self];
}

+ (NSDate *)ty_offsetMonths:(int)numMonths fromDate:(NSDate *)fromDate {
    if (fromDate == nil) {
        return nil;
    }
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_8_0
    // NSDayCalendarUnit
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
#else
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSGregorianCalendar];
#endif
    
    
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    [offsetComponents setMonth:numMonths];
    
    return [gregorian dateByAddingComponents:offsetComponents
                                      toDate:fromDate
                                     options:0];
}

- (NSDate *)ty_offsetDays:(int)numDays {
    return [NSDate ty_offsetDays:numDays fromDate:self];
}

+ (NSDate *)ty_offsetDays:(int)numDays fromDate:(NSDate *)fromDate {
    if (fromDate == nil) {
        return nil;
    }
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_8_0
    // NSDayCalendarUnit
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
#else
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSGregorianCalendar];
#endif
    
    
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    [offsetComponents setDay:numDays];
    
    return [gregorian dateByAddingComponents:offsetComponents
                                      toDate:fromDate
                                     options:0];
}

- (NSDate *)ty_offsetHours:(int)hours {
    return [NSDate ty_offsetHours:hours fromDate:self];
}

+ (NSDate *)ty_offsetHours:(int)numHours fromDate:(NSDate *)fromDate {
    if (fromDate == nil) {
        return nil;
    }
    
#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_8_0
    // NSDayCalendarUnit
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
#else
    NSCalendar *gregorian = [[NSCalendar alloc]
                             initWithCalendarIdentifier:NSGregorianCalendar];
#endif
    
    
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    [offsetComponents setHour:numHours];
    
    return [gregorian dateByAddingComponents:offsetComponents
                                      toDate:fromDate
                                     options:0];
}

@end
