//
//  NSNumber+Formatter.h
//  YaboGames
//
//  Created by mannay on 09/03/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSNumber (Formatter)



// 格式化为金额，当前规则无分割
- (NSString *)moneyWithFraction:(NSInteger)fraciton;
// 前面加上‘¥’符号
- (NSString *)rmbMoneyWithFraction:(NSInteger)fraction;
- (CGFloat)ty_floatValue;

@end

NS_ASSUME_NONNULL_END
