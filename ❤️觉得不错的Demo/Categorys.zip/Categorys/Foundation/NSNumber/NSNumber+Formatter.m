//
//  NSNumber+Formatter.m
//  YaboGames
//
//  Created by mannay on 09/03/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "NSNumber+Formatter.h"

@implementation NSNumber (Formatter)

// 格式化为金额，当前规则无分割
- (NSString *)moneyWithFraction:(NSInteger)fraciton
{
    static NSNumberFormatter *s_fmt = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        s_fmt = [NSNumberFormatter new];
        s_fmt.minimumIntegerDigits = 1;
    });
    s_fmt.minimumFractionDigits = MAX(0, fraciton);
    
    return [s_fmt stringFromNumber: self];
}
// 前面加上‘¥’符号
- (NSString *)rmbMoneyWithFraction:(NSInteger)fraction
{
    return [NSString stringWithFormat: @"¥%@", [self moneyWithFraction:fraction]];
}

- (CGFloat)ty_floatValue {
    // 定义一个跟NSString一样的方法，防止定义的是String,实际是number类型的崩溃
    return self.floatValue;
}

@end
