//
//  NSURL+WebpOss.m
//  Pods-TYFPreloadImage_Example
//
//  Created by BWJS-FREDERIC on 2020/10/1.
//

#import "NSURL+WebpOss.h"
#import <objc/runtime.h>

@implementation NSURL(WebpOss)

+ (NSString *)str:(NSString *)urlStr ossParam:(NSString *)oss {
    if ([NSString isEmptySring:urlStr]) {
        return nil;
    }
    if ([urlStr componentsSeparatedByString:@"?"].count == 2) {
        // 已经有参数了
        NSString *paramStr = [urlStr componentsSeparatedByString:@"?"].lastObject;
        if ([paramStr rangeOfString:@"x-oss-process="].location == NSNotFound) {
            urlStr = [NSString stringWithFormat:@"%@&%@",urlStr,oss];
        }else{
            // 有参数，重组参数
            NSString *path = [urlStr componentsSeparatedByString:@"?"].firstObject;
            path = [NSString stringWithFormat:@"%@?%@",path,oss];
            NSArray *params = [paramStr componentsSeparatedByString:@"&"];
            for (NSString *paramStr in params) {
                if ([paramStr rangeOfString:@"x-oss-process="].location == NSNotFound) {
                    path = [NSString stringWithFormat:@"%@&%@",path,paramStr];
                }
            }
            urlStr = path;
        }
    } else {
        // 没有参数
        urlStr = [NSString stringWithFormat:@"%@?%@",urlStr,oss];
    }
    return urlStr;
}

+ (NSURL *)ty_webpOssImageUrl:(NSString *)urlStr changeWebP:(BOOL)changeWebP notScale:(BOOL)notScale size:(CGSize)size{
    if ([NSString isEmptySring:urlStr]) {
        return nil;
    }
    
    if (!changeWebP) {
        return [NSURL URLWithString:urlStr];
    }
    
    if (notScale) {
        NSString *oss = [NSString stringWithFormat:@"x-oss-process=image/format,webp"];
        return [NSURL URLWithString:[self str:urlStr ossParam:oss]];
    }
    
    if (size.width>0 && size.height>0) {
        NSString *oss = [NSString stringWithFormat:@"x-oss-process=image/format,webp/resize,l_%ld,h_%ld",@(size.width).integerValue,@(size.height).integerValue];
        return [NSURL URLWithString:[self str:urlStr ossParam:oss]];
    } else {
        NSString *oss = [NSString stringWithFormat:@"x-oss-process=image/format,webp/quality,Q_80"];
        return [NSURL URLWithString:[self str:urlStr ossParam:oss]];
    }
}

#pragma mark - Getter & Setter
- (void)setTy_notChangeToWebP:(BOOL)ty_notChangeToWebP {
    objc_setAssociatedObject(self,
                             @"ty_notChangeToWebP",
                             [NSNumber numberWithBool:ty_notChangeToWebP],
                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (BOOL)ty_notChangeToWebP {
    NSNumber *val = objc_getAssociatedObject(self, @"ty_notChangeToWebP");
    if (val == nil) {
        return NO;
    }
    return [val boolValue];
}
@end
