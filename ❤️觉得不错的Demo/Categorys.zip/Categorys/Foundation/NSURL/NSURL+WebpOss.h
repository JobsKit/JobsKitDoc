//
//  NSURL+WebpOss.h
//  Pods-TYFPreloadImage_Example
//
//  Created by BWJS-FREDERIC on 2020/10/1.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSURL(WebpOss)
@property (nonatomic, assign) BOOL ty_notChangeToWebP;
+ (NSString *)str:(NSString *)urlStr
         ossParam:(NSString *)oss;

+ (NSURL *)ty_webpOssImageUrl:(NSString *)urlStr
                   changeWebP:(BOOL)changeWebP
                     notScale:(BOOL)notScale
                         size:(CGSize)size;
@end

NS_ASSUME_NONNULL_END
