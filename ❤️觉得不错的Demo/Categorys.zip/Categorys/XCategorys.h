//
//  XCategorys.h
//  XGames
//
//  Created by linker on 10/7/2019.
//  Copyright © 2019 XGames. All rights reserved.
//

#ifndef XCategorys_h
#define XCategorys_h

/// 统一对外暴露 Categorys文件

#import "TYUIKitCategory.h"
#import "FoundationCategory.h"
#import "AmountManager.h"


#endif /* XCategorys_h */
