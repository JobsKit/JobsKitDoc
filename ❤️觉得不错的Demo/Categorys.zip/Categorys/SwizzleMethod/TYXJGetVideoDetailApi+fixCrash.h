//
//  TYXJGetVideoDetailApi+fixCrash.h
//  FirefoxGames
//
//  Created by mac on 2020/1/16.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//



#import "TYXJGetVideoDetailApi.h"

NS_ASSUME_NONNULL_BEGIN

@interface TYXJGetVideoDetailApi (fixCrash)

@end

NS_ASSUME_NONNULL_END
