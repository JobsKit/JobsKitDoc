//
//  TYXJGetVideoApi+fixCrash.m
//  FirefoxGames
//
//  Created by mac on 2020/1/16.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "TYXJGetVideoApi+fixCrash.h"


@implementation TYXJGetVideoApi (fixCrash)

+ (void)load {
    TYFSwizzleMethod([self class], @selector(requestUrl), [self class], @selector(customRequestUrl));
}

- (NSString *)customRequestUrl {
    
    NSString *channel = @"V188";
    NSString *platform = @"BW";
    NSString *type = @"all";
    NSString *user = @"admin";
    
    NSMutableString *strM = [[NSMutableString alloc] init];
    [strM appendString:channel];
    [strM appendString:type];
    NSString *txt = [NSString stringWithFormat:@"%@%@",user,platform];
    NSString *sign1 = [txt ty_md5];
    [strM appendString:sign1];
    NSString *sign = [[NSString stringWithString:strM] ty_md5];
    NSString *url = @"%@/video/api/external/app/getVideoList?channel=%@&platform=%@&type=%@&sign=%@";
    NSString *domain = [NSString stringWithFormat:@"%@://video.83y7n1.com",(TYFSiteManager.manager.localMetaData.ISHttps?@"https":@"http")];
    NSString *cURL = [NSString stringWithFormat:url, domain,channel,platform,type,sign];
    
    return cURL;
//    return [NSString stringWithFormat:@"%@/video/v1/list.txt?type=all", self.xjBaseUrl];
//    return @"/im_video/v3/IMVideo/Oub188AppVideoList";
    
}
@end
