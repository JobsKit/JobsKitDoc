//
//  TYXBetRecord+TYFAmount.m
//  FirefoxGames
//
//  Created by storm on 2020/1/21.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "TYXBetRecord+TYFAmount.h"


@implementation TYXBetRecord (TYFAmount)
+ (void)load {
    TYFSwizzleMethod([self class], @selector(stake), [self class], @selector(ty_stake));
    TYFSwizzleMethod([self class], @selector(winLossMoney), [self class], @selector(ty_winLossMoney));
}

- (NSString *)ty_stake {
    NSString *stakeAmount = [self ty_stake];
    stakeAmount = [stakeAmount stringByReplacingOccurrencesOfString:@"," withString:@""];
    stakeAmount = [stakeAmount stringByReplacingOccurrencesOfString:@"，" withString:@""];
    return stakeAmount;
}

- (NSString *)ty_winLossMoney {
    NSString *winLossMoneyAmount = [self ty_winLossMoney];
    winLossMoneyAmount = [winLossMoneyAmount stringByReplacingOccurrencesOfString:@"," withString:@""];
    winLossMoneyAmount = [winLossMoneyAmount stringByReplacingOccurrencesOfString:@"，" withString:@""];
    return winLossMoneyAmount;
}
@end
