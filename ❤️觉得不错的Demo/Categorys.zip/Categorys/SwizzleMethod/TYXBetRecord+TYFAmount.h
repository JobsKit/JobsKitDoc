//
//  TYXBetRecord+TYFAmount.h
//  FirefoxGames
//
//  Created by storm on 2020/1/21.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "TYXBetRecord.h"

NS_ASSUME_NONNULL_BEGIN

@interface TYXBetRecord (TYFAmount)

@end

NS_ASSUME_NONNULL_END
