//
//  TYIMGetVideoInfoApi+bwVideo.h
//  FirefoxGames
//
//  Created by storm on 2020/1/18.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "TYIMGetVideoInfoApi.h"

NS_ASSUME_NONNULL_BEGIN

@interface TYIMGetVideoInfoApi (bwVideo)

@end

NS_ASSUME_NONNULL_END
