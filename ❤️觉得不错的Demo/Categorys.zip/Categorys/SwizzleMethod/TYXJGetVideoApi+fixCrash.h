//
//  TYXJGetVideoApi+fixCrash.h
//  FirefoxGames
//
//  Created by mac on 2020/1/16.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//



#import "TYXJGetVideoApi.h"

NS_ASSUME_NONNULL_BEGIN

@interface TYXJGetVideoApi (fixCrash)

@end

NS_ASSUME_NONNULL_END
