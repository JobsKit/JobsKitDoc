//
//  TYIMGetVideoApi+bwVideo.h
//  FirefoxGames
//
//  Created by storm on 2020/1/18.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "TYIMGetVideoApi.h"

NS_ASSUME_NONNULL_BEGIN

@interface TYIMGetVideoApi (bwVideo)

@end

NS_ASSUME_NONNULL_END
