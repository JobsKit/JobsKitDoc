//
//  TYIMGetVideoInfoApi+bwVideo.m
//  FirefoxGames
//
//  Created by storm on 2020/1/18.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "TYIMGetVideoInfoApi+bwVideo.h"


@implementation TYIMGetVideoInfoApi (bwVideo)
+ (void)load {
    TYFSwizzleMethod([self class], @selector(requestUrl), [self class], @selector(bw_customRequestUrl));
}

- (NSString *)bw_customRequestUrl {
    
    NSString *channel = @"IM";
    NSString *platform = @"BW";
 //   NSString *type = @"all";
    NSString *eventId = self.vid.longLongValue >0 ? self.vid : self.aniId;
    NSString *user = @"admin";

    NSMutableString *strM = [[NSMutableString alloc] init];
    [strM appendString:channel];
//    [strM appendString:type];
    [strM appendString:eventId];
    NSString *txt = [NSString stringWithFormat:@"%@%@",user,platform];
    NSString *sign1 = [txt ty_md5];
    [strM appendString:sign1];
    NSString *sign = [strM ty_md5];
    //NSString *url = @"%@/video/api/external/app/videoDetail?channel=%@&platform=%@&type=%@&eventId=%@&sign=%@";
    NSString *url = @"%@/video/api/external/app/getUrlsOfVideo?channel=%@&platform=%@&eventId=%@&sign=%@";
    NSString *domain = [NSString stringWithFormat:@"%@://video.83y7n1.com",(TYFSiteManager.manager.localMetaData.ISHttps?@"https":@"http")];
    NSString *cURL = [NSString stringWithFormat:url, domain,channel,platform,eventId,sign];//@"http://videoapi.bwhou2028.com"
//    NSString *cURL = [NSString stringWithFormat:url, domain ,channel,platform,type,eventId, sign];
    return cURL;
//    return [NSString stringWithFormat:@"%@/video/v1/im_play_url.php?stream_id=%@&ani_id=%@&is_https=true",self.imBaseUrl, self.vid, self.aniId];
    
}
@end
