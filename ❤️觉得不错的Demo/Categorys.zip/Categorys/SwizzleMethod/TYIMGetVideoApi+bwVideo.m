//
//  TYIMGetVideoApi+bwVideo.m
//  FirefoxGames
//
//  Created by storm on 2020/1/18.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "TYIMGetVideoApi+bwVideo.h"


@implementation TYIMGetVideoApi (bwVideo)
+ (void)load {
    TYFSwizzleMethod([self class], @selector(requestUrl), [self class], @selector(bw_customRequestUrl));
}

- (NSString *)bw_customRequestUrl {
    
    NSString *channel = @"IM";
    NSString *platform = @"BW";
    NSString *type = @"all";
    NSString *user = @"admin";
    
    NSMutableString *strM = [[NSMutableString alloc] init];
    [strM appendString:channel];
    [strM appendString:type];
    NSString *txt = [NSString stringWithFormat:@"%@%@",user,platform];
    NSString *sign1 = [txt ty_md5];
    [strM appendString:sign1];
    NSString *sign = [[NSString stringWithString:strM] ty_md5];
    NSString *url = @"%@/video/api/external/app/getVideoList?channel=%@&platform=%@&type=%@&sign=%@";
    NSString *domain = [NSString stringWithFormat:@"%@://video.83y7n1.com",(TYFSiteManager.manager.localMetaData.ISHttps?@"https":@"http")];
    NSString *cURL = [NSString stringWithFormat:url,domain,channel,platform,type,sign];
    return cURL;
    
}
@end
