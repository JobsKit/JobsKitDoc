//
//  UITableViewCell+TYAdd.m
//  FirefoxGames
//
//  Created by storm on 2019/12/19.
//  Copyright © 2019 FirefoxGames. All rights reserved.
//

#import "UITableViewCell+TYAdd.h"

@implementation UITableViewCell (TYAdd)
+ (instancetype)cellWithTableView:(UITableView *)tableView {
    NSString *className = NSStringFromClass(self.class);
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:className];
    if (cell == nil) {
        cell = [[self alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:className];
    }
    return cell;
}
@end
