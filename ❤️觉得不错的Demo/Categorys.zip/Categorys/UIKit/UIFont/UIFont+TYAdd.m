//
//  UIFont+TYAdd.m
//  Project
//
//  Created by linker on 5/3/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIFont+TYAdd.h"
static NSDictionary *kNewFontMap = nil;
static NSDictionary *kOldFontMap = nil;

@implementation UIFont (TYAdd)

+ (instancetype)ty_systemFontOfSize:(CGFloat)size weight:(SystemFontWeight)weight {
    UIFont *font = nil;
    
    if ([UIFont respondsToSelector:@selector(systemFontOfSize:weight:)]) {
        if (!kNewFontMap) {
            kNewFontMap = @{@(SystemFontWeightUltraLight) : @(UIFontWeightUltraLight),
                            @(SystemFontWeightThin) : @(UIFontWeightThin),
                            @(SystemFontWeightLight) : @(UIFontWeightLight),
                            @(SystemFontWeightRegular) : @(UIFontWeightRegular),
                            @(SystemFontWeightMedium) : @(UIFontWeightMedium),
                            @(SystemFontWeightSemibold) : @(UIFontWeightSemibold),
                            @(SystemFontWeightBold) : @(UIFontWeightBold),
                            @(SystemFontWeightHeavy) : @(UIFontWeightHeavy),
                            @(SystemFontWeightBlack) : @(UIFontWeightBlack)};
        }
        
        NSNumber *fontWeightNumber = kNewFontMap[@(weight)] ?: [NSNumber numberWithFloat:UIFontWeightRegular];
        CGFloat fontWeight = fontWeightNumber.floatValue;
        
        font = [UIFont systemFontOfSize:size weight:fontWeight];
    } else {
        if (!kOldFontMap) {
            kOldFontMap = @{@(SystemFontWeightUltraLight) : @"HelveticaNeue-UltraLight",
                            @(SystemFontWeightThin) : @"HelveticaNeue-Thin",
                            @(SystemFontWeightLight) : @"HelveticaNeue-Light",
                            @(SystemFontWeightRegular) : @"HelveticaNeue",
                            @(SystemFontWeightMedium) : @"HelveticaNeue-Medium",
                            @(SystemFontWeightSemibold) : @"Helvetica-Bold",
                            @(SystemFontWeightBold) : @"HelveticaNeue-Bold",
                            @(SystemFontWeightHeavy) : @"HelveticaNeue-CondensedBold",
                            @(SystemFontWeightBlack) : @"HelveticaNeue-CondensedBlack"};
            
            NSString *fontName = kOldFontMap[@(weight)] ?: @"HelveticaNeue";
            
            font = [UIFont fontWithName:fontName size:size];
        }
    }
    
    return font ?: [UIFont systemFontOfSize:size];
}

+(UIFont *)ty_numberFontOfSize:(NSInteger)size{
    return [UIFont systemFontOfSize:size];
}

+(UIFont *)ty_numberDINAlternateBoldFontOfSize:(NSInteger)size{
    UIFont *font = [UIFont fontWithName:@"DINAlternate-Bold" size:size];
    return font ?:[UIFont systemFontOfSize:size];
}

+(UIFont *)ty_numberDINProBoldFontOfSize:(NSInteger)size{
    UIFont *font = [UIFont fontWithName:@"DINPro-Bold" size:size];
    return font ?:[UIFont systemFontOfSize:size];
}

+ (UIFont *)ty_numberDINProMediumFontOfSize:(NSInteger)size{
    UIFont *font = [UIFont fontWithName:@"DINPro-Medium" size:size];
    return font ?: [UIFont systemFontOfSize:size];
}

+ (UIFont *)ty_numberDINProRegularFontOfSize:(NSInteger)size{
    UIFont *font = [UIFont fontWithName:@"DINPro-Regular" size:size];
    return font ?: [UIFont systemFontOfSize:size];
}

+ (UIFont *)ty_numberDINBoldFontOfSize:(NSInteger)size{
    UIFont *font = [UIFont fontWithName:@"DIN-Bold" size:size];
    return font ?: [UIFont systemFontOfSize:size];
}

+ (UIFont *)ty_numberDINMediumFontOfSize:(NSInteger)size{
    UIFont *font = [UIFont fontWithName:@"DIN-Medium" size:size];
    return font ?: [UIFont systemFontOfSize:size];
}

+ (UIFont *)ty_numberDINRegularFontOfSize:(NSInteger)size{
    UIFont *font = [UIFont fontWithName:@"DIN-Regular" size:size];
    return font ?: [UIFont systemFontOfSize:size];
}

+ (UIFont *)ty_numberDINItalicFontOfSize:(NSInteger)size {
    UIFont *font = [UIFont fontWithName:@"DINPro-CondensedBoldItalic" size:size];
    return font ?: [UIFont systemFontOfSize:size];
}

+ (UIFont *)ty_numberDINCondBoldFontOfSize:(NSInteger)size {
    UIFont *font = [UIFont fontWithName:@"DINCond-Bold" size:size];
    return font ?: [UIFont systemFontOfSize:size];
}

@end
