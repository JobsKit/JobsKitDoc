//
//  UIFont+TYAdd.h
//  Project
//
//  Created by linker on 5/3/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>
///苹方-简 常规
#define SystemFont(size)        [UIFont ty_systemFontOfSize:size weight:SystemFontWeightRegular]
///苹方-简 中黑体
#define MediumSystemFont(size)  [UIFont ty_systemFontOfSize:size weight:SystemFontWeightMedium]
///苹方-简 细体
#define LightSystemFont(size)   [UIFont ty_systemFontOfSize:size weight:SystemFontWeightLight]
///苹方-简 黑体
#define BoldSystemFont(size)    [UIFont ty_systemFontOfSize:size weight:SystemFontWeightBold]
///苹方-简 纤细体
#define ThinSystemFont(size)    [UIFont ty_systemFontOfSize:size weight:SystemFontWeightThin]
///苹方-简 中粗体
#define SemiSystemFont(size)    [UIFont ty_systemFontOfSize:size weight:SystemFontWeightSemibold]
// 苹方-简 Hevay
#define HeavySystemFont(size)   [UIFont ty_systemFontOfSize:size weight:SystemFontWeightHeavy]
/** PingFangSC-Regular 平方简体 */
#define PingSCLight(fontSize)    [UIFont fontWithName:@"PingFangSC-Light" size:fontSize]
/** PingFangSC-Regular 平方简体 */
#define PingSCRegular(fontSize)    [UIFont fontWithName:@"PingFangSC-Regular" size:fontSize]
/** PingFangSC-Regular 平方粗体 */
#define PingSCBold(fontSize)    [UIFont fontWithName:@"PingFangSC-Semibold" size:fontSize]
/** PingFangSC-Regular 平方中等体 */
#define PingSCMedium(fontSize)    [UIFont fontWithName:@"PingFangSC-Medium" size:fontSize]
//特殊字体（使用外部导入字体）
#define DinProFont(fontSize)        [UIFont fontWithName:@"DINPro" size:fontSize]           //常规
#define MediumDinProFont(fontSize)  [UIFont fontWithName:@"DINPro-Medium" size:fontSize]    //中黑
#define BoldDinProFont(fontSize)    [UIFont fontWithName:@"DINPro-Bold" size:fontSize]      //黑体
#define SpeedTestFont(fontSize)     [UIFont fontWithName:@"speedtest" size:fontSize]        // SpeedTest 字体
#define HYYaKuHeiWFont(fontSize)    [UIFont fontWithName:@"HYYaKuHeiW" size:fontSize]        // HYYaKuHeiW 字体
#define FZZhengHeiSDBGBFont(fontSize)    [UIFont fontWithName:@"FZZhengHeiS-DB-GB" size:fontSize]        // HYYaKuHeiW 字体

#define DINItalicFont(fontSize)     [UIFont ty_numberDINItalicFontOfSize:fontSize]

#define DINCondBoldFont(fontSize)     [UIFont ty_numberDINCondBoldFontOfSize:fontSize]

typedef NS_ENUM(NSUInteger, SystemFontWeight) {
    SystemFontWeightUltraLight,
    SystemFontWeightThin,
    SystemFontWeightLight,
    SystemFontWeightRegular,
    SystemFontWeightMedium,
    SystemFontWeightSemibold,
    SystemFontWeightBold,
    SystemFontWeightHeavy,
    SystemFontWeightBlack
};


NS_ASSUME_NONNULL_BEGIN

@interface UIFont (TYAdd)

+ (instancetype)ty_systemFontOfSize:(CGFloat)size weight:(SystemFontWeight)weight;

+(UIFont *)ty_numberFontOfSize:(NSInteger)size;
+(UIFont *)ty_numberDINAlternateBoldFontOfSize:(NSInteger)size;
+(UIFont *)ty_numberDINProBoldFontOfSize:(NSInteger)size;
+(UIFont *)ty_numberDINProMediumFontOfSize:(NSInteger)size;
+(UIFont *)ty_numberDINProRegularFontOfSize:(NSInteger)size;
+(UIFont *)ty_numberDINBoldFontOfSize:(NSInteger)size;
+(UIFont *)ty_numberDINMediumFontOfSize:(NSInteger)size;
+(UIFont *)ty_numberDINRegularFontOfSize:(NSInteger)size;
+ (UIFont *)ty_numberDINItalicFontOfSize:(NSInteger)size;
+ (UIFont *)ty_numberDINCondBoldFontOfSize:(NSInteger)size;
@end

NS_ASSUME_NONNULL_END
