//
//  UINavigationBar+tyAppearance.h
//  TYFVendor
//
//  Created by BWJS-JS-D00108 on 2020/11/16.
//

#import <UIKit/UIKit.h>
#import "TYFNavBarAppearance.h"

NS_ASSUME_NONNULL_BEGIN

@interface UINavigationBar (tyAppearance)

/// 只对指定的navbar生效，YES时appearance参数才会生效
@property (nonatomic, assign) BOOL isCustomAppearance;
/// 当前navBar的状态
@property (nonatomic, assign, readonly) TYNavbarStyle ty_navbarStyle;
/// 分割线
@property (nonatomic, strong) UIImageView *ty_lineView;
/// 阴影
@property (nonatomic, strong) UIImageView *ty_ShadowView;

/// 设置自定义样式
- (void)ty_drawShadowWithApperance:(TYFNavBarAppearance *)appearance;

@end


NS_ASSUME_NONNULL_END
