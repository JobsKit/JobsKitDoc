//
//  UINavigationBar+tyAppearance.m
//  TYFVendor
//
//  Created by BWJS-JS-D00108 on 2020/11/16.
//

#import "UINavigationBar+tyAppearance.h"
#import <objc/runtime.h>
#import "TYFFSwizzle.h"

static const char *K_tyNavbarStyle          = "K_tyNavbarStyle";
static const char *K_tyNavbarShadowViewKey          = "K_tyNavbarShadowViewKey";
static const char *K_tyNavbarLineViewKey         = "K_tyNavbarLineViewKey";
static const char *K_tyNavbarCustomAppearance        = "K_tyNavbarCustomAppearance";

@implementation UINavigationBar (tyAppearance)

+ (void)load {
    TYFFSwizzleMethod([self class], @selector(layoutSubviews), [self class], @selector(tyf_layoutSubviews));
    TYFFSwizzleMethod([self class], @selector(setBackgroundImage:forBarMetrics:), [self class], @selector(tyf_setBackgroundImage:forBarMetrics:));
    
}

- (void)tyf_layoutSubviews {
    [self tyf_layoutSubviews];
    if (self.isCustomAppearance) {
        [self sendSubviewToBack:self.ty_ShadowView];
    }
}

- (void)tyf_setBackgroundImage:(nullable UIImage *)backgroundImage forBarMetrics:(UIBarMetrics)barMetrics {
    [self tyf_setBackgroundImage:backgroundImage forBarMetrics:barMetrics];
    if (self.isCustomAppearance) {
        [self.ty_ShadowView setImage:backgroundImage];
        
    }
}

- (void)ty_drawShadowWithApperance:(TYFNavBarAppearance *)appearance {
    
    [self ty_navAppearanceWithStyle:appearance.ty_navbarStyle];
    
    if (appearance.ty_navbarStyle == TYNavbarStyleShadow) {
        self.ty_ShadowView.hidden = NO;
        self.ty_lineView.hidden = YES;
        self.ty_ShadowView.layer.shadowColor = appearance.shadowColor.CGColor;
        self.ty_ShadowView.layer.shadowOpacity = appearance.shadowOpacity;
        self.ty_ShadowView.layer.shadowOffset = appearance.shadowOffset;
        self.ty_ShadowView.layer.shadowRadius = appearance.shadowRadius;
    }
    else if (appearance.ty_navbarStyle == TYNavbarStyleLine) {
        self.ty_ShadowView.hidden = YES;
        self.ty_lineView.hidden = NO;
        self.ty_lineView.image = appearance.lineImage;
        
        if (appearance.lineColor) {
            self.ty_lineView.backgroundColor = appearance.lineColor;
        }
        
        if (appearance.lineOffsetY != 0 || appearance.lineHeight > 0) {
            CGRect frame = self.ty_lineView.frame;
            CGFloat lineH = frame.size.height;
            if (appearance.lineHeight > 0) {
                lineH = appearance.lineHeight;
            }
            CGFloat navH = [self navbarHeight];
            frame = CGRectMake(frame.origin.x, navH+appearance.lineOffsetY, frame.size.width, lineH);
            self.ty_lineView.frame = frame;
        }
    }
    else if (appearance.ty_navbarStyle == TYNavbarStyleClear) {
        self.ty_ShadowView.hidden = YES;
        self.ty_lineView.hidden = YES;
    }
    
}

- (CGFloat)navbarHeight {
    CGFloat navH = self.bounds.size.height;
    return navH;
}

#pragma mark - setter && getter
- (UIImageView *)ty_lineView {
    UIImageView *ty_lineView = objc_getAssociatedObject(self, K_tyNavbarLineViewKey);
    if (!ty_lineView) {
        CGFloat scale = [UIScreen mainScreen].scale;
        CGFloat lineH = (scale == 3) ? 0.34 : 0.5;
        CGFloat navH = [self navbarHeight];
        ty_lineView = [[UIImageView alloc] initWithFrame:CGRectMake(0, navH, [UIScreen mainScreen].bounds.size.width, lineH)];
        objc_setAssociatedObject(self, K_tyNavbarLineViewKey, ty_lineView, OBJC_ASSOCIATION_RETAIN);
        [self addSubview:ty_lineView];
    }
    return ty_lineView;
}

- (void)setTy_lineView:(UIImageView *)ty_lineView {
    objc_setAssociatedObject(self, K_tyNavbarLineViewKey, ty_lineView, OBJC_ASSOCIATION_RETAIN);
}

- (UIImageView *)ty_ShadowView {
    UIImageView *ty_ShadowView = objc_getAssociatedObject(self, K_tyNavbarShadowViewKey);
    if (!ty_ShadowView) {
        CGFloat statusH = [[UIApplication sharedApplication] statusBarFrame].size.height;
        CGFloat navH = [self navbarHeight];
        ty_ShadowView = [[UIImageView alloc] initWithFrame:CGRectMake(0, -statusH, [UIScreen mainScreen].bounds.size.width, navH+statusH)];
        objc_setAssociatedObject(self, K_tyNavbarShadowViewKey, ty_ShadowView, OBJC_ASSOCIATION_RETAIN);
        [self insertSubview:ty_ShadowView atIndex:0];
    }
    return ty_ShadowView;
}

- (void)setTy_ShadowView:(UIImageView *)ty_ShadowView {
    objc_setAssociatedObject(self, K_tyNavbarShadowViewKey, ty_ShadowView, OBJC_ASSOCIATION_RETAIN);
}

- (void)ty_navAppearanceWithStyle:(TYNavbarStyle)style {
    objc_setAssociatedObject(self, K_tyNavbarStyle, @(style), OBJC_ASSOCIATION_RETAIN);
}

- (TYNavbarStyle)ty_navbarStyle {
    id style = objc_getAssociatedObject(self, K_tyNavbarStyle);
    if (!style) {
        return TYNavbarStyleUndefined;
    }
    return [style integerValue];
}

- (void)setIsCustomAppearance:(BOOL)isCustomAppearance {
    objc_setAssociatedObject(self, K_tyNavbarCustomAppearance, @(isCustomAppearance), OBJC_ASSOCIATION_RETAIN);
}

- (BOOL)isCustomAppearance {
    BOOL result = [objc_getAssociatedObject(self, K_tyNavbarCustomAppearance) boolValue];
    return result;
}

@end
