//
//  TYFNavBarAppearance.m
//  TYFVendor
//
//  Created by BWJS-JS-D00108 on 2020/11/16.
//

#import "TYFNavBarAppearance.h"

@implementation TYFNavBarAppearance
+ (instancetype)shareAppearance {
    static TYFNavBarAppearance *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance  = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.shadowOffset = CGSizeMake(0, 3);
        self.shadowColor = UIColor.blackColor;
        self.shadowOpacity = 0.05;
        self.shadowRadius = 4;
        self.lineColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.15];
    }
    return self;
}

- (void)setShadowColor:(UIColor *)shadowColor
          shadowOffset:(CGSize)offset
         shadowOpacity:(CGFloat)Opacity
          shadowRadius:(CGFloat)shadowRadius {
    self.shadowColor = shadowColor;
    self.shadowOffset = offset;
    self.shadowOpacity = Opacity;
    self.shadowRadius = shadowRadius;
}

@end
