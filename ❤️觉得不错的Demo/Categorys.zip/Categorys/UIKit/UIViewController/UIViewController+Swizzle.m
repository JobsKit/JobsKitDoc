//
//  UIViewController+Swizzle.m
//  FirefoxGames
//
//  Created by BWJS-OTIS on 2020/8/26.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "UIViewController+Swizzle.h"


@implementation UIViewController (Swizzle)
+ (void)load
{
    #ifdef DEBUG
//        TYFFSwizzleMethod([self class], NSSelectorFromString(@"dealloc"), [self class], @selector(deallocSwizzle));
//        TYFFSwizzleMethod([self class], NSSelectorFromString(@"init"), [self class], @selector(initSwizzle));
    #else
    #endif
    
}

- (void)deallocSwizzle
{
    #ifdef DEBUG
        NSLog(@"logfilter dealloc:%@ ", NSStringFromClass([self class]));
    #else
    #endif
    [self deallocSwizzle];
}

- (instancetype)initSwizzle
{
    self = [self initSwizzle];
    if (self) {
        #ifdef DEBUG
            NSLog(@"logfilter init:%@ ", NSStringFromClass([self class]));
        #else
        #endif
    }
    return self;
}
@end
