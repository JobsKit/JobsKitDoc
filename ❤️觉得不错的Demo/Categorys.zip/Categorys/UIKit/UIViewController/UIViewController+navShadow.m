//
//  UIViewController+navShadow.m
//  FirefoxGames
//
//  Created by charlie on 2020/1/13.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "UIViewController+navShadow.h"
#import <objc/runtime.h>
#import "TYFFSwizzle.h"

static const char *KisHiddenNavigationBarShadowKey            = "IsHiddenNavigationBarShadowKey";
static const char *KNavAppearanceModel           = "KNavAppearanceModel";

@implementation UIViewController (navShadow)
+ (void)load {
    TYFFSwizzleMethod([self class], @selector(viewDidAppear:), [self class], @selector(tyf_viewDidAppear:));
    TYFFSwizzleMethod([self class], @selector(viewWillAppear:), [self class], @selector(tyf_viewWillAppear:));
}

- (void)tyf_viewDidAppear:(BOOL)animated {
    [self tyf_viewDidAppear:animated];
    
    [self setupNavShadow:self.isHiddenNavigationBarShadow];
}

- (void)tyf_viewWillAppear:(BOOL)animated {
    [self tyf_viewWillAppear:animated];
    [self setupNavShadow:self.isHiddenNavigationBarShadow];
}

- (void)setupNavShadow:(BOOL)isHiddenNavigationBarShadow {
    
    if ([TYFNavBarAppearance shareAppearance].versionTag == 1) {
        if (isHiddenNavigationBarShadow) {
            self.tyAppearance.shadowOpacity = 0.0;
        }
        if (self.navigationController.navigationBar.isCustomAppearance) {
            [self.navigationController.navigationBar ty_drawShadowWithApperance:self.tyAppearance];
        }
        return;
    }
    
    CALayer *layer = self.navigationController.navigationBar.layer;

    if (!layer) {  return; }
    //设置阴影
    if (isHiddenNavigationBarShadow) {
        layer.shadowOffset = CGSizeMake(0, 0);
        layer.shadowColor = UIColor.clearColor.CGColor;
        layer.shadowOpacity = 0.0;
    } else {
        layer.shadowOffset = CGSizeMake(0, -3);
        layer.shadowColor = UIColor.blackColor.CGColor;
        layer.shadowOpacity = 0.2;
        layer.shadowRadius = 4;
    }
}

- (void)setIsHiddenNavigationBarShadow:(BOOL)isHiddenNavigationBarShadow {
    objc_setAssociatedObject(self, KisHiddenNavigationBarShadowKey, @(isHiddenNavigationBarShadow), OBJC_ASSOCIATION_RETAIN);
    
    [self setupNavShadow:isHiddenNavigationBarShadow];
}

- (BOOL)isHiddenNavigationBarShadow {
    return [objc_getAssociatedObject(self, KisHiddenNavigationBarShadowKey) boolValue];
}

- (void)setTyAppearance:(TYFNavBarAppearance *)tyAppearance {
    objc_setAssociatedObject(self, KNavAppearanceModel, tyAppearance, OBJC_ASSOCIATION_RETAIN);
}

- (TYFNavBarAppearance *)tyAppearance {
    
    TYFNavBarAppearance *model = objc_getAssociatedObject(self, KNavAppearanceModel);
    if (!model) {
        model =[TYFNavBarAppearance new];
        
        model.ty_navbarStyle = [TYFNavBarAppearance shareAppearance].ty_navbarStyle;
        model.versionTag = [TYFNavBarAppearance shareAppearance].versionTag;
        
        [model setShadowColor:[TYFNavBarAppearance shareAppearance].shadowColor
                 shadowOffset:[TYFNavBarAppearance shareAppearance].shadowOffset
                shadowOpacity:[TYFNavBarAppearance shareAppearance].shadowOpacity
                 shadowRadius:[TYFNavBarAppearance shareAppearance].shadowRadius];
        
        model.lineColor = [TYFNavBarAppearance shareAppearance].lineColor;
        model.lineHeight = [TYFNavBarAppearance shareAppearance].lineHeight;
        model.lineImage = [TYFNavBarAppearance shareAppearance].lineImage;
        model.lineOffsetY = [TYFNavBarAppearance shareAppearance].lineOffsetY;
        
        objc_setAssociatedObject(self, KNavAppearanceModel, model, OBJC_ASSOCIATION_RETAIN);
    }
    return model;
}

@end

