//
//  TYFNavBarAppearance.h
//  TYFVendor
//
//  Created by BWJS-JS-D00108 on 2020/11/16.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, TYNavbarStyle) {
    TYNavbarStyleUndefined = -1,
    /// 不做任何操作
    TYNavbarStyleNone = 0,
    /// 阴影
    TYNavbarStyleShadow = 1,
    /// 分割线
    TYNavbarStyleLine,
    /// 清空自定义样式
    TYNavbarStyleClear,
};

NS_ASSUME_NONNULL_BEGIN

@interface TYFNavBarAppearance : NSObject

+ (instancetype)shareAppearance;
/// navBar的样式
@property (nonatomic, assign) TYNavbarStyle ty_navbarStyle;
/// 阴影参数
@property (nonatomic, strong) UIColor *shadowColor;
@property (nonatomic, assign) CGSize shadowOffset;
@property (nonatomic, assign) CGFloat shadowOpacity;
@property (nonatomic, assign) CGFloat shadowRadius;
/// 分割线参数
@property (nonatomic, strong) UIColor *lineColor;
@property (nonatomic, strong) UIImage *lineImage;
@property (nonatomic, assign) CGFloat lineOffsetY;
@property (nonatomic, assign) CGFloat lineHeight;

/**
 临时处理，兼容新老版本，代码合并后再统一修改
 versionTag：0 老版本，1:新版本
 */
@property (nonatomic, assign) NSInteger versionTag;

- (void)setShadowColor:(UIColor *)shadowColor
          shadowOffset:(CGSize)offset
         shadowOpacity:(CGFloat)Opacity
          shadowRadius:(CGFloat)shadowRadius;

@end

NS_ASSUME_NONNULL_END
