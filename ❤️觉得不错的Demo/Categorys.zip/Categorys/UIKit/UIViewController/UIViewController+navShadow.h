//
//  UIViewController+navShadow.h
//  FirefoxGames
//
//  Created by charlie on 2020/1/13.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UINavigationBar+tyAppearance.h"

NS_ASSUME_NONNULL_BEGIN


@interface UIViewController (navShadow)

/// YES:隐藏阴影 NO:显示阴影
@property (nonatomic,assign) BOOL isHiddenNavigationBarShadow;

/**
 自定义的navBar样式,只需在viewDidLoad中设置，
 最后生效时机在viewDidAppear
 */
@property (nonatomic, strong) TYFNavBarAppearance *tyAppearance;

@end

NS_ASSUME_NONNULL_END
