//
//  UIWindow+TYHierarchy.m
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIWindow+TYHierarchy.h"
#import <objc/runtime.h>

const TYWindowLevel TYWindowBusiness   = @"TYWindowBusiness";
const TYWindowLevel TYWindowCross      = @"TYWindowCross";
const TYWindowLevel TYWindowAppliction = @"TYWindowAppliction";
const NSUInteger    TYLowestPriority   = 1000;

@implementation UIWindow (TYHierarchy)
#pragma mark - life cycle

#pragma mark - public methods
//class methods
+ (void)showAlertView:(UIView <WindowAlertDelegate>*)alertView
          windowLevel:(TYWindowLevel)windowLevel {
    NSAssert(alertView, @"alertView 不能为空");
    [UIWindow showAlertViewInQueue:alertView windowLevel:windowLevel priority:TYLowestPriority target:alertView];
}

+ (void)showAlertView:(UIView <WindowAlertDelegate>*)alertView
          windowLevel:(TYWindowLevel)windowLevel
            configure:(nullable void(^)(UIWindow *alertWindow))configure {
    [UIWindow showAlertViewInQueue:alertView windowLevel:windowLevel priority:TYLowestPriority target:alertView configure:configure];
}

+ (void)dismissAlertView:(UIView <WindowAlertDelegate>*)alertView {
    NSAssert(alertView, @"alertView 不能为空");
    [self dismissAlertViewInQueue:alertView target:alertView];
}


+ (void)showAlertViewInQueue:(UIView <WindowAlertDelegate>*)alertView
                 windowLevel:(TYWindowLevel)windowLevel
                    priority:(NSUInteger)priority
                      target:(id)target {
    NSAssert(target, @"target 不能为空");
    [UIWindow showAlertViewInQueue:alertView windowLevel:windowLevel priority:priority target:target configure:nil];
}

+ (void)showAlertViewInQueue:(UIView <WindowAlertDelegate>*)alertView
                 windowLevel:(TYWindowLevel)windowLevel
                    priority:(NSUInteger)priority
                      target:(id)target
                   configure:(nullable void(^)(UIWindow *alertWindow))configure {
    dispatch_async(dispatch_get_main_queue(), ^{
         [UIWindow _showAlertViewInQueue:alertView windowLevel:windowLevel priority:priority target:target configure:configure];
    });
}

+ (void)dismissAlertViewInQueue:(UIView <WindowAlertDelegate>*)alertView
                         target:(id)target {
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIWindow _dismissAlertViewInQueue:alertView target:target];
    });
}

//instance methods
- (UIViewController*)ty_topMostController {
    UIViewController *topController = [self rootViewController];
    while ([topController presentedViewController])    topController = [topController presentedViewController];
    
    //  Returning topMost ViewController
    return topController;
}

- (UIViewController*)ty_currentViewController;
{
    UIViewController *currentViewController = [self ty_topMostController];
    
    while (
           ([currentViewController isKindOfClass:[UINavigationController class]] && [(UINavigationController*)currentViewController topViewController]) ||
           ([currentViewController isKindOfClass:[UITabBarController class]] && [(UITabBarController*)currentViewController selectedViewController])  ) {
        if ([currentViewController isKindOfClass:[UINavigationController class]]) {
            currentViewController = [(UINavigationController*)currentViewController topViewController];
        }
        if ([currentViewController isKindOfClass:[UITabBarController class]]) {
            currentViewController = [(UITabBarController*)currentViewController selectedViewController];
        }
    }
    
    return currentViewController;
}

+ (instancetype)getCurrentWindow {
return (UIApplication.sharedApplication.delegate).window;
}

+ (UIView *)ty_currentVCView {
return UIWindow.getCurrentWindow.ty_currentViewController.view;

}

+ (UINavigationController *)ty_currentNavigationController {
    UIViewController *rootVC = UIWindow.getCurrentWindow.rootViewController;
    if ([rootVC isKindOfClass:[UIViewController class]]) {
        UITabBarController *tabVC = (UITabBarController *)rootVC;
        UIViewController *selectVC = tabVC.selectedViewController;
        if ([selectVC isKindOfClass:[UINavigationController class]]) {
            return (UINavigationController *)selectVC;
        }else{
            return nil;
        }
    }else if([rootVC isKindOfClass:[UINavigationController class]]){
        return (UINavigationController *)rootVC;
    }
    return nil;;
}
+ (UITabBarController *)ty_currentTabbarVC {
    UIViewController *rootVC = UIWindow.getCurrentWindow.rootViewController;
    if ([rootVC isKindOfClass:[UITabBarController class]]) {
        return (UITabBarController *)rootVC;
    }
    return nil;
}
+ (UINavigationController *)ty_currentNavigationVC {
    return UIWindow.getCurrentWindow.ty_currentViewController.navigationController;
}

#pragma mark - private methods
+ (UIWindow *)_windowWithAlertView:(UIView *)alertView
                       windowLevel:(TYWindowLevel)windowLevel {
    UIWindow *_alterWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    _alterWindow.windowLevel = [[[[self windowLevelInfo] objectForKey:windowLevel] lastObject] floatValue];
    return _alterWindow;
}

+ (void)_showAlertView:(UIView <WindowAlertDelegate>*)alertView alterWindow:(UIWindow *)alterWindow {
    if(!alertView.superview){
        [alterWindow addSubview:alertView];
        [alterWindow makeKeyAndVisible];
        if ([alertView respondsToSelector:@selector(beginShowWithAnmation)]) {
            [alertView beginShowWithAnmation];
        }
    }else {
        [alterWindow makeKeyAndVisible];
    }
}

+ (TYWaitHoldM *)_associatedWaitHoldM:(UIView *)alertView alertQueue:(NSMutableArray <TYWaitHoldM *>*)alertQueue {
    __block NSInteger _index = -1;
    if(!alertQueue || ![alertQueue isKindOfClass:[NSMutableArray class]]){
        return nil;
    }
    [alertQueue enumerateObjectsUsingBlock:^(TYWaitHoldM * waitHoldM, NSUInteger idx, BOOL * _Nonnull stop) {
        if (waitHoldM.alertView == alertView) {
            _index = idx;;
            *stop = YES;
        }
    }];
    if(_index != -1 && _index < alertQueue.count){
        return alertQueue[_index];
    }
    return nil;
}

+ (TYWaitHoldM *)_hideAlertViewInQueue:(UIView <WindowAlertDelegate>*)alertView
                                target:(nullable id)target {
    NSMutableArray<TYWaitHoldM *> *_alertQueue = [[UIWindow targetKeyAlertQueueMapTable] objectForKey:target];
    TYWaitHoldM *_waitHoldM = [self _associatedWaitHoldM:alertView alertQueue:_alertQueue];
    if(!_waitHoldM) { return nil; }
    [_waitHoldM.alertWindow setHidden:YES];
    return _waitHoldM;
}

+ (void)_showAlertViewInQueue:(UIView <WindowAlertDelegate>*)alertView
                 windowLevel:(TYWindowLevel)windowLevel
                    priority:(NSUInteger)priority
                      target:(id)target
                   configure:(nullable void(^)(UIWindow *alertWindow))configure {
    NSAssert(target, @"target 不能为空");
    
    //1 生成新的缓存模型
    UIWindow *_window = [UIWindow _windowWithAlertView:alertView windowLevel:windowLevel];
    NSMutableArray<TYWaitHoldM *> *_alertQueue = [[UIWindow targetKeyAlertQueueMapTable] objectForKey:target];
    if(!_alertQueue || ![_alertQueue isKindOfClass:[NSMutableArray class]]){ //对应的targe没有alert队列,生成一个
        _alertQueue = [NSMutableArray new];
    }
    TYWaitHoldM *_waitHoldM =  [TYWaitHoldM new];
    _waitHoldM.alertView    = alertView;
    _waitHoldM.priority     = priority;
    _waitHoldM.alertWindow  = _window;
    //将新的alertView 根据优先级放到合适的位置
    __block NSUInteger _index = 0;
    [_alertQueue enumerateObjectsUsingBlock:^(TYWaitHoldM * waitHoldM, NSUInteger idx, BOOL * _Nonnull stop) {
        if (waitHoldM.priority >= priority) {
            _index = idx;
            *stop = YES;
        }
    }];
    [_alertQueue insertObject:_waitHoldM atIndex:_index];
    [[UIWindow targetKeyAlertQueueMapTable] setObject:_alertQueue forKey:target];
    
    //2 显示
    if(_alertQueue.count == 1){                         //当前队列只有一个需要显示的alertView 直接进行显示
        [UIWindow _showAlertView:alertView alterWindow:_window];
        return;
    }
    if([_alertQueue firstObject].priority == priority){ //当前priority在队列中的最高优先级,直接显示
        //现将之前显示的alertView隐藏
        [UIWindow _hideAlertViewInQueue:_alertQueue[1].alertView target:target];
        //将新的显示出来
        [UIWindow _showAlertView:alertView alterWindow:_window];
        return;
    }
}

+ (void)_dismissAlertViewInQueue:(UIView <WindowAlertDelegate>*)alertView
                         target:(id)target {
    NSAssert(alertView, @"dismissAlertViewInQueue alertView 不能为空");
    NSAssert(target, @"dismissAlertViewInQueue target 不能为空");
    
    //隐藏alertView 以及 alertWindow
    NSMutableArray<TYWaitHoldM *> *_alertQueue = [[UIWindow targetKeyAlertQueueMapTable] objectForKey:target];
    TYWaitHoldM *_waitHoldM = [self _hideAlertViewInQueue:alertView target:target];
    //清除view window 强引用绑定关系
    [_alertQueue removeObject:_waitHoldM];
    //清除target 与 alertQueue之间的绑定关系
    if(_alertQueue.count == 0){
        [[self targetKeyAlertQueueMapTable] removeObjectForKey:target];
    }else {
        TYWaitHoldM *_waitHoldM = [_alertQueue firstObject];
        [self _showAlertView:_waitHoldM.alertView alterWindow:_waitHoldM.alertWindow];
    }
}

#pragma mark - setter/getter methods
+ (NSMutableDictionary <TYWindowLevel, NSMutableArray*> *)windowLevelInfo {
    NSMutableDictionary *_windowLevelInfo = objc_getAssociatedObject([UIWindow class], _cmd);
    
    if(!_windowLevelInfo) {
        
        _windowLevelInfo = [[NSMutableDictionary alloc] initWithObjects:@[@[@([self ty_fetchBaseWindowLevel:TYWindowBusiness])],
                                                                          @[@([self ty_fetchBaseWindowLevel:TYWindowCross])],
                                                                          @[@([self ty_fetchBaseWindowLevel:TYWindowAppliction])]]
                                                                forKeys:@[TYWindowBusiness,
                                                                          TYWindowCross,
                                                                          TYWindowAppliction]];
        
    }
    return _windowLevelInfo;
}

- (void)setWindowLevelInfo:(NSMutableDictionary <TYWindowLevel, NSMutableArray*> *)windowLevelInfo {
    if(!windowLevelInfo || [windowLevelInfo isKindOfClass:[NSMutableDictionary class]]) {
        objc_setAssociatedObject([UIWindow class], @selector(windowLevelInfo), windowLevelInfo, OBJC_ASSOCIATION_RETAIN);
    }
}

+ (UIWindowLevel)ty_fetchBaseWindowLevel:(TYWindowLevel)windowType {
    if([windowType isEqualToString:TYWindowBusiness]) {
        return UIWindowLevelNormal;
    }else if([windowType isEqualToString:TYWindowCross]) {
        return UIWindowLevelNormal+100;
    }else if([windowType isEqualToString:TYWindowAppliction]) {
        return UIWindowLevelNormal+200;
    }
    return UIWindowLevelNormal;
}


///强持有target 与 alertQueue间的对应关系
+ (NSMapTable <id, NSMutableArray<TYWaitHoldM*>*> *)targetKeyAlertQueueMapTable {
    NSMapTable *_targetKeyAlertQueueMapTable = objc_getAssociatedObject([UIWindow class], _cmd);
    if (!_targetKeyAlertQueueMapTable) {
        _targetKeyAlertQueueMapTable =  [NSMapTable mapTableWithKeyOptions:NSMapTableStrongMemory valueOptions:NSMapTableStrongMemory];
        [self setTargetKeyAlertQueueMapTable:_targetKeyAlertQueueMapTable];
    }
    return _targetKeyAlertQueueMapTable;
}

+ (void)setTargetKeyAlertQueueMapTable:(NSMapTable <id, NSMutableArray<NSMapTable<UIView*, TYWaitHoldM*>*>*>*)targetKeyAlertQueueMapTable {
    if(!targetKeyAlertQueueMapTable || [targetKeyAlertQueueMapTable isKindOfClass:[NSMapTable class]]) {
        objc_setAssociatedObject([UIWindow class], @selector(targetKeyAlertQueueMapTable), targetKeyAlertQueueMapTable, OBJC_ASSOCIATION_RETAIN);
    }
}
@end


@implementation TYWaitHoldM @end
