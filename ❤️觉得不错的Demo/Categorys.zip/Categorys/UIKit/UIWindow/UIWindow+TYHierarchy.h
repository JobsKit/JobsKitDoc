//
//  UIWindow+TYHierarchy.h
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol   WindowAlertDelegate;
@class      TYWaitHoldM;

@interface UIWindow (TYHierarchy)

typedef NSString *TYWindowLevel;
extern const TYWindowLevel _Nullable TYWindowBusiness;
extern const TYWindowLevel _Nullable TYWindowCross;
extern const TYWindowLevel _Nullable TYWindowAppliction;

NS_ASSUME_NONNULL_BEGIN

+ (void)showAlertView:(UIView <WindowAlertDelegate>*)alertView
          windowLevel:(TYWindowLevel)windowLevel;
+ (void)showAlertView:(UIView <WindowAlertDelegate>*)alertView
          windowLevel:(TYWindowLevel)windowLevel
            configure:(nullable void(^)(UIWindow *alertWindow))configure;
+ (void)dismissAlertView:(UIView <WindowAlertDelegate>*)alertView;


// 按照优先级显示alertView,当高优先级没有弹出时先显示到来的低优先级的alertView,当高优先级显示后隐藏低优先级显示高优先级，高优先级关闭后再显示低之前隐藏的低优先级
//priority:优先级 0->NSUIntegerMax: hight->low
+ (void)showAlertViewInQueue:(UIView <WindowAlertDelegate>*)alertView
                 windowLevel:(TYWindowLevel)windowLevel
                    priority:(NSUInteger)priority
                      target:(id)target;

+ (void)showAlertViewInQueue:(UIView <WindowAlertDelegate>*)alertView
                 windowLevel:(TYWindowLevel)windowLevel
                    priority:(NSUInteger)priority
                      target:(id)target
                   configure:(nullable void(^)(UIWindow *alertWindow))configure;

+ (void)dismissAlertViewInQueue:(UIView <WindowAlertDelegate>*)alertView
                         target:(id)target;

/*!
 @method topMostController
 
 @return Returns the current Top Most ViewController in hierarchy.
 */
- (UIViewController*)ty_topMostController;

/*!
 @method currentViewController
 
 @return Returns the topViewController in stack of topMostController.
 */
- (UIViewController*)ty_currentViewController;
+ (UINavigationController *)ty_currentNavigationController;
+ (instancetype)getCurrentWindow;

+ (UIView *)ty_currentVCView;
+ (UINavigationController *)ty_currentNavigationVC;
+ (UITabBarController *)ty_currentTabbarVC;
@end

@interface TYWaitHoldM: NSObject
@property(nonatomic, strong)UIView <WindowAlertDelegate>*alertView;
@property(nonatomic, assign)NSUInteger                   priority;
@property(nonatomic, strong)UIWindow                    *alertWindow;
@end

@protocol WindowAlertDelegate <NSObject>
@optional
//有些弹框view会有显示动画，需要在此方法中实现。showAlertView...会自动调用此方法
- (void)beginShowWithAnmation;
@end
NS_ASSUME_NONNULL_END
