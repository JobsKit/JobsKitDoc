//
//  TYGradientView.h
//  YaboGames
//
//  Created by mannay on 10/03/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView(GradientColors)
@property (nonatomic, strong) NSArray<UIColor *> *colors;
@end

NS_ASSUME_NONNULL_END
