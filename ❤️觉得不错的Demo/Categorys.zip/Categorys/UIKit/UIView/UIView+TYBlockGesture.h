//
//  UIView+TYBlockGesture.h
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^TYGestureActionBlock)(UIGestureRecognizer *gestureRecoginzer);

@interface UIView (TYBlockGesture)

/**
 *  @brief  添加tap手势
 *
 *  @param block 代码块
 */
- (void)ty_addTapActionWithBlock:(TYGestureActionBlock)block;
/**
 *  @brief  添加长按手势
 *
 *  @param block 代码块
 */
- (void)ty_addLongPressActionWithBlock:(TYGestureActionBlock)block;

@end
