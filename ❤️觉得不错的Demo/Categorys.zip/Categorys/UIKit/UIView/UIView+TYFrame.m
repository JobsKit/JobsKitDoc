//
//  UIView+TYFrame.m
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIView+TYFrame.h"
#import <objc/runtime.h>

static const char *kTyPlaceSizePropertyKey           = "kTyPlaceSizePropertyKey";
@implementation UIView (TYFrame)

#pragma mark - Shortcuts for the coords

- (CGFloat)ty_x {
    return self.frame.origin.x;
}

- (void)setTy_x:(CGFloat)x {
    CGRect frame = self.frame;
    frame.origin.x = x;
    self.frame = frame;
}

-(CGFloat)ty_y {
    return self.frame.origin.y;
}

- (void)setTy_y:(CGFloat)y {
    CGRect frame = self.frame;
    frame.origin.y = y;
    self.frame = frame;
}

- (CGFloat)ty_top
{
    return self.frame.origin.y;
}

- (void)setTy_top:(CGFloat)y
{
    CGRect frame = self.frame;
    frame.origin.y = y;
    self.frame = frame;
}

- (CGFloat)ty_right
{
    return self.frame.origin.x + self.frame.size.width;
}

- (void)setTy_right:(CGFloat)right
{
    CGRect frame = self.frame;
    frame.origin.x = right - self.frame.size.width;
    self.frame = frame;
}

- (CGFloat)ty_bottom
{
    return self.frame.origin.y + self.frame.size.height;
}

- (void)setTy_bottom:(CGFloat)bottom
{
    CGRect frame = self.frame;
    frame.origin.y = bottom - self.frame.size.height;
    self.frame = frame;
}

- (CGFloat)ty_left
{
    return self.frame.origin.x;
}

- (void)setTy_left:(CGFloat)x
{
    CGRect frame = self.frame;
    frame.origin.x = x;
    self.frame = frame;
}

- (CGFloat)ty_width
{
    return self.frame.size.width;
}

- (void)setTy_width:(CGFloat)width
{
    CGRect frame = self.frame;
    frame.size.width = width;
    self.frame = frame;
}

- (CGFloat)ty_height
{
    return self.frame.size.height;
}

- (void)setTy_height:(CGFloat)height
{
    CGRect frame = self.frame;
    frame.size.height = height;
    self.frame = frame;
}

#pragma mark - Shortcuts for frame properties

- (CGPoint)ty_origin {
    return self.frame.origin;
}

- (void)setTy_origin:(CGPoint)origin {
    CGRect frame = self.frame;
    frame.origin = origin;
    self.frame = frame;
}

- (CGSize)ty_size {
    return self.frame.size;
}

- (void)setTy_size:(CGSize)size {
    CGRect frame = self.frame;
    frame.size = size;
    self.frame = frame;
}
- (void)setTy_place_size:(CGSize)ty_place_size {
    objc_setAssociatedObject(self, kTyPlaceSizePropertyKey, [NSValue valueWithCGSize:ty_place_size], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
- (CGSize)ty_place_size {
    NSValue *val = objc_getAssociatedObject(self, kTyPlaceSizePropertyKey);
    if (val == nil || ![val isKindOfClass:[NSValue class]] || ![val respondsToSelector:@selector(CGSizeValue)]) {
        return CGSizeZero;
    }
    return [val CGSizeValue];
}
#pragma mark - Shortcuts for positions

- (CGFloat)ty_centerX {
    return self.center.x;
}

- (void)setTy_centerX:(CGFloat)centerX {
    self.center = CGPointMake(centerX, self.center.y);
}

- (CGFloat)ty_centerY {
    return self.center.y;
}

- (void)setTy_centerY:(CGFloat)centerY {
    self.center = CGPointMake(self.center.x, centerY);
}

- (CGFloat)borderWidth{
    return self.layer.borderWidth;
}

- (void)setBorderWidth:(CGFloat)borderWidth{
    self.layer.borderWidth = borderWidth;
}

- (void)setBorderColor:(UIColor *)borderColor{
    self.layer.borderColor = borderColor.CGColor;
}


- (CGFloat)cornerRadio{
    return self.layer.cornerRadius;
}

- (void)setCornerRadio:(CGFloat)cornerRadio{
    self.clipsToBounds = YES;
    self.layer.cornerRadius = cornerRadio;
}

@end
