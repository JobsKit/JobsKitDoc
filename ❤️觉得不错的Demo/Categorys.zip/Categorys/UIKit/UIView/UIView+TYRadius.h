//
//  UIView+TYRadius.h
//  XGames
//
//  Created by safi on 2019/8/2.
//  Copyright © 2019 XGames. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (TYRadius)


/**
 设置圆角

 @param radius 圆角半径
 @param corners UIRectCorner 任意角组合 UIRectCornerTopLeft | UIRectCornerBottomRight
 @param borderWidth borderWidth
 @param borderColor borderColor
 */
- (void)radius:(CGFloat)radius corners:(UIRectCorner)corners borderWidth:(CGFloat)borderWidth borderColor:(UIColor * _Nullable )borderColor;



@end

NS_ASSUME_NONNULL_END
