//
//  TYGradientView.m
//  YaboGames
//
//  Created by mannay on 10/03/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIView+GradientColors.h"
#import <objc/runtime.h>

static const void *kColors = &kColors;

@implementation UIView(GradientColors)

+ (Class)layerClass{
    return [CAGradientLayer class];
}

- (NSArray<UIColor *> *)colors{
    return objc_getAssociatedObject(self, kColors);
}

- (void)setColors:(NSArray<UIColor *> *)colors{
    objc_setAssociatedObject(self, kColors, colors, OBJC_ASSOCIATION_COPY_NONATOMIC);
    [self setupColors];
}

- (void)setupColors{
    NSInteger count = self.colors.count;
    if (count <= 1) {
        self.backgroundColor = self.colors.firstObject;
        return;
    }
    
    NSMutableArray *cgColors = [NSMutableArray array];
    for (NSInteger i = 0; i < count; i++) {
        [cgColors addObject: (id)self.colors[i].CGColor];
    }
    ((CAGradientLayer *)self.layer).colors = cgColors;
}

@end
