//
//  UIView+TYFrame.h
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (TYFrame)

@property (nonatomic, assign) CGPoint ty_origin;
@property (nonatomic, assign) CGSize ty_size;
@property (nonatomic, assign) CGSize ty_place_size;

@property (nonatomic) CGFloat ty_centerX;
@property (nonatomic) CGFloat ty_centerY;

@property (nonatomic) CGFloat ty_x;
@property (nonatomic) CGFloat ty_y;

@property (nonatomic) CGFloat ty_top;
@property (nonatomic) CGFloat ty_bottom;
@property (nonatomic) CGFloat ty_right;
@property (nonatomic) CGFloat ty_left;

@property (nonatomic) CGFloat ty_width;
@property (nonatomic) CGFloat ty_height;

@property (nonatomic) UIColor *borderColor;//只有setter方法，无getter方法
@property (nonatomic) CGFloat borderWidth;
@property (nonatomic) CGFloat cornerRadio;

@end
