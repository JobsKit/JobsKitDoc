//
//  UIView+TYRadius.m
//  XGames
//
//  Created by safi on 2019/8/2.
//  Copyright © 2019 XGames. All rights reserved.
//

#import "UIView+TYRadius.h"

@implementation UIView (TYRadius)


- (void)radius:(CGFloat)radius corners:(UIRectCorner)corners borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)borderColor {
    
    CGRect rect = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:rect byRoundingCorners:corners cornerRadii:CGSizeMake(radius, radius)];
    
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = rect;
    maskLayer.path = maskPath.CGPath;
    
    self.layer.mask = maskLayer;
    
    if (borderWidth > 0 || borderColor) {
        CAShapeLayer *borderLayer = [CAShapeLayer layer];
        borderLayer.frame = rect;
        borderLayer.lineWidth = borderWidth;
        borderLayer.strokeColor = borderColor.CGColor;
        borderLayer.fillColor = UIColor.clearColor.CGColor;
        borderLayer.path = maskPath.CGPath;
        [self.layer insertSublayer:borderLayer atIndex:0];
    }
}
@end
