//
//  UITextField+TYPlaceHolder.m
//  YaboSports
//
//  Created by corin on 2019/11/4.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UITextField+TYPlaceHolder.h"
#import "UIFont+TYAdd.h"

@implementation UITextField (TYPlaceHolder)

+ (NSAttributedString *)attPlaceHolderWithDefaultStyle:(NSString *)placeHolder {
    NSParameterAssert(placeHolder);
    UIFont *font = SystemFont(12);
    return [self attPlaceHolder:placeHolder font:font color:UIColor.redColor];
}

+ (NSAttributedString *)attPlaceHolder:(NSString *)placeHolder font:(UIFont *)font color:(UIColor *)color {
    NSParameterAssert(placeHolder);
    NSParameterAssert(font);
    NSParameterAssert(color);
    NSAttributedString *attrStr = [[NSAttributedString alloc] initWithString:placeHolder attributes:@{
        NSFontAttributeName: font,
        NSForegroundColorAttributeName: color,
    }];
    return attrStr;
}

@end
