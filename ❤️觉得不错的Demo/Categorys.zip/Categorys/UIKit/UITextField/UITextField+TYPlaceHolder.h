//
//  UITextField+TYPlaceHolder.h
//  YaboSports
//
//  Created by corin on 2019/11/4.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@interface UITextField (TYPlaceHolder)
// 默认颜色的placeHolder
+ (NSAttributedString *)attPlaceHolderWithDefaultStyle:(NSString *)placeHolder;

+ (NSAttributedString *)attPlaceHolder:(NSString *)placeHolder font:(UIFont *)font color:(UIColor *)color;
@end

NS_ASSUME_NONNULL_END
