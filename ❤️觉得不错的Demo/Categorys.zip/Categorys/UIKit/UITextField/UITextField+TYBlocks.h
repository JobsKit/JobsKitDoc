//
//  UITextField+TYBlocks.h
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (TYBlocks)

@property (copy, nonatomic) BOOL (^ty_shouldBegindEditingBlock)(UITextField *textField);
@property (copy, nonatomic) BOOL (^ty_shouldEndEditingBlock)(UITextField *textField);
@property (copy, nonatomic) void (^ty_didBeginEditingBlock)(UITextField *textField);
@property (copy, nonatomic) void (^ty_didEndEditingBlock)(UITextField *textField);
@property (copy, nonatomic) BOOL (^ty_shouldChangeCharactersInRangeBlock)(UITextField *textField, NSRange range, NSString *replacementString);
@property (copy, nonatomic) BOOL (^ty_shouldReturnBlock)(UITextField *textField);
@property (copy, nonatomic) BOOL (^ty_shouldClearBlock)(UITextField *textField);

- (void)setTy_shouldBegindEditingBlock:(BOOL (^)(UITextField *textField))shouldBegindEditingBlock;
- (void)setTy_shouldEndEditingBlock:(BOOL (^)(UITextField *textField))shouldEndEditingBlock;
- (void)setTy_didBeginEditingBlock:(void (^)(UITextField *textField))didBeginEditingBlock;
- (void)setTy_didEndEditingBlock:(void (^)(UITextField *textField))didEndEditingBlock;
- (void)setTy_shouldChangeCharactersInRangeBlock:(BOOL (^)(UITextField *textField, NSRange range, NSString *string))shouldChangeCharactersInRangeBlock;
- (void)setTy_shouldClearBlock:(BOOL (^)(UITextField *textField))shouldClearBlock;
- (void)setTy_shouldReturnBlock:(BOOL (^)(UITextField *textField))shouldReturnBlock;

@end
