//
//  UITextField+TYBlocks.m
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UITextField+TYBlocks.h"
#import <objc/runtime.h>

typedef BOOL (^TYUITextFieldReturnBlock) (UITextField *textField);
typedef void (^TYUITextFieldVoidBlock) (UITextField *textField);
typedef BOOL (^TYUITextFieldCharacterChangeBlock) (UITextField *textField, NSRange range, NSString *replacementString);

@implementation UITextField (TYBlocks)

static const void *TYUITextFieldDelegateKey = &TYUITextFieldDelegateKey;
static const void *TYUITextFieldShouldBeginEditingKey = &TYUITextFieldShouldBeginEditingKey;
static const void *TYUITextFieldShouldEndEditingKey = &TYUITextFieldShouldEndEditingKey;
static const void *TYUITextFieldDidBeginEditingKey = &TYUITextFieldDidBeginEditingKey;
static const void *TYUITextFieldDidEndEditingKey = &TYUITextFieldDidEndEditingKey;
static const void *TYUITextFieldShouldChangeCharactersInRangeKey = &TYUITextFieldShouldChangeCharactersInRangeKey;
static const void *TYUITextFieldShouldClearKey = &TYUITextFieldShouldClearKey;
static const void *TYUITextFieldShouldReturnKey = &TYUITextFieldShouldReturnKey;
#pragma mark UITextField Delegate methods
+ (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    TYUITextFieldReturnBlock block = textField.ty_shouldBegindEditingBlock;
    if (block) {
        return block(textField);
    }
    id delegate = objc_getAssociatedObject(self, TYUITextFieldDelegateKey);
    if ([delegate respondsToSelector:@selector(textFieldShouldBeginEditing:)]) {
        return [delegate textFieldShouldBeginEditing:textField];
    }
    // return default value just in case
    return YES;
}
+ (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    TYUITextFieldReturnBlock block = textField.ty_shouldEndEditingBlock;
    if (block) {
        return block(textField);
    }
    id delegate = objc_getAssociatedObject(self, TYUITextFieldDelegateKey);
    if ([delegate respondsToSelector:@selector(textFieldShouldEndEditing:)]) {
        return [delegate textFieldShouldEndEditing:textField];
    }
    // return default value just in case
    return YES;
}
+ (void)textFieldDidBeginEditing:(UITextField *)textField
{
    TYUITextFieldVoidBlock block = textField.ty_didBeginEditingBlock;
    if (block) {
        block(textField);
    }
    id delegate = objc_getAssociatedObject(self, TYUITextFieldDelegateKey);
    if ([delegate respondsToSelector:@selector(textFieldDidBeginEditing:)]) {
        [delegate textFieldDidBeginEditing:textField];
    }
}
+ (void)textFieldDidEndEditing:(UITextField *)textField
{
    TYUITextFieldVoidBlock block = textField.ty_didEndEditingBlock;
    if (block) {
        block(textField);
    }
    id delegate = objc_getAssociatedObject(self, TYUITextFieldDelegateKey);
    if ([delegate respondsToSelector:@selector(textFieldDidEndEditing:)]) {
        [delegate textFieldDidBeginEditing:textField];
    }
}
+ (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    TYUITextFieldCharacterChangeBlock block = textField.ty_shouldChangeCharactersInRangeBlock;
    if (block) {
        return block(textField,range,string);
    }
    id delegate = objc_getAssociatedObject(self, TYUITextFieldDelegateKey);
    if ([delegate respondsToSelector:@selector(textField:shouldChangeCharactersInRange:replacementString:)]) {
        return [delegate textField:textField shouldChangeCharactersInRange:range replacementString:string];
    }
    return YES;
}
+ (BOOL)textFieldShouldClear:(UITextField *)textField
{
    TYUITextFieldReturnBlock block = textField.ty_shouldClearBlock;
    if (block) {
        return block(textField);
    }
    id delegate = objc_getAssociatedObject(self, TYUITextFieldDelegateKey);
    if ([delegate respondsToSelector:@selector(textFieldShouldClear:)]) {
        return [delegate textFieldShouldClear:textField];
    }
    return YES;
}
+ (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    TYUITextFieldReturnBlock block = textField.ty_shouldReturnBlock;
    if (block) {
        return block(textField);
    }
    id delegate = objc_getAssociatedObject(self, TYUITextFieldDelegateKey);
    if ([delegate respondsToSelector:@selector(textFieldShouldReturn:)]) {
        return [delegate textFieldShouldReturn:textField];
    }
    return YES;
}
#pragma mark Block setting/getting methods
- (BOOL (^)(UITextField *))ty_shouldBegindEditingBlock
{
    return objc_getAssociatedObject(self, TYUITextFieldShouldBeginEditingKey);
}
- (void)setTy_shouldBegindEditingBlock:(BOOL (^)(UITextField *))shouldBegindEditingBlock
{
    [self ty_setDelegateIfNoDelegateSet];
    objc_setAssociatedObject(self, TYUITextFieldShouldBeginEditingKey, shouldBegindEditingBlock, OBJC_ASSOCIATION_COPY);
}
- (BOOL (^)(UITextField *))ty_shouldEndEditingBlock
{
    return objc_getAssociatedObject(self, TYUITextFieldShouldEndEditingKey);
}
- (void)setTy_shouldEndEditingBlock:(BOOL (^)(UITextField *))shouldEndEditingBlock
{
    [self ty_setDelegateIfNoDelegateSet];
    objc_setAssociatedObject(self, TYUITextFieldShouldEndEditingKey, shouldEndEditingBlock, OBJC_ASSOCIATION_COPY);
}
- (void (^)(UITextField *))ty_didBeginEditingBlock
{
    return objc_getAssociatedObject(self, TYUITextFieldDidBeginEditingKey);
}
- (void)setTy_didBeginEditingBlock:(void (^)(UITextField *))didBeginEditingBlock
{
    [self ty_setDelegateIfNoDelegateSet];
    objc_setAssociatedObject(self, TYUITextFieldDidBeginEditingKey, didBeginEditingBlock, OBJC_ASSOCIATION_COPY);
}
- (void (^)(UITextField *))ty_didEndEditingBlock
{
    return objc_getAssociatedObject(self, TYUITextFieldDidEndEditingKey);
}
- (void)setTy_didEndEditingBlock:(void (^)(UITextField *))didEndEditingBlock
{
    [self ty_setDelegateIfNoDelegateSet];
    objc_setAssociatedObject(self, TYUITextFieldDidEndEditingKey, didEndEditingBlock, OBJC_ASSOCIATION_COPY);
}
- (BOOL (^)(UITextField *, NSRange, NSString *))ty_shouldChangeCharactersInRangeBlock
{
    return objc_getAssociatedObject(self, TYUITextFieldShouldChangeCharactersInRangeKey);
}
- (void)setTy_shouldChangeCharactersInRangeBlock:(BOOL (^)(UITextField *, NSRange, NSString *))shouldChangeCharactersInRangeBlock
{
    [self ty_setDelegateIfNoDelegateSet];
    objc_setAssociatedObject(self, TYUITextFieldShouldChangeCharactersInRangeKey, shouldChangeCharactersInRangeBlock, OBJC_ASSOCIATION_COPY);
}
- (BOOL (^)(UITextField *))ty_shouldReturnBlock
{
    return objc_getAssociatedObject(self, TYUITextFieldShouldReturnKey);
}
- (void)setTy_shouldReturnBlock:(BOOL (^)(UITextField *))shouldReturnBlock
{
    [self ty_setDelegateIfNoDelegateSet];
    objc_setAssociatedObject(self, TYUITextFieldShouldReturnKey, shouldReturnBlock, OBJC_ASSOCIATION_COPY);
}
- (BOOL (^)(UITextField *))ty_shouldClearBlock
{
    return objc_getAssociatedObject(self, TYUITextFieldShouldClearKey);
}
- (void)setTy_shouldClearBlock:(BOOL (^)(UITextField *textField))shouldClearBlock
{
    [self ty_setDelegateIfNoDelegateSet];
    objc_setAssociatedObject(self, TYUITextFieldShouldClearKey, shouldClearBlock, OBJC_ASSOCIATION_COPY);
}
#pragma mark control method
/*
 Setting itself as delegate if no other delegate has been set. This ensures the UITextField will use blocks if no delegate is set.
 */
- (void)ty_setDelegateIfNoDelegateSet
{
    if (self.delegate != (id<UITextFieldDelegate>)[self class]) {
        objc_setAssociatedObject(self, TYUITextFieldDelegateKey, self.delegate, OBJC_ASSOCIATION_ASSIGN);
        self.delegate = (id<UITextFieldDelegate>)[self class];
    }
}

@end
