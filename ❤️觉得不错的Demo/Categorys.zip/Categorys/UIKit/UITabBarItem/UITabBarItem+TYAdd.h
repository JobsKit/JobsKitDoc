//
//  UITabBarItem+TYAdd.h
//  Project
//
//  Created by linker on 12/3/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITabBarItem (TYAdd)
///小红点
@property (nonatomic, strong) UIView                 *badgeView;

///添加badge
- (void)addBadgeView:(UIColor *)color borderColor:(UIColor *)borderColor;
@end

NS_ASSUME_NONNULL_END
