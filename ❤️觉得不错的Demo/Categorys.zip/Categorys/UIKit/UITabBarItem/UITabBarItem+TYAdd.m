//
//  UITabBarItem+TYAdd.m
//  Project
//
//  Created by linker on 12/3/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UITabBarItem+TYAdd.h"
#import <objc/runtime.h>
#import "UIImage+TYColor.h"

/// 个人中心 tabbar badge
static const NSInteger KMineBadgeViewTag = 90901;
static const char *kCustomBadgePropertyKey = "kCustomBadgePropertyKey";

@implementation UITabBarItem (TYAdd)

- (void)addBadgeView:(UIColor *)color borderColor:(UIColor *)borderColor{
    CGFloat xOffset = -7;
    CGFloat originY = -1;
    CGFloat badgeWidthH = 10;
    UIView *view = [self valueForKey:@"view"];
    if (view) {
        UIImage *img=  [UIImage ty_imageWithColor:color size:CGSizeMake(badgeWidthH, badgeWidthH)];
        for(UIView *subView in view.subviews) {
            NSString *str = NSStringFromClass([subView class]);
            if([str isEqualToString:@"UITabBarSwappableImageView"]) {
                UIImageView *badge = [[UIImageView alloc] initWithFrame:CGRectMake(subView.bounds.size.width + xOffset, originY, badgeWidthH, badgeWidthH)];
                badge.image = img;
                badge.layer.cornerRadius = badgeWidthH * 0.5;
                badge.layer.borderColor = borderColor.CGColor;
                badge.layer.borderWidth = 1.0;
                badge.layer.masksToBounds = YES;
                badge.tag = KMineBadgeViewTag;
                badge.hidden = YES;
                for (UIView *ssubView in subView.subviews) {
                    if (ssubView.tag == KMineBadgeViewTag) {
                        [ssubView removeFromSuperview];
                    }
                }
                [subView addSubview:badge];
                self.badgeView = badge;
            }
        }
    }
}

- (void)setBadgeView:(UIView *)badgeView {
    objc_setAssociatedObject(self, kCustomBadgePropertyKey, badgeView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UIView *)badgeView {
    return objc_getAssociatedObject(self, kCustomBadgePropertyKey);
}
@end
