//
//  UIControl+TYBlock.m
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIControl+TYBlock.h"
#import <objc/runtime.h>

#define TY_UICONTROL_EVENT(methodName, eventName)                                \
-(void)methodName : (void (^)(void))eventBlock {                              \
objc_setAssociatedObject(self, @selector(methodName:), eventBlock, OBJC_ASSOCIATION_COPY_NONATOMIC);\
[self addTarget:self                                                        \
action:@selector(methodName##Action:)                                       \
forControlEvents:UIControlEvent##eventName];                                \
}                                                                               \
-(void)methodName##Action:(id)sender {                                        \
void (^block)(void) = objc_getAssociatedObject(self, @selector(methodName:));  \
if (block) {                                                                \
block();                                                                \
}                                                                           \
}

@interface UIControl ()

@end

@implementation UIControl (TYBlock)

TY_UICONTROL_EVENT(ty_touchDown, TouchDown)
TY_UICONTROL_EVENT(ty_touchDownRepeat, TouchDownRepeat)
TY_UICONTROL_EVENT(ty_touchDragInside, TouchDragInside)
TY_UICONTROL_EVENT(ty_touchDragOutside, TouchDragOutside)
TY_UICONTROL_EVENT(ty_touchDragEnter, TouchDragEnter)
TY_UICONTROL_EVENT(ty_touchDragExit, TouchDragExit)
TY_UICONTROL_EVENT(ty_touchUpInside, TouchUpInside)
TY_UICONTROL_EVENT(ty_touchUpOutside, TouchUpOutside)
TY_UICONTROL_EVENT(ty_touchCancel, TouchCancel)
TY_UICONTROL_EVENT(ty_valueChanged, ValueChanged)
TY_UICONTROL_EVENT(ty_editingDidBegin, EditingDidBegin)
TY_UICONTROL_EVENT(ty_editingChanged, EditingChanged)
TY_UICONTROL_EVENT(ty_editingDidEnd, EditingDidEnd)
TY_UICONTROL_EVENT(ty_editingDidEndOnExit, EditingDidEndOnExit)

@end
