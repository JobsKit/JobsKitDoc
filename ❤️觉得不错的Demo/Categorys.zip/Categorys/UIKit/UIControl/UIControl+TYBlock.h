//
//  UIControl+TYBlock.h
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIControl (TYBlock)

- (void)ty_touchDown:(void (^)(void))eventBlock;
- (void)ty_touchDownRepeat:(void (^)(void))eventBlock;
- (void)ty_touchDragInside:(void (^)(void))eventBlock;
- (void)ty_touchDragOutside:(void (^)(void))eventBlock;
- (void)ty_touchDragEnter:(void (^)(void))eventBlock;
- (void)ty_touchDragExit:(void (^)(void))eventBlock;
- (void)ty_touchUpInside:(void (^)(void))eventBlock;
- (void)ty_touchUpOutside:(void (^)(void))eventBlock;
- (void)ty_touchCancel:(void (^)(void))eventBlock;
- (void)ty_valueChanged:(void (^)(void))eventBlock;
- (void)ty_editingDidBegin:(void (^)(void))eventBlock;
- (void)ty_editingChanged:(void (^)(void))eventBlock;
- (void)ty_editingDidEnd:(void (^)(void))eventBlock;
- (void)ty_editingDidEndOnExit:(void (^)(void))eventBlock;

@end
