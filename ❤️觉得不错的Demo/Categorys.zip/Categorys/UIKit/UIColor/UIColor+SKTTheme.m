//
//  UIColor+SKTTheme.m
//  FirefoxGames
//
//  Created by YBJS-YF-D00714 on 2020/11/11.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "UIColor+SKTTheme.h"

@implementation UIColor (SKTTheme)

+ (UIImage *)skt_btnGradientNormalForWith:(CGFloat)width {
    CGSize size = CGSizeMake(width, 1);
    UIColor *startColor = UIColor.SKTF_Button_Gradient_Start;
    UIColor *endColor = UIColor.SKTF_Button_Gradient_End;
    UIImage *image = [self ty_gradientImageFromColor:startColor
                                             toColor:endColor
                                            endPoint:CGPointMake(size.width, size.height)
                                            withSize:size];
    return image;
}

+ (UIImage *)skt_btnGradientDisableForWith:(CGFloat)width {
    return [self skt_btnGradientNormalForWith:width];
}

+ (UIColor *)skt_btnGradientColorNormalWithWith:(CGFloat)width {
    UIColor *startColor = Color.GradientColor_StartMainColor;
    UIColor *endColor = Color.GradientColor_EndMainColor;
    return [UIColor ty_gradientFromColor:startColor toColor:endColor withWidth:width];
}

+ (UIColor *)skt_btnGradientColorDisableWithWith:(CGFloat)width {
    return [self skt_btnGradientColorNormalWithWith:width];
}
@end
