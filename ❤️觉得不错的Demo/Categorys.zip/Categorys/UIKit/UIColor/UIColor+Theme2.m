//
//  UIColor+Theme.m
//  YaboGames
//
//  Created by mannay on 09/03/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIColor+Theme2.h"
#import "YBDefine.h"

static NSArray *_themGradientColors;

@implementation UIColor (Theme2)

+ (DKColorPicker)ty_setThemColor:(UIColor *)lightColor darkColor:(UIColor *)darkColor {
    UIColor *color = lightColor;
    return DKColorPickerWithColors(color, color);
}

/// 获取主题渐变色（不包含黑夜模式）
+ (UIColor*)ty_gradientMainColorWithSize:(CGSize)size {
    UIColor *fromColor = Color.GradientColor_StartMainColor;
    UIColor *toColor = Color.GradientColor_EndMainColor;
    return [UIColor ty_gradientFromColor:fromColor
                                 toColor:toColor
                                withSize:size];
}

/// 获取主题渐变色
+ (UIColor*)ty_gradientMainColorWithSizeDark:(CGSize)size {
    UIColor *fromColor = Color.GradientColor_StartMainColor;
    UIColor *toColor = Color.GradientColor_EndMainColor;
    return [UIColor ty_gradientFromColor:fromColor
                                 toColor:toColor
                                endPoint:CGPointMake(size.width, size.height)
                                withSize:size];
}

+ (void)ty_updateThemGradientColors:(NSArray *)colors {
    NSAssert(colors.count == 2, @"主题色配置错误");
    _themGradientColors = colors;
}

+ (UIImage *)ty_gradientMainColorDarkNormalFroWidth:(CGFloat)width{
    CGSize size = CGSizeMake(width, 1);
    UIColor *fromColor = Color.GradientColor_StartMainColor;
    UIColor *toColor = Color.GradientColor_EndMainColor;
    UIImage *image = [self ty_gradientImageFromColor:fromColor
                                             toColor:toColor
                                            endPoint:CGPointMake(size.width, size.height)
                                            withSize:size];
    return image;
}

+ (UIImage *)ty_gradientMainColorDarkDisableFroWidth:(CGFloat)width{
    CGSize size = CGSizeMake(width, 1);
    UIColor *fromColor = [UIColor.GradientColor_StartMainColor colorWithAlphaComponent:0.5];
    UIColor *toColor = [UIColor.GradientColor_EndMainColor colorWithAlphaComponent:0.5];
    UIImage *image = [self ty_gradientImageFromColor:fromColor
                                             toColor:toColor
                                            endPoint:CGPointMake(size.width, size.height)
                                            withSize:size];
    return image;
}

+ (UIImage *)ty_gradientFromColor:(UIColor *)fromColor toColor:(UIColor *)toColor Width:(CGFloat)width {
    CGSize size = CGSizeMake(width, 1);
    UIImage *image = [self ty_gradientImageFromColor:fromColor
                                             toColor:toColor
                                            endPoint:CGPointMake(size.width, size.height)
                                            withSize:size];
    return image;
}
@end
