//
//  UIColor+TYGradient.h
//  YaboGames
//
//  Created by eagle on 18/02/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (TYGradient)

+ (UIColor*)ty_gradientFromColor:(UIColor*)c1 toColor:(UIColor*)c2 withWidth:(int)width;

+ (UIColor*)ty_gradientFromColor:(UIColor*)c1 toColor:(UIColor*)c2 withHeight:(int)height;
    
@end

NS_ASSUME_NONNULL_END
