//
//  UIColor+SKTTheme.h
//  FirefoxGames
//
//  Created by YBJS-YF-D00714 on 2020/11/11.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (SKTTheme)

// SKT站中使用的普通状态时的渐变颜色
+ (UIImage *)skt_btnGradientNormalForWith:(CGFloat)width;

// SKT站中使用的禁用状态时的渐变颜色
+ (UIImage *)skt_btnGradientDisableForWith:(CGFloat)width;


+ (UIColor *)skt_btnGradientColorNormalWithWith:(CGFloat)width;


+ (UIColor *)skt_btnGradientColorDisableWithWith:(CGFloat)width;

@end

NS_ASSUME_NONNULL_END
