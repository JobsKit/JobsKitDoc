//
//  UIColor+Theme.h
//  YaboGames
//
//  Created by mannay on 09/03/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (Theme2)

+ (UIColor *)ty_gradientMainColorWithSize:(CGSize)size;
+ (UIColor *)ty_gradientMainColorWithSizeDark:(CGSize)size;
+ (UIImage *)ty_gradientMainColorDarkNormalFroWidth:(CGFloat)width;
+ (UIImage *)ty_gradientMainColorDarkDisableFroWidth:(CGFloat)width;
+ (UIImage *)ty_gradientFromColor:(UIColor *)fromColor toColor:(UIColor *)toColor Width:(CGFloat)width;
+ (void)ty_updateThemGradientColors:(NSArray *)colors;
+ (DKColorPicker)ty_setThemColor:(UIColor *)lightColor darkColor:(UIColor *)darkColor;
@end

NS_ASSUME_NONNULL_END
