//
//  UIScrollView+TYAddition.h
//  YaboSports
//
//  Created by windy on 17/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, TYScrollDirection) {
    TYScrollDirectionUp,
    TYScrollDirectionDown,
    TYScrollDirectionLeft,
    TYScrollDirectionRight,
    TYScrollDirectionWTF
};

NS_ASSUME_NONNULL_BEGIN

@interface UIScrollView (TYAddition)

@property(nonatomic) CGFloat ty_contentWidth;
@property(nonatomic) CGFloat ty_contentHeight;
@property(nonatomic) CGFloat ty_contentOffsetX;
@property(nonatomic) CGFloat ty_contentOffsetY;

- (CGPoint)ty_topContentOffset;
- (CGPoint)ty_bottomContentOffset;
- (CGPoint)ty_leftContentOffset;
- (CGPoint)ty_rightContentOffset;

- (TYScrollDirection)ty_ScrollDirection;

- (BOOL)ty_isScrolledToTop;
- (BOOL)ty_isScrolledToBottom;
- (BOOL)ty_isScrolledToLeft;
- (BOOL)ty_isScrolledToRight;
- (void)ty_scrollToTopAnimated:(BOOL)animated;
- (void)ty_scrollToBottomAnimated:(BOOL)animated;
- (void)ty_scrollToLeftAnimated:(BOOL)animated;
- (void)ty_scrollToRightAnimated:(BOOL)animated;

- (NSUInteger)ty_verticalPageIndex;
- (NSUInteger)ty_horizontalPageIndex;

- (void)ty_scrollToVerticalPageIndex:(NSUInteger)pageIndex animated:(BOOL)animated;
- (void)ty_scrollToHorizontalPageIndex:(NSUInteger)pageIndex animated:(BOOL)animated;

@end

NS_ASSUME_NONNULL_END
