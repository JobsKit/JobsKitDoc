//
//  UIScrollView+TYAddition.m
//  YaboSports
//
//  Created by windy on 17/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIScrollView+TYAddition.h"

@implementation UIScrollView (TYAddition)

//frame
- (CGFloat)ty_contentWidth {
    return self.contentSize.width;
}
- (void)setTy_contentWidth:(CGFloat)width {
    self.contentSize = CGSizeMake(width, self.frame.size.height);
}
- (CGFloat)ty_contentHeight {
    return self.contentSize.height;
}
- (void)setTy_contentHeight:(CGFloat)height {
    self.contentSize = CGSizeMake(self.frame.size.width, height);
}
- (CGFloat)ty_contentOffsetX {
    return self.contentOffset.x;
}
- (void)setTy_contentOffsetX:(CGFloat)x {
    self.contentOffset = CGPointMake(x, self.contentOffset.y);
}
- (CGFloat)ty_contentOffsetY {
    return self.contentOffset.y;
}
- (void)setTy_contentOffsetY:(CGFloat)y {
    self.contentOffset = CGPointMake(self.contentOffset.x, y);
}
//


- (CGPoint)ty_topContentOffset
{
    return CGPointMake(0.0f, -self.contentInset.top);
}
- (CGPoint)ty_bottomContentOffset
{
    return CGPointMake(0.0f, self.contentSize.height + self.contentInset.bottom - self.bounds.size.height);
}
- (CGPoint)ty_leftContentOffset
{
    return CGPointMake(-self.contentInset.left, 0.0f);
}
- (CGPoint)ty_rightContentOffset
{
    return CGPointMake(self.contentSize.width + self.contentInset.right - self.bounds.size.width, 0.0f);
}
- (TYScrollDirection)ty_ScrollDirection
{
    TYScrollDirection direction;
    
    if ([self.panGestureRecognizer translationInView:self.superview].y > 0.0f)
    {
        direction = TYScrollDirectionUp;
    }
    else if ([self.panGestureRecognizer translationInView:self.superview].y < 0.0f)
    {
        direction = TYScrollDirectionDown;
    }
    else if ([self.panGestureRecognizer translationInView:self].x < 0.0f)
    {
        direction = TYScrollDirectionLeft;
    }
    else if ([self.panGestureRecognizer translationInView:self].x > 0.0f)
    {
        direction = TYScrollDirectionRight;
    }
    else
    {
        direction = TYScrollDirectionWTF;
    }
    
    return direction;
}
- (BOOL)ty_isScrolledToTop
{
    return self.contentOffset.y <= [self ty_topContentOffset].y;
}
- (BOOL)ty_isScrolledToBottom
{
    return self.contentOffset.y >= [self ty_bottomContentOffset].y;
}
- (BOOL)ty_isScrolledToLeft
{
    return self.contentOffset.x <= [self ty_leftContentOffset].x;
}
- (BOOL)ty_isScrolledToRight
{
    return self.contentOffset.x >= [self ty_rightContentOffset].x;
}
- (void)ty_scrollToTopAnimated:(BOOL)animated
{
    [self setContentOffset:[self ty_topContentOffset] animated:animated];
}
- (void)ty_scrollToBottomAnimated:(BOOL)animated
{
    [self setContentOffset:[self ty_bottomContentOffset] animated:animated];
}
- (void)ty_scrollToLeftAnimated:(BOOL)animated
{
    [self setContentOffset:[self ty_leftContentOffset] animated:animated];
}
- (void)ty_scrollToRightAnimated:(BOOL)animated
{
    [self setContentOffset:[self ty_rightContentOffset] animated:animated];
}
- (NSUInteger)ty_verticalPageIndex
{
    return (self.contentOffset.y + (self.frame.size.height * 0.5f)) / self.frame.size.height;
}
- (NSUInteger)ty_horizontalPageIndex
{
    return (self.contentOffset.x + (self.frame.size.width * 0.5f)) / self.frame.size.width;
}
- (void)ty_scrollToVerticalPageIndex:(NSUInteger)pageIndex animated:(BOOL)animated
{
    [self setContentOffset:CGPointMake(0.0f, self.frame.size.height * pageIndex) animated:animated];
}
- (void)ty_scrollToHorizontalPageIndex:(NSUInteger)pageIndex animated:(BOOL)animated
{
    [self setContentOffset:CGPointMake(self.frame.size.width * pageIndex, 0.0f) animated:animated];
}


@end
