//
//  UILabel+Copy.h
//  FirefoxGames
//
//  Created by Freddie on 4/21/20.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UILabel (Copy)

@property (nonatomic,assign) BOOL isCopyable;

@end
NS_ASSUME_NONNULL_END
