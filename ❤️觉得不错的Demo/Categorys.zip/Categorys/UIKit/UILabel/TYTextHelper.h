//
//  TYTextHelper.h
//  Project
//
//  Created by linker on 12/3/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface TYTextHelper : NSObject

/**
 * 获取UILabel点击的字符
 * @param location 点击label的位置
 * @param label 点击的label
 * @param selectedBlock 点击返回
 */
- (void)selectLocation:(CGPoint)location OfLabel:(UILabel *)label selectedBlock:(void (^)(NSInteger index,NSAttributedString *charAttributedString))selectedBlock;

@end
