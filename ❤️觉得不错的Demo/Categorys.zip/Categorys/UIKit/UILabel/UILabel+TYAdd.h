//
//  UILabel+TYAdd.h
//  Project
//
//  Created by linker on 12/3/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface UILabel (TYLabelCategory)

/**
 * 点击回调
 * @param ty_tapBlock index 没有点到时返回-1;charAttributedString 选中的字符的属性字符串
 */
@property (nonatomic,copy) void (^ty_tapBlock)(NSInteger index,NSAttributedString *charAttributedString);


/**
 设置文本,并指定行间距(一定是先赋值了text才有效)

 @param lineSpacing 行间距
 */
-(void)setTextlineSpacing:(CGFloat)lineSpacing;

+ (UILabel *)ty_labelWithFont:(UIFont *)font color:(UIColor *)color text:(NSString *)text;
+ (UILabel *)ty_labelWithFonts:(NSArray<UIFont *> *)fonts colors:(NSArray<UIColor *> *)colors texts:(NSArray<NSString *> *)texts;
@end
