//
//  UILabel+TYAdd.m
//  Project
//
//  Created by linker on 12/3/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//


#import "UILabel+TYAdd.h"
#import "TYTextHelper.h"
#import <objc/runtime.h>

NSString const *TY_TapBlock = @"TY_TapBlock";
NSString const *TY_TextHelper = @"TY_TextHelper";

@interface UILabel ()

@property (nonatomic,strong) TYTextHelper *ty_textHelper;

@end

@implementation UILabel (TYLabelCategory)

- (void)setTy_tapBlock:(void (^)(NSInteger, NSAttributedString *))ty_tapBlock {
    objc_setAssociatedObject(self, &TY_TapBlock, ty_tapBlock, OBJC_ASSOCIATION_COPY);
    self.userInteractionEnabled = YES;
    TYTextHelper *textHelper = [[TYTextHelper alloc]init];
    self.ty_textHelper = textHelper;
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(ty_tapAction:)];
    [self addGestureRecognizer:tapGestureRecognizer];
}
- (void (^)(NSInteger, NSAttributedString *))ty_tapBlock {
    return objc_getAssociatedObject(self, &TY_TapBlock);
}
- (void)setTy_textHelper:(TYTextHelper *)ty_textHelper {
    objc_setAssociatedObject(self, &TY_TextHelper, ty_textHelper, OBJC_ASSOCIATION_RETAIN);
}
- (TYTextHelper *)ty_textHelper {
    return objc_getAssociatedObject(self, &TY_TextHelper);
}
#pragma mark -Event
- (void)ty_tapAction:(UITapGestureRecognizer *)recognizer {
    CGPoint location = [recognizer locationInView:recognizer.view];
//    NSLog(@"location = %@",NSStringFromCGPoint(location));
    __weak UILabel *weakSelf = self;
    [self.ty_textHelper selectLocation:location OfLabel:(UILabel *)recognizer.view selectedBlock:^(NSInteger index, NSAttributedString *charAttributedString) {
        if (weakSelf.ty_tapBlock && index >= 0) {
            weakSelf.ty_tapBlock(index,charAttributedString);
        }
    }];
}

-(void)setTextlineSpacing:(CGFloat)lineSpacing {
    if (!self.text || lineSpacing < 0.01) {
        return;
    }
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:lineSpacing];        //设置行间距
    [paragraphStyle setLineBreakMode:self.lineBreakMode];
    [paragraphStyle setAlignment:self.textAlignment];
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:self.text];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [self.text length])];
    self.attributedText = attributedString;
}

+ (UILabel *)ty_labelWithFont:(UIFont *)font color:(UIColor *)color text:(NSString *)text {
    UILabel *label = [[UILabel alloc] init];
    label.font = font;
    label.textColor = color;
    label.text = text;
    label.numberOfLines = 0;
    return label;
}
+ (UILabel *)ty_labelWithFonts:(NSArray<UIFont *> *)fonts colors:(NSArray<UIColor *> *)colors texts:(NSArray<NSString *> *)texts {
    UILabel *label = [[UILabel alloc] init];
    NSString *text = [texts componentsJoinedByString:@""];
    label.numberOfLines = 0;
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc] initWithString:text];
    NSInteger from = 0;
    for (NSInteger i=0;i<texts.count;i++) {
        NSString *str = texts[i];
        if (fonts.count>i) {
            [attr addAttribute:NSFontAttributeName value:fonts[i] range:NSMakeRange(from, str.length)];
        }
        if (colors.count>i) {
            [attr addAttribute:NSForegroundColorAttributeName value:colors[i] range:NSMakeRange(from, str.length)];
        }
        from = from+str.length;
    }
     label.attributedText = attr;
    return label;
}
@end
