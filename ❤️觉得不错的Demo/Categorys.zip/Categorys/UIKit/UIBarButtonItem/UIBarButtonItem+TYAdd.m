//
//  UIBarButtonItem+TYAdd.m
//  Project
//
//  Created by linker on 5/3/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIBarButtonItem+TYAdd.h"
#import "UIView+TYFrame.h"
#import "NSString+TYSize.h"

@implementation UIBarButtonItem (TYAdd)

+ (instancetype)navbarButtonItemWithImage:(UIImage *)image target:(id)target selector:(SEL)selector{
    return [UIBarButtonItem navbarButtonItemWithTitle:nil
                                                image:image
                                      imageEdgeInsets:UIEdgeInsetsZero
                                               target:target
                                             selector:selector];
}

+ (instancetype)navbarButtonItemWithTitle:(NSString *)title target:(id)target selector:(SEL)selector {
    return [UIBarButtonItem navbarButtonItemWithTitle:nil
                                                image:nil
                                      imageEdgeInsets:UIEdgeInsetsZero
                                               target:target
                                             selector:selector];
}

+ (instancetype)navbarButtonItemWithImage:(UIImage *)image imageEdgeInsets:(UIEdgeInsets)imageEdgeInsets target:(id)target selector:(SEL)selector{
    return [UIBarButtonItem navbarButtonItemWithTitle:nil
                                                image:image
                                      imageEdgeInsets:imageEdgeInsets
                                               target:target
                                             selector:selector];
}

+ (instancetype)navbarButtonItemWithTitle:(NSString *)title image:(UIImage *)image imageEdgeInsets:(UIEdgeInsets)imageEdgeInsets target:(id)target selector:(SEL)selector {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.bounds = CGRectMake(0, 0, 44, 44);
    button.titleLabel.font = [UIFont systemFontOfSize:14];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    if (image) {
        [button setImage:image forState:UIControlStateNormal];
        button.imageEdgeInsets = imageEdgeInsets;
    } else if (title.length > 0) {
        [button setTitle:title forState:UIControlStateNormal];
        // 计算按钮的宽度
        button.ty_width = 10 + [title ty_sizeWithFont:button.titleLabel.font constrainedToWidth:200].width;
    }
    [button addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
    return [[self alloc] initWithCustomView:button];
}


@end
