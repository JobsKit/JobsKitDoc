//
//  UIBarButtonItem+TYAdd.h
//  Project
//
//  Created by linker on 5/3/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIBarButtonItem (TYAdd)

/**
 UIBarButtonItem

 @param image 图标
 @param target 绑定目标
 @param selector 方法选择器
 @return 实例
 */
+ (instancetype)navbarButtonItemWithImage:(UIImage *)image
                                   target:(id)target
                                 selector:(SEL)selector;

/**
 UIBarButtonItem
 
 @param title 标题
 @param target 绑定目标
 @param selector 方法选择器
 @return 实例
 */
+ (instancetype)navbarButtonItemWithTitle:(NSString *)title
                                   target:(id)target
                                 selector:(SEL)selector;
/**
UIBarButtonItem

@param image 图片
@param target 绑定目标
@param imageEdgeInsets 图片内边距
@param selector 方法选择器
@return 实例
*/
+ (instancetype)navbarButtonItemWithImage:(UIImage *)image imageEdgeInsets:(UIEdgeInsets)imageEdgeInsets target:(id)target selector:(SEL)selector;

@end

NS_ASSUME_NONNULL_END
