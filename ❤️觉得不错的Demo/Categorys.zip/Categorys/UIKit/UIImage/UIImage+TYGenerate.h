//
//  UIImage+TYGenerate.h
//  XGenericSDK
//
//  Created by safi on 2019/12/27.
//

#import <UIKit/UIKit.h>

static NSString * _Nonnull itemContent = @"itemContent";
static NSString * _Nonnull itemFrame = @"itemFrame";
static NSString * _Nonnull textAttribute = @"textAttribute";

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (TYGenerate)


/**
 二维码图片生成

 @param code 二维码内容
 @param size 二维码图片t大小
 @return 二维码图片
 */
+ (UIImage *)generateQRCode:(NSString *)code size:(CGSize)size;

@end

NS_ASSUME_NONNULL_END
