//
//  UIImage+TYImageBase64Convert.h
//  YaboGames
//
//  Created by Allon on 2019/7/29.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (TYImageBase64)

/**
 64base字符串转图片

 @param str 64base字符
 @return image图片
 */
+ (UIImage *)ty_stringToImage:(NSString *)str;

/**
 图片转64base字符串

 @param image image图片
 @return 64base字符串
 */
+ (NSString *)ty_imageToString:(UIImage *)image;
@end

NS_ASSUME_NONNULL_END
