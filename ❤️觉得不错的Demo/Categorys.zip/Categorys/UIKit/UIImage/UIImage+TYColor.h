//
//  UIImage+TYColor.h
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (TYColor)

/**
 *  @brief  根据颜色生成纯色图片
 *
 *  @param color 颜色
 *  @return 纯色图片
 */
+ (UIImage *)ty_imageWithColor:(UIColor *)color;

+ (UIImage *)ty_imageWithColor:(UIColor *)color size:(CGSize)size;
+ (UIImage *)ty_imageWithColor:(UIColor *)color radius:(CGFloat)radius;
/**tu
 *  @brief  取图片某一点的颜色
 *
 *  @param point 某一点
 *
 *  @return 颜色
 */
- (UIColor *)ty_colorAtPoint:(CGPoint )point;
//more accurate method ,colorAtPixel 1x1 pixel
/**
 *  @brief  取某一像素的颜色
 *
 *  @param point 一像素
 *
 *  @return 颜色
 */
- (UIColor *)ty_colorAtPixel:(CGPoint)point;
/**
 *  @brief  返回该图片是否有透明度通道
 *
 *  @return 是否有透明度通道
 */
- (BOOL)ty_hasAlphaChannel;

/**
 *  @brief  获得灰度图
 *
 *  @param sourceImage 图片
 *
 *  @return 获得灰度图片
 */
+ (UIImage*)ty_covertToGrayImageFromImage:(UIImage*)sourceImage;
/**
*  获取矩形的渐变色的UIImage(此函数还不够完善)
*
*  @param bounds       UIImage的bounds
*  @param colors       渐变色数组，可以设置两种颜色
*  @param gradientType 渐变的方式：0--->从上到下   1--->从左到右
*
*  @return 渐变色的UIImage
*/
+ (UIImage*)gradientImageWithBounds:(CGRect)bounds andColors:(NSArray*)colors andGradientType:(int)gradientType;

- (UIImage *)changeImageColorWithTintColor:(UIColor *)tintColor;
@end
