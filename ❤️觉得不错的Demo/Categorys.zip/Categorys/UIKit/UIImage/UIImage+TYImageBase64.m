//
//  UIImage+TYImageBase64Convert.m
//  YaboGames
//
//  Created by Allon on 2019/7/29.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIImage+TYImageBase64.h"

@implementation UIImage (TYImageBase64)

// 64base字符串转图片
+ (UIImage *)ty_stringToImage:(NSString *)str {
    str = [str stringByReplacingOccurrencesOfString:@"data:image/png;base64," withString:@""];
    NSData *imageData =[[NSData alloc] initWithBase64EncodedString:str options:NSDataBase64DecodingIgnoreUnknownCharacters];
    UIImage *photo = [UIImage imageWithData:imageData ];
    return photo;
}

// 图片转64base字符串
+ (NSString *)ty_imageToString:(UIImage *)image {
    NSData *imagedata = UIImagePNGRepresentation(image);
    NSString *image64 = [imagedata base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    return image64;
    
}

@end
