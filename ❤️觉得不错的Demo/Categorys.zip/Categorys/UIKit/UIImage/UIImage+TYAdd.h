//
//  UIImage+TYAdd.h
//  YaboGames
//
//  Created by linker on 17/3/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DKImage.h"

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (TYAdd)

/**
 压缩图片

 @param image 原图
 @param byte 最大限制
 @return 压缩图
 */
+ (instancetype)compressBaseImage:(UIImage *)image maxByte:(CGFloat)byte;

+ (UIImage *)qr_imageWithSize:(CGSize)size Txt:(NSString *)txt;
/**
 获取图片

 @param imageName 图片名称
 @return 返回图片
 */
+ (instancetype)imageFromGenericBundle:(NSString *)imageName;

/**
获取图片

@param imageName 图片名称
@return 返回图片
*/
+ (instancetype)imageFromAssets:(NSString *)imageName;

/**
 改变图片尺寸图片
 
 @param image 目标图片
 @param targetSize 改变后的尺寸
 @return 返回图片
 */
+ (UIImage *)image:(UIImage*)image byScalingToSize:(CGSize)targetSize;

/**
 从默认的bundle里获取图片
 */
+ (instancetype)imageFromBundleImageName:(NSString *)imageName;
+ (instancetype)imageFromBundleImageName:(NSString *)imageName render:(BOOL)render;


/**
从各个台子默认的bundle里获取图片，如果没有获取到，从assets里获取
@param bundleName 图片存储的bundle名称
 @param imageName 图片名称
@return 返回图片
*/
+ (instancetype)imageFromBundleName:(NSString *)bundleName imageName:(NSString *)imageName;
/**
从各个台子默认的bundle里获取图片，如果没有获取到，从assets里获取
@param bundle 图片存储的bundle，传bundle而不传bundleName是为了方便缓存bundle
 @param imageName 图片名称
@return 返回图片
*/
+ (instancetype)imageFromBundle:(NSBundle *)bundle imageName:(NSString *)imageName;

/// 黑夜模式的 bundle
+ (instancetype)imageFromDarkBundleImageName:(NSString *)imageName;
/**
    light: 按 imageName 名字取图片 图片名字自动拼接_light
    dark: 按 imageName 从darkBundle中取图片，名字自动拼接 _dark,_night,
 */
+ (DKImagePicker)imagePickerWithName:(NSString *)imageName;
+ (DKImagePicker)imagePickerWithLightName:(NSString *)lightName darkImageName:(NSString *)darkName;
+ (DKImagePicker)imagePickerWithLightImage:(UIImage *)lightName darkImage:(UIImage *)darkName;

/// 更具当前主题获取相应图片
+ (UIImage *)imageWithThemeName:(NSString *)imageName;

/**
 * 将图片的tintcolor改颜色
 */
- (UIImage *)ty_tintImageWithColor:(UIColor *)tintColor;
- (UIImage *)ty_tintImageWithMainColor;
/**
 * 图片叠加
 */
- (UIImage *)ty_addImage:(UIImage *)image;
/**
 * 背景图片+背景颜色+上面一个图片
 */
+ (UIImage *)ty_bgImage:(UIImage *)image bgColor:(UIColor *)bgColor addImage:(UIImage *)addImage;

+ (UIImage *)mainColorGradientImageWithSize:(CGSize)size;
+ (UIImage *)mainColorGradientImageWithSize:(CGSize)size gradientColors:(NSArray *)colors;

+ (UIImage *)getNightTypeBgImage:(TYNightBackgroudType)nightType;
+ (UIImage *)getNightTypeParlayBgImage:(TYNightBackgroudType)nightType;

@end

NS_ASSUME_NONNULL_END
