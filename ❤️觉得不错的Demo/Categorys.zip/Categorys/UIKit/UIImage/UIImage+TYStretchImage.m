//
//  UIImage+TYStretchImage.m
//  YaboGames
//
//  Created by mac on 2019/8/5.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIImage+TYStretchImage.h"

@implementation UIImage (TYStretchImage)

+ (UIImage *)ty_stretchableImageNamed:(NSString *)imageName{
    UIImage *image = [UIImage imageNamed:imageName];
    return [image stretchableImageWithLeftCapWidth:image.size.width/2 topCapHeight:image.size.height/2];
}

@end
