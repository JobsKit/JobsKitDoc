//
//  UIImage+TYStretchImage.h
//  YaboGames
//
//  Created by mac on 2019/8/5.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//



NS_ASSUME_NONNULL_BEGIN

@interface UIImage (TYStretchImage)


/**
 UIImage 中间一点拉伸.

 @param imageName 要拉伸的图片
 @return 中间一个像素点拉伸
 */
+ (UIImage *)ty_stretchableImageNamed:(NSString *)imageName;

@end

NS_ASSUME_NONNULL_END
