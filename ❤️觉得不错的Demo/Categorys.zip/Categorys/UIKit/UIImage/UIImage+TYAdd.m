
//
//  UIImage+TYAdd.m
//  YaboGames
//
//  Created by linker on 17/3/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIImage+TYAdd.h"

@implementation UIImage (TYAdd)

- (UIImage *)ty_tintImageWithColor:(UIColor *)tintColor {
    UIGraphicsBeginImageContextWithOptions(self.size, NO, [[UIScreen mainScreen] scale]);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextTranslateCTM(context, 0, self.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    
    CGRect rect = CGRectMake(0, 0, self.size.width, self.size.height);
    CGContextSetBlendMode(context, kCGBlendModeNormal);
    CGContextDrawImage(context, rect, self.CGImage);
    
    CGContextSetBlendMode(context, kCGBlendModeSourceIn);
    [tintColor setFill];
    CGContextFillRect(context, rect);
    
    UIImage *coloredImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return coloredImage;
}
/**
 * 图片叠加
 */
- (UIImage *)ty_addImage:(UIImage *)addImage {
    UIImage *bgImage = self;
    
    UIGraphicsBeginImageContext(bgImage.size);
    UIGraphicsBeginImageContextWithOptions(addImage.size, NO, [UIScreen mainScreen].scale);//这样就不模糊了
    [bgImage drawInRect:CGRectMake(0, 0, bgImage.size.width, bgImage.size.height)];
    // 将添加的图片画在背景图片的中心
    [addImage drawInRect:CGRectMake((bgImage.size.width - addImage.size.width)/2,(bgImage.size.height - addImage.size.height)/2, addImage.size.width, addImage.size.height)];
    UIImage *resultingImage = UIGraphicsGetImageFromCurrentImageContext();

    UIGraphicsEndImageContext();

    return resultingImage;
}
/**
 * 背景图片+背景颜色+上面一个图片
 */
+ (UIImage *)ty_bgImage:(UIImage *)image bgColor:(UIColor *)bgColor addImage:(UIImage *)addImage {
    UIImage *resultImage = [image ty_tintImageWithColor:bgColor];
    resultImage = [resultImage ty_addImage:addImage];
    return resultImage;
}
- (UIImage *)ty_tintImageWithMainColor {
    return [self ty_tintImageWithColor:Color.ThemeColor];
}

+ (instancetype)compressBaseImage:(UIImage *)image maxByte:(CGFloat)byte{
    NSAssert(byte > 0, @"图片的大小必须大于 0");
    
    
    CGFloat compress = 0.9f;
    NSData *data = UIImageJPEGRepresentation(image, compress);
    
    while (data.length > byte && compress > 0.01) {
        compress -= 0.02f;
        
        data = UIImageJPEGRepresentation(image, compress);
    }
    return [UIImage imageWithData:data];
}

+ (instancetype)imageFromGenericBundle:(NSString *)imageName {
    
    NSString *path = [[NSBundle bundleForClass: NSClassFromString(@"TYViewController")] pathForResource:@"XGeneric" ofType:@"bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:path];
    return [UIImage imageNamed:imageName inBundle:bundle compatibleWithTraitCollection:nil];
}

+ (instancetype)imageFromBundleName:(NSString *)bundleName imageName:(NSString *)imageName {
    NSString *bundlePath = [[NSBundle mainBundle] pathForResource:bundleName ofType :@"bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
    return [self imageFromBundle:bundle imageName:imageName];
}

+ (instancetype)imageFromBundleImageName:(NSString *)imageName render:(BOOL)render {
    UIImage *image = [self imageFromBundleImageName:imageName];
    if (render) {
         image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    }
    return image;
}

+ (instancetype)imageFromBundleImageName:(NSString *)imageName {
    
    if (![imageName isKindOfClass:NSString.class]) {
        return nil;
    }
    
    if (imageName.length == 0) {
        return nil;
    }
    
    /* 增加黑夜模式 */
    if (IsYB()) {
        return [self imageFromBundleImageNameYB:imageName];
    } else {
        return [self imageFromBundleImageNameNormal:imageName];
    }
}

+ (instancetype)imageFromBundleImageNameNormal:(NSString *)imageName{
    
    TYFResourceConfig *config = TYFSiteManager.manager.resourceConfig;
    NSBundle *defaultBundle = config.defaultBundle;
    NSBundle *commonBundle = config.commonBundle;
    NSBundle *xGenericBundle = config.xGenericBundle;
    
    if (defaultBundle == nil) {
        return [UIImage imageNamed:imageName];
    }
    
    NSString *defaultBundleImageKey = [[defaultBundle bundlePath] stringByAppendingPathComponent:imageName];
    UIImage *image = [YYImageCache.sharedCache getImageForKey:defaultBundleImageKey withType:YYImageCacheTypeMemory];
    if (image) {
        return image;
    }
    
    NSString *commonBundleImageKey = [[commonBundle bundlePath] stringByAppendingPathComponent:imageName];
    image = [YYImageCache.sharedCache getImageForKey:commonBundleImageKey withType:YYImageCacheTypeMemory];
    if (image) {
        return image;
    }
    
    NSString *xGenericBundleImageKey = [[xGenericBundle bundlePath] stringByAppendingPathComponent:imageName];
    image = [YYImageCache.sharedCache getImageForKey:xGenericBundleImageKey withType:YYImageCacheTypeMemory];
    if (image) {
        return image;
    }
    
    NSString *key = defaultBundleImageKey;
    image = [UIImage imageNamed:imageName inBundle:defaultBundle compatibleWithTraitCollection:nil];
    if (image == nil) {
        key = commonBundleImageKey;
        image = [UIImage imageNamed:imageName inBundle:commonBundle compatibleWithTraitCollection:nil];
    }
    
    if (image == nil) {
        key = xGenericBundleImageKey;
        image = [UIImage imageNamed:imageName inBundle:xGenericBundle compatibleWithTraitCollection:nil];
    }
    
    if (image == nil) {
        key = nil;
        image = [UIImage imageNamed:imageName];
    }
    
    if (image && key) {
        [YYImageCache.sharedCache setImage:image imageData:nil forKey:key withType:YYImageCacheTypeMemory];
    }
    
    return image;
}

+ (instancetype)imageFromBundleImageNameYB:(NSString *)imageName {
    TYFResourceConfig *config = TYFSiteManager.manager.resourceConfig;
    NSBundle *defaultDarkBundle = config.defaultDarkBundle;
    NSBundle *commonDarkBundle = config.commonDarkBundle;
    if (defaultDarkBundle == nil) {
        return [UIImage imageNamed:imageName];
    }
    
    NSString *defaultBundleImageKey = [[defaultDarkBundle bundlePath] stringByAppendingPathComponent:imageName];
    UIImage *image = [YYImageCache.sharedCache getImageForKey:defaultBundleImageKey withType:YYImageCacheTypeMemory];
    if (image) {
        return image;
    }
    
    NSString *commonBundleImageKey = [[commonDarkBundle bundlePath] stringByAppendingPathComponent:imageName];
    image = [YYImageCache.sharedCache getImageForKey:commonBundleImageKey withType:YYImageCacheTypeMemory];
    if (image) {
        return image;
    }
    
    NSString *key = defaultBundleImageKey;
    image = [UIImage imageNamed:imageName inBundle:defaultDarkBundle compatibleWithTraitCollection:nil];
    if (image == nil) {
        key = commonBundleImageKey;
        image = [UIImage imageNamed:imageName inBundle:commonDarkBundle compatibleWithTraitCollection:nil];
    }
    
    if (image == nil) {
        key = nil;
        image = [UIImage imageNamed:imageName];
    }
    
    if (image && key) {
        [YYImageCache.sharedCache setImage:image imageData:nil forKey:key withType:YYImageCacheTypeMemory];
    }
    
    return image;
}

+ (instancetype)imageFromDarkBundleImageName:(NSString *)imageName {
    
    TYFResourceConfig *config = TYFSiteManager.manager.resourceConfig;
    NSBundle *defaultDarkBundle = config.defaultDarkBundle;
    NSBundle *commonDarkBundle = config.commonDarkBundle;
    
    NSString *defaultBundleImageKey = [[defaultDarkBundle bundlePath] stringByAppendingPathComponent:imageName];
    UIImage *image = [YYImageCache.sharedCache getImageForKey:defaultBundleImageKey withType:YYImageCacheTypeMemory];
    if (image) {
        return image;
    }
    
    NSString *commonBundleImageKey = [[commonDarkBundle bundlePath] stringByAppendingPathComponent:imageName];
    image = [YYImageCache.sharedCache getImageForKey:commonBundleImageKey withType:YYImageCacheTypeMemory];
    if (image) {
        return image;
    }
    
    NSString *key = defaultBundleImageKey;
    image = [UIImage imageNamed:imageName inBundle:defaultDarkBundle compatibleWithTraitCollection:nil];
    if (image == nil) {
        key = commonBundleImageKey;
        image = [UIImage imageNamed:imageName inBundle:commonDarkBundle compatibleWithTraitCollection:nil];
    }
    
    if (image && key) {
        [YYImageCache.sharedCache setImage:image imageData:nil forKey:key withType:YYImageCacheTypeMemory];
    }
    
    return image;
    
}

+ (instancetype)imageFromBundle:(NSBundle *)bundle imageName:(NSString *)imageName {
    UIImage *image = [UIImage imageNamed:imageName inBundle:bundle compatibleWithTraitCollection:nil];
    if (image == nil) {
        // 如果图片是空，从assets里获取
        image = [UIImage imageNamed:imageName];
    }
    return image;
}

+ (instancetype)imageFromAssets:(NSString *)imageName{
    
    return [UIImage imageNamed:imageName];
}

+ (UIImage *)image:(UIImage*)image byScalingToSize:(CGSize)targetSize {
    
    UIImage *sourceImage = image;
    UIImage *newImage = nil;
    
    UIGraphicsBeginImageContext(targetSize);
    
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = CGPointZero;
    thumbnailRect.size.width  = targetSize.width;
    thumbnailRect.size.height = targetSize.height;
    
    [sourceImage drawInRect:thumbnailRect];
    
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage ;
}

/// 黑夜模式图片获取方式
+ (DKImagePicker)imagePickerWithName:(NSString *)imageName {
    
    return [UIImage imagePickerWithLightName:imageName darkImageName:imageName];
}

+ (DKImagePicker)imagePickerWithLightName:(NSString *)lightName darkImageName:(NSString *)darkName {
    
    UIImage *norImage = [UIImage imageFromBundleImageName:lightName];
    if (!norImage) {
        norImage = [UIImage imageFromBundleImageName:[NSString stringWithFormat:@"%@_light",EMPTY_IF_NIL(lightName)]];
    }
    
    UIImage *darkImage = [UIImage imageFromDarkBundleImageName:EMPTY_IF_NIL(darkName)];
    if (!darkImage) {
        darkImage = [UIImage imageFromDarkBundleImageName:[NSString stringWithFormat:@"%@_dark",EMPTY_IF_NIL(darkName)]];
    }
    
    if (!darkImage) {
        darkImage = [UIImage imageFromDarkBundleImageName:[NSString stringWithFormat:@"%@_night",EMPTY_IF_NIL(darkName)]];
    }
    
    if (!IsYB()) {
        return DKImagePickerWithImages(norImage,norImage);
    }
    
    return DKImagePickerWithImages(norImage,darkImage);
}

+ (DKImagePicker)imagePickerWithLightImage:(UIImage *)lightName darkImage:(UIImage *)darkName {
    
    if (IsYB()) {
        return DKImagePickerWithImages(darkName,darkName);
    }
    
    if (!IsYB()) {
        return DKImagePickerWithImages(lightName,lightName);
    }
   return DKImagePickerWithImages(lightName,darkName);
}

/// 更具当前主题获取相应图片
+ (UIImage *)imageWithThemeName:(NSString *)imageName {
    
    DKImagePicker picker = [UIImage imagePickerWithName:imageName];
    return picker([DKNightVersionManager sharedManager].themeVersion);
}

+ (UIImage *)mainColorGradientImageWithSize:(CGSize)size {
    
    return [self mainColorGradientImageWithSize:size gradientColors:@[(__bridge id)TYFSiteManager.manager.siteConfig.gradientMainColor.CGColor,(__bridge id)SiteMainColor().CGColor]];
}

+ (UIImage *)mainColorGradientImageWithSize:(CGSize)size gradientColors:(NSArray *)colors {
    
    CAGradientLayer *gradientLayer =  [CAGradientLayer layer];
    gradientLayer.frame = CGRectMake(0, 0, size.width, size.height);
    gradientLayer.startPoint = CGPointMake(0, 0);
    gradientLayer.endPoint = CGPointMake(1, 0);
    gradientLayer.locations = @[@(0.1),@(1.0)];
    gradientLayer.cornerRadius = size.height/2.0;
    gradientLayer.colors = colors;
    
    UIGraphicsBeginImageContextWithOptions(gradientLayer.frame.size, NO, 0);
    [gradientLayer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *gradientImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return gradientImage;
}

+ (UIImage *)qr_imageWithSize:(CGSize)size Txt:(NSString *)txt {
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    [filter setDefaults];
    NSData *data = [txt dataUsingEncoding:NSUTF8StringEncoding];
    [filter setValue:data forKeyPath:@"inputMessage"];
    CIImage *cimage = [filter outputImage];
    
    CGRect extent = CGRectIntegral(cimage.extent);
    CGFloat scale = MIN(size.width/CGRectGetWidth(extent), size.height/CGRectGetHeight(extent));
    // 1.创建bitmap;
    size_t width = CGRectGetWidth(extent) * scale;
    size_t height = CGRectGetHeight(extent) * scale;
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
    CGContextRef bitmapRef = CGBitmapContextCreate(nil, width, height, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaNone);
    CIContext *context = [CIContext contextWithOptions:nil];
    CGImageRef bitmapImage = [context createCGImage:cimage fromRect:extent];
    CGContextSetInterpolationQuality(bitmapRef, kCGInterpolationNone);
    CGContextScaleCTM(bitmapRef, scale, scale);
    CGContextDrawImage(bitmapRef, extent, bitmapImage);
    // 2.保存bitmap到图片
    CGImageRef scaledImage = CGBitmapContextCreateImage(bitmapRef);
    CGContextRelease(bitmapRef);
    CGImageRelease(bitmapImage);
    return [UIImage imageWithCGImage:scaledImage];
}

+ (UIImage *)getNightTypeBgImage:(TYNightBackgroudType)nightType {
    switch (nightType) {
        case TYNightBackgroudTypeRed:
            return Image.event_list_bg_red;
        case TYNightBackgroudTypeBlue:
            return Image.event_list_bg_blue;
        case TYNightBackgroudTypePurple:
            return Image.event_list_bg_zi;
            
        default:
            break;
    }
    return nil;
}
+ (UIImage *)getNightTypeParlayBgImage:(TYNightBackgroudType)nightType {
    switch (nightType) {
        case TYNightBackgroudTypeRed:
            return Image.skt_sport_bet_bg_red_night;
        case TYNightBackgroudTypeBlue:
            return Image.skt_sport_bet_bg_blue_night;
        case TYNightBackgroudTypePurple:
            return Image.skt_sport_bet_bg_purple_night;
            
        default:
            break;
    }
    return nil;
}


@end
