//
//  UIButton+TYBadge.h
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (TYBadge)

@property (strong, nonatomic) UILabel *ty_badge;

// Badge value to be display
@property (nonatomic) NSString *ty_badgeValue;
// Badge background color
@property (nonatomic) UIColor *ty_badgeBGColor;
// Badge text color
@property (nonatomic) UIColor *ty_badgeTextColor;
// Badge font
@property (nonatomic) UIFont *ty_badgeFont;
// Padding value for the badge
@property (nonatomic) CGFloat ty_badgePadding;
// Minimum size badge to small
@property (nonatomic) CGFloat ty_badgeMinSize;
// Values for offseting the badge over the BarButtonItem you picked
@property (nonatomic) CGFloat ty_badgeOriginX;
@property (nonatomic) CGFloat ty_badgeOriginY;
// In case of numbers, remove the badge when reaching zero
@property BOOL ty_shouldHideBadgeAtZero;
// Badge has a bounce animation when value changes
@property BOOL ty_shouldAnimateBadge;

@end
