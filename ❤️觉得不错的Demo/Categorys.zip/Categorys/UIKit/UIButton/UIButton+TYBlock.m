//
//  UIButton+TYBlock.m
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIButton+TYBlock.h"
#import <objc/runtime.h>

static const void *ty_UIButtonBlockKey = &ty_UIButtonBlockKey;

@implementation UIButton (TYBlock)

-(void)ty_addActionHandler:(TYTouchedButtonBlock)touchHandler{
    objc_setAssociatedObject(self, ty_UIButtonBlockKey, touchHandler, OBJC_ASSOCIATION_COPY_NONATOMIC);
    [self addTarget:self action:@selector(ty_blockActionTouched:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)ty_blockActionTouched:(UIButton *)btn {
    TYTouchedButtonBlock block = objc_getAssociatedObject(self, ty_UIButtonBlockKey);
    if (block) {
        block(btn.tag);
    }
}

@end
