//
//  UIButton+TYBackgroundColor.h
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (TYBackgroundColor)

- (void)ty_setBackgroundColor:(UIColor *)backgroundColor forState:(UIControlState)state;

@end
