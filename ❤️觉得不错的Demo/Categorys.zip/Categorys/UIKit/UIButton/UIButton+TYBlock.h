//
//  UIButton+TYBlock.h
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^TYTouchedButtonBlock)(NSInteger tag);

@interface UIButton (TYBlock)

- (void)ty_addActionHandler:(TYTouchedButtonBlock)touchHandler;

@end
