//
//  UIButton+TYBadge.m
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIButton+TYBadge.h"
#import <objc/runtime.h>

NSString const *ty_UIButton_badgeKey = @"ty_UIButton_badgeKey";

NSString const *ty_UIButton_badgeBGColorKey = @"ty_UIButton_badgeBGColorKey";
NSString const *ty_UIButton_badgeTextColorKey = @"ty_UIButton_badgeTextColorKey";
NSString const *ty_UIButton_badgeFontKey = @"ty_UIButton_badgeFontKey";
NSString const *ty_UIButton_badgePaddingKey = @"ty_UIButton_badgePaddingKey";
NSString const *ty_UIButton_badgeMinSizeKey = @"ty_UIButton_badgeMinSizeKey";
NSString const *ty_UIButton_badgeOriginXKey = @"ty_UIButton_badgeOriginXKey";
NSString const *ty_UIButton_badgeOriginYKey = @"ty_UIButton_badgeOriginYKey";
NSString const *ty_UIButton_shouldHideBadgeAtZeroKey = @"ty_UIButton_shouldHideBadgeAtZeroKey";
NSString const *ty_UIButton_shouldAnimateBadgeKey = @"ty_UIButton_shouldAnimateBadgeKey";
NSString const *ty_UIButton_badgeValueKey = @"ty_UIButton_badgeValueKey";

@implementation UIButton (TYBadge)

@dynamic ty_badgeValue, ty_badgeBGColor, ty_badgeTextColor, ty_badgeFont;
@dynamic ty_badgePadding, ty_badgeMinSize, ty_badgeOriginX, ty_badgeOriginY;
@dynamic ty_shouldHideBadgeAtZero, ty_shouldAnimateBadge;

- (void)ty_badgeInit
{
    // Default design initialization
    self.ty_badgeBGColor   = UIColor.redColor;
    self.ty_badgeTextColor = UIColor.whiteColor;
    self.ty_badgeFont      = [UIFont systemFontOfSize:12.0];
    self.ty_badgePadding   = 6;
    self.ty_badgeMinSize   = 8;
    self.ty_badgeOriginX   = self.frame.size.width - self.ty_badge.frame.size.width/2;
    self.ty_badgeOriginY   = -4;
    self.ty_shouldHideBadgeAtZero = YES;
    self.ty_shouldAnimateBadge = YES;
    // Avoids badge to be clipped when animating its scale
    self.clipsToBounds = NO;
}

#pragma mark - Utility methods

// Handle badge display when its properties have been changed (color, font, ...)
- (void)ty_refreshBadge
{
    // Change new attributes
    self.ty_badge.textColor        = self.ty_badgeTextColor;
    self.ty_badge.backgroundColor  = self.ty_badgeBGColor;
    self.ty_badge.font             = self.ty_badgeFont;
}

- (CGSize) ty_badgeExpectedSize
{
    // When the value changes the badge could need to get bigger
    // Calculate expected size to fit new value
    // Use an intermediate label to get expected size thanks to sizeToFit
    // We don't call sizeToFit on the true label to avoid bad display
    UILabel *frameLabel = [self ty_duplicateLabel:self.ty_badge];
    [frameLabel sizeToFit];
    
    CGSize expectedLabelSize = frameLabel.frame.size;
    return expectedLabelSize;
}

- (void)ty_updateBadgeFrame
{
    
    CGSize expectedLabelSize = [self ty_badgeExpectedSize];
    
    // Make sure that for small value, the badge will be big enough
    CGFloat minHeight = expectedLabelSize.height;
    
    // Using a const we make sure the badge respect the minimum size
    minHeight = (minHeight < self.ty_badgeMinSize) ? self.ty_badgeMinSize : expectedLabelSize.height;
    CGFloat minWidth = expectedLabelSize.width;
    CGFloat padding = self.ty_badgePadding;
    
    // Using const we make sure the badge doesn't get too smal
    minWidth = (minWidth < minHeight) ? minHeight : expectedLabelSize.width;
    self.ty_badge.frame = CGRectMake(self.ty_badgeOriginX, self.ty_badgeOriginY, minWidth + padding, minHeight + padding);
    self.ty_badge.layer.cornerRadius = (minHeight + padding) / 2;
    self.ty_badge.layer.masksToBounds = YES;
}

// Handle the badge changing value
- (void)ty_updateBadgeValueAnimated:(BOOL)animated
{
    // Bounce animation on badge if value changed and if animation authorized
    if (animated && self.ty_shouldAnimateBadge && ![self.ty_badge.text isEqualToString:self.ty_badgeValue]) {
        CABasicAnimation * animation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
        [animation setFromValue:[NSNumber numberWithFloat:1.5]];
        [animation setToValue:[NSNumber numberWithFloat:1]];
        [animation setDuration:0.2];
        [animation setTimingFunction:[CAMediaTimingFunction functionWithControlPoints:.4f :1.3f :1.f :1.f]];
        [self.ty_badge.layer addAnimation:animation forKey:@"bounceAnimation"];
    }
    
    // Set the new value
    self.ty_badge.text = self.ty_badgeValue;
    
    // Animate the size modification if needed
    NSTimeInterval duration = animated ? 0.2 : 0;
    [UIView animateWithDuration:duration animations:^{
        [self ty_updateBadgeFrame];
    }];
}

- (UILabel *)ty_duplicateLabel:(UILabel *)labelToCopy
{
    UILabel *duplicateLabel = [[UILabel alloc] initWithFrame:labelToCopy.frame];
    duplicateLabel.text = labelToCopy.text;
    duplicateLabel.font = labelToCopy.font;
    
    return duplicateLabel;
}

- (void)ty_removeBadge
{
    // Animate badge removal
    [UIView animateWithDuration:0.2 animations:^{
        self.ty_badge.transform = CGAffineTransformMakeScale(0, 0);
    } completion:^(BOOL finished) {
        [self.ty_badge removeFromSuperview];
        self.ty_badge = nil;
    }];
}

#pragma mark - getters/setters
-(UILabel*)ty_badge {
    return objc_getAssociatedObject(self, &ty_UIButton_badgeKey);
}
-(void)setTy_badge:(UILabel *)badgeLabel
{
    objc_setAssociatedObject(self, &ty_UIButton_badgeKey, badgeLabel, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self addSubview:self.ty_badge];
}

// Badge value to be display
-(NSString *)ty_badgeValue {
    return objc_getAssociatedObject(self, &ty_UIButton_badgeValueKey);
}
-(void) setTy_badgeValue:(NSString *)badgeValue
{
    objc_setAssociatedObject(self, &ty_UIButton_badgeValueKey, badgeValue, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    // When changing the badge value check if we need to remove the badge
    if (!badgeValue || [badgeValue isEqualToString:@""] || ([badgeValue isEqualToString:@"0"] && self.ty_shouldHideBadgeAtZero)) {
        [self ty_removeBadge];
    } else if (!self.ty_badge) {
        // Create a new badge because not existing
        self.ty_badge                      = [[UILabel alloc] initWithFrame:CGRectMake(self.ty_badgeOriginX, self.ty_badgeOriginY, 20, 20)];
        self.ty_badge.textColor            = self.ty_badgeTextColor;
        self.ty_badge.backgroundColor      = self.ty_badgeBGColor;
        self.ty_badge.font                 = self.ty_badgeFont;
        self.ty_badge.textAlignment        = NSTextAlignmentCenter;
        [self ty_badgeInit];
        [self addSubview:self.ty_badge];
        [self ty_updateBadgeValueAnimated:NO];
    } else {
        [self ty_updateBadgeValueAnimated:YES];
    }
}

// Badge background color
-(UIColor *)ty_badgeBGColor {
    return objc_getAssociatedObject(self, &ty_UIButton_badgeBGColorKey);
}
-(void)setTy_badgeBGColor:(UIColor *)badgeBGColor
{
    objc_setAssociatedObject(self, &ty_UIButton_badgeBGColorKey, badgeBGColor, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    if (self.ty_badge) {
        [self ty_refreshBadge];
    }
}

// Badge text color
-(UIColor *)ty_badgeTextColor {
    return objc_getAssociatedObject(self, &ty_UIButton_badgeTextColorKey);
}
-(void)setTy_badgeTextColor:(UIColor *)badgeTextColor
{
    objc_setAssociatedObject(self, &ty_UIButton_badgeTextColorKey, badgeTextColor, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    if (self.ty_badge) {
        [self ty_refreshBadge];
    }
}

// Badge font
-(UIFont *)ty_badgeFont {
    return objc_getAssociatedObject(self, &ty_UIButton_badgeFontKey);
}
-(void)setTy_badgeFont:(UIFont *)badgeFont
{
    objc_setAssociatedObject(self, &ty_UIButton_badgeFontKey, badgeFont, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    if (self.ty_badge) {
        [self ty_refreshBadge];
    }
}

// Padding value for the badge
-(CGFloat) ty_badgePadding {
    NSNumber *number = objc_getAssociatedObject(self, &ty_UIButton_badgePaddingKey);
    return number.floatValue;
}
-(void) setTy_badgePadding:(CGFloat)badgePadding
{
    NSNumber *number = [NSNumber numberWithDouble:badgePadding];
    objc_setAssociatedObject(self, &ty_UIButton_badgePaddingKey, number, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    if (self.ty_badge) {
        [self ty_updateBadgeFrame];
    }
}

// Minimum size badge to small
-(CGFloat) ty_badgeMinSize {
    NSNumber *number = objc_getAssociatedObject(self, &ty_UIButton_badgeMinSizeKey);
    return number.floatValue;
}
-(void) setTy_badgeMinSize:(CGFloat)badgeMinSize
{
    NSNumber *number = [NSNumber numberWithDouble:badgeMinSize];
    objc_setAssociatedObject(self, &ty_UIButton_badgeMinSizeKey, number, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    if (self.ty_badge) {
        [self ty_updateBadgeFrame];
    }
}

// Values for offseting the badge over the BarButtonItem you picked
-(CGFloat) ty_badgeOriginX {
    NSNumber *number = objc_getAssociatedObject(self, &ty_UIButton_badgeOriginXKey);
    return number.floatValue;
}
-(void) setTy_badgeOriginX:(CGFloat)badgeOriginX
{
    NSNumber *number = [NSNumber numberWithDouble:badgeOriginX];
    objc_setAssociatedObject(self, &ty_UIButton_badgeOriginXKey, number, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    if (self.ty_badge) {
        [self ty_updateBadgeFrame];
    }
}

-(CGFloat) ty_badgeOriginY {
    NSNumber *number = objc_getAssociatedObject(self, &ty_UIButton_badgeOriginYKey);
    return number.floatValue;
}
-(void) setTy_badgeOriginY:(CGFloat)badgeOriginY
{
    NSNumber *number = [NSNumber numberWithDouble:badgeOriginY];
    objc_setAssociatedObject(self, &ty_UIButton_badgeOriginYKey, number, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    if (self.ty_badge) {
        [self ty_updateBadgeFrame];
    }
}

// In case of numbers, remove the badge when reaching zero
-(BOOL) ty_shouldHideBadgeAtZero {
    NSNumber *number = objc_getAssociatedObject(self, &ty_UIButton_shouldHideBadgeAtZeroKey);
    return number.boolValue;
}
- (void)setTy_shouldHideBadgeAtZero:(BOOL)shouldHideBadgeAtZero
{
    NSNumber *number = [NSNumber numberWithBool:shouldHideBadgeAtZero];
    objc_setAssociatedObject(self, &ty_UIButton_shouldHideBadgeAtZeroKey, number, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

// Badge has a bounce animation when value changes
-(BOOL) ty_shouldAnimateBadge {
    NSNumber *number = objc_getAssociatedObject(self, &ty_UIButton_shouldAnimateBadgeKey);
    return number.boolValue;
}
- (void)setTy_shouldAnimateBadge:(BOOL)shouldAnimateBadge
{
    NSNumber *number = [NSNumber numberWithBool:shouldAnimateBadge];
    objc_setAssociatedObject(self, &ty_UIButton_shouldAnimateBadgeKey, number, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

@end
