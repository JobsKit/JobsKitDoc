//
//  UIButton+TYExtendResponseArea.m
//  YaboSports
//
//  Created by olin on 2019/6/2.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import "UIButton+TYExtendResponseArea.h"
#import <objc/runtime.h>
#import "TYFFSwizzle.h"

@implementation UIButton (TYExtendResponseArea)

+ (void)initialize
{
    [super initialize];
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        TYFFSwizzleMethod([UIButton class], @selector(pointInside:withEvent:), [UIButton class], @selector(ty_pointInside:withEvent:));
    });
}

- (UIEdgeInsets)extendEdgeInsets
{
    NSValue *edgeInsetValue= objc_getAssociatedObject(self, _cmd);
    UIEdgeInsets edgeInset = UIEdgeInsetsZero;
    if(edgeInsetValue){
        edgeInset = edgeInsetValue.UIEdgeInsetsValue;
    }
    return edgeInset;
}

- (void)setExtendEdgeInsets:(UIEdgeInsets)extendEdgeInsets
{
    NSValue *edgeInsetValue = [NSValue valueWithUIEdgeInsets:extendEdgeInsets];
    objc_setAssociatedObject(self, @selector(extendEdgeInsets), edgeInsetValue, OBJC_ASSOCIATION_RETAIN);
}


- (BOOL)ty_pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    if(UIEdgeInsetsEqualToEdgeInsets(self.extendEdgeInsets, UIEdgeInsetsZero)){
        return [self ty_pointInside:point withEvent:event];
    }
    CGRect area = CGRectMake(-self.extendEdgeInsets.left,
                             -self.extendEdgeInsets.top,
                             CGRectGetWidth(self.frame)+self.extendEdgeInsets.left+self.extendEdgeInsets.right,
                             CGRectGetHeight(self.frame)+self.extendEdgeInsets.top+self.extendEdgeInsets.bottom);
    return CGRectContainsPoint(area, point);
    
}

@end
