//
//  UIButton+TYExtendResponseArea.h
//  YaboSports
//
//  Created by olin on 2019/6/2.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//
//  扩展控件的响应区域
//  有时button frame较小，经常会出现点击不到的情况，因此可以通过扩展点击区域解决此问题

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (TYExtendResponseArea)

@property(nonatomic, assign)UIEdgeInsets extendEdgeInsets;

@end

NS_ASSUME_NONNULL_END
