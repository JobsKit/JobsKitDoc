//
//  UIButton+TYImagePosition.h
//  YaboGames
//
//  Created by windy on 08/04/2019.
//  Copyright © 2019 com.tianyu.mobiledev. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, TYImagePosition) {
    TYImagePositionLeft = 0,              //图片在左，文字在右，默认
    TYImagePositionRight = 1,             //图片在右，文字在左
    TYImagePositionTop = 2,               //图片在上，文字在下
    TYImagePositionBottom = 3,            //图片在下，文字在上
};


@interface UIButton (TYImagePosition)

/**
 *  利用UIButton的titleEdgeInsets和imageEdgeInsets来实现文字和图片的自由排列
 *  注意：这个方法需要在设置图片和文字之后才可以调用，且button的大小要大于 图片大小+文字大小+spacing
 *
 *  @param spacing 图片和文字的间隔
 */
- (void)ty_setImagePosition:(TYImagePosition)postion spacing:(CGFloat)spacing;
/* 只给凤凰和球速用，其他台子不要用 */
- (void)ty_setImagePosition:(TYImagePosition)postion spacing:(CGFloat)spacing leftSpace:(CGFloat)leftSpace topSpace:(CGFloat)topSace;

- (void)ty_setImagePosition:(TYImagePosition)postion spacing:(CGFloat)spacing  numberLine:(NSInteger) lines;

- (void)ty_setImagePosition:(TYImagePosition)postion spacing:(CGFloat)spacing leftSpace:(CGFloat)leftSpace;
@end
