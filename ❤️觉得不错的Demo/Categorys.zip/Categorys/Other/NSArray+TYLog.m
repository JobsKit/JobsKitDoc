//
//  NSArray+TYLog.m
//  YaboSports
//
//  Created by amos on 2020/2/22.
//  Copyright © 2020 com.tianyu.mobiledev. All rights reserved.
//

#import "NSArray+TYLog.h"

@implementation NSArray (TYLog)

//%@ 为数组会来调用这个方法
- (NSString *)descriptionWithLocale:(id)locale
{
#ifdef DEBUG
    NSMutableString *strM = [NSMutableString stringWithString:@"(\n"];
    
    [self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        [strM appendFormat:@"\t%@,\n", obj];
    }];
    
    [strM appendString:@")"];
    
    return strM;
#endif
    return @"";
}

@end
