//
//  TYFSwizzle.h
//  FirefoxGames
//
//  Created by BWJS-FREDERIC on 2020/9/21.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import <Foundation/Foundation.h>

extern BOOL TYFSwizzleMethod(Class originalCls, SEL originalSelector, Class swizzledCls, SEL swizzledSelector);
extern BOOL TYFSwizzleClassMethod(Class originalCls, SEL originalSelector, Class swizzledCls, SEL swizzledSelector);
