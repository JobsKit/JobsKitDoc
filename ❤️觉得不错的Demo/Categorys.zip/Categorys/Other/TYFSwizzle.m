//
//  TYFSwizzle.m
//  FirefoxGames
//
//  Created by BWJS-FREDERIC on 2020/9/21.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import "TYFSwizzle.h"
#import <objc/runtime.h>

BOOL TYFSwizzleMethod(Class originalCls, SEL originalSelector, Class swizzledCls, SEL swizzledSelector) {
    Method originalMethod = class_getInstanceMethod(originalCls, originalSelector);
    Method swizzledMethod = class_getInstanceMethod(swizzledCls, swizzledSelector);
    if (!originalMethod || !swizzledMethod) {
        return NO;
    }
    BOOL didAddMethod =
    class_addMethod(originalCls,
                    originalSelector,
                    method_getImplementation(swizzledMethod),
                    method_getTypeEncoding(swizzledMethod));
    
    if (didAddMethod) {
        class_replaceMethod(originalCls,
                            swizzledSelector,
                            method_getImplementation(originalMethod),
                            method_getTypeEncoding(originalMethod));
    } else {
        method_exchangeImplementations(originalMethod, swizzledMethod);
    }
    return YES;
}

BOOL TYFSwizzleClassMethod(Class originalCls, SEL originalSelector, Class swizzledCls, SEL swizzledSelector) {
    Method originalMethod = class_getClassMethod(originalCls, originalSelector);
    Method swizzledMethod = class_getClassMethod(swizzledCls, swizzledSelector);
    if (!originalMethod || !swizzledMethod) {
        return NO;
    }
    BOOL didAddMethod = class_addMethod(object_getClass(originalCls),originalSelector,
                                        method_getImplementation(swizzledMethod),
                                        method_getTypeEncoding(swizzledMethod));
    
    if (didAddMethod) {
        class_replaceMethod(originalCls,swizzledSelector,
                            method_getImplementation(originalMethod),
                            method_getTypeEncoding(originalMethod));
    } else {
        method_exchangeImplementations(originalMethod, swizzledMethod);
    }
    
    return YES;
}
