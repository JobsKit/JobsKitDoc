//
//  NSDictionary+TYLog.m
//  YaboSports
//
//  Created by amos on 2020/2/22.
//  Copyright © 2020 com.tianyu.mobiledev. All rights reserved.
//

#import "NSDictionary+TYLog.h"

@implementation NSDictionary (TYLog)

//%@ 为字典会来调用这个方法
- (NSString *)descriptionWithLocale:(id)locale
{
#ifdef DEBUG
    NSMutableString *strM = [NSMutableString stringWithString:@"{\n"];
    
    [self enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        [strM appendFormat:@"\t%@ = %@;\n", key, obj];
    }];
    
    [strM appendString:@"}\n"];
    
    return strM;
#endif
    return @"";
    
}

@end
