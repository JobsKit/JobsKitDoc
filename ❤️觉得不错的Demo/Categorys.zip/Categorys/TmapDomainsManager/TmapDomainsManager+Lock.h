//
//  TmapDomainsManager+Lock.h
//  FirefoxGames
//
//  Created by xiexun on 2020/8/18.
//  Copyright © 2020 FirefoxGames. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TmapDomainsManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface TmapDomainsManager (Lock)

/*更新CDN域名组*/
/**
@param mainHost  mainHost
*/
- (void)updateCDNmainHost:(NSDictionary *)mainHost;
@end

NS_ASSUME_NONNULL_END
